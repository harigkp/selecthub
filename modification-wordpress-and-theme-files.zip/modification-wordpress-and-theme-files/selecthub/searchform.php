<?php
/**
 * The template for displaying search forms in elixar
 *
 * @package Elixar
 */
?>
<section>
            <div class="container mt-5">
                <div class="row">
                    <div class="col-md-6">
<form action="<?php echo esc_url( home_url('/') ); ?>" autocomplete="off" method="get" role="search">
	<div class="form-group text-margin">
		<input type="search" name="s" value="<?php echo get_search_query(); ?>" class="form-control input-lg inputfield" placeholder="<?php esc_html_e( 'Search for article ...', 'elixar' ); ?>">
		
	</div>
</form>
</div>
</div>
</div>
</section>