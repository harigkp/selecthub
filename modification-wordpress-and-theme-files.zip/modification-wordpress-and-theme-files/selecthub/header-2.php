<?php
/**
 * The header for our theme.
 *
 * The template used for displaying header content in header.php. it's include in header.php file.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Elixar
 */
 
/* Topbar */
$elixar_topbar_enable = intval( get_theme_mod( 'elixar_topbar_enable', 0 ) );
$elixar_social_top_enable = intval( get_theme_mod( 'elixar_social_top_enable', 1 ) );
$elixar_topbar_menu_enable = intval( get_theme_mod( 'elixar_topbar_menu_enable', 1 ) );
$elixar_fb_url = get_theme_mod( 'elixar_fb_url' );
$elixar_twitter_url = get_theme_mod( 'elixar_twitter_url' );
$elixar_gplus_url = get_theme_mod( 'elixar_gplus_url' );
$elixar_instagram_url = get_theme_mod( 'elixar_instagram_url' );
$elixar_flickr_url = get_theme_mod( 'elixar_flickr_url' );
$elixar_skype_url = get_theme_mod( 'elixar_skype_url' );
/* Header */

$elixar_show_search_in_header = intval( get_theme_mod( 'elixar_show_search_in_header', 1 ) );

/* Menu Bar Position */
$elixar_menu_bar_position = sanitize_text_field( get_theme_mod( 'elixar_menu_bar_position', 'top' ) );



 ?>

<body <?php body_class( 'body-nav-fixed-menu-top ' ); ?>>
<div class="main_wrapper">
<a class="skip-link screen-reader-text" href="#site-header"><?php esc_html_e( 'Skip to content', 'elixar' ); ?></a>
<!-- NAVBAR -->
<div id="site-header">
		<?php if( $elixar_topbar_enable == 1 ) {
			if( $elixar_social_top_enable == 1 || $elixar_topbar_menu_enable == 1 ) { ?>
			<div class="container sitetopbar top_details top-detail-inverse">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="topbar-inner">
							<div class="row">
							<?php if( $elixar_social_top_enable == 1 ) { ?>
							<div class="col-sm-6 col-xs-12 topsocial">
								<div class="list-inline social-top-detail pull-left">
									<?php if( !empty ( $elixar_fb_url ) ) { ?>
									<a href="<?php echo esc_url( $elixar_fb_url ); ?>"><i class="elixar-facebook"></i></a>
									<?php } if( !empty ( $elixar_twitter_url ) ) { ?>
									<a href="<?php echo esc_url( $elixar_twitter_url ); ?>"><i class=" elixar-twitter"></i></a>
									<?php } if( !empty ( $elixar_gplus_url ) ) { ?>
									<a href="<?php echo esc_url( $elixar_gplus_url ); ?>"><i class="elixar-google-plus"></i></a>
									<?php } if( !empty ( $elixar_instagram_url ) ) { ?>
									<a href="<?php echo esc_url( $elixar_instagram_url ); ?>"><i class="elixar-instagram"></i></a>
									<?php } if( !empty ( $elixar_flickr_url ) ) { ?>
									<a href="<?php echo esc_url( $elixar_flickr_url ); ?>"><i class="elixar-flickr"></i></a>
									<?php } if( !empty ( $elixar_skype_url ) ) { ?>
									<a href="<?php echo esc_attr( $elixar_skype_url ); ?>"><i class="elixar-skype"></i></a>
									<?php } ?>
								</div>
							</div>
							<?php } if( $elixar_topbar_menu_enable == 1 ) { ?>
							<div class="col-sm-6 hidden-xs contact_info">
								<nav id="header-nav" class="menu-top-menu-container pull-right">
									<?php wp_nav_menu(
										array(
										'theme_location' => 'top',
										'menu_class'     => 'menu',
										'depth'          => 1,
										'fallback_cb'    => false,
										)
									); ?>
								</nav>
							</div>
							<?php } ?>
						</div>	
					</div>
				</div>
			</div>
		</div>
		<?php } } ?>
		<div class="mobile-nav-wrap">
			<a id="mobile-trigger" href="#mob-menu"><i class="fas fa-list-ul" aria-hidden="true"></i><span><?php esc_html_e( 'Main Menu', 'elixar'); ?><span></span></span></a>
			<div id="mob-menu">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'container'      => '',
					'fallback_cb' => 'elixar_primary_navigation_fallback',
				) );
				?>
			</div><!-- #mob-menu -->
			<?php if ( has_nav_menu( 'top' ) ) : ?>
			<a id="mobile-trigger-quick" href="#mob-menu-quick"><span><?php esc_html_e( 'Top Menu', 'elixar' ); ?></span><i class="fas fa-list-ul" aria-hidden="true"></i></a>
			<div id="mob-menu-quick">
				<?php
				wp_nav_menu( array(
					'theme_location' => 'top',
					'container'      => '',
					'depth'          => 1,
					'fallback_cb'    => false,
				) );
				?>
			</div><!-- #mob-menu-quick -->
		<?php endif; ?>
		</div>

		<?php if( $elixar_menu_bar_position == 'below_hero' ) {
			if ( is_front_page() ) {
				do_action( 'elixar_header_end' );
			}
		} ?>
		
		
		
		
		<div id="e_main_nav" class="clear-fix d-flex justify-content-between" >
		
			<div class="container">
			<span class="wrap-menu-content"><?php if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {the_custom_logo(); } ?><span>
				<nav id="site-navigation" class="main-navigation" role="navigation" style="float:right;">
				
					<div class="wrap-menu-content">
					
					<?php wp_nav_menu( array(
					'theme_location' => 'primary',
					'container' => false,
					'menu_id' => 'primary-menu',
					'fallback_cb' => 'elixar_primary_navigation_fallback',
					) ); ?>
					
					
				</div><!--/.nav-collapse -->
			</nav>
			
			<?php if ( $elixar_show_search_in_header == 1 ) : ?>
				<div class="header-search-box">
					<a href="#" class="search-icon"><i class="fas fa-search"></i></a>
					<div class="search-box-wrap">
						<?php get_search_form(); ?>
					</div>
				</div><!-- .header-search-box -->
			<?php endif; ?>
			</div>
		</div>
</div>
<!-- NAVBAR END -->
<?php
if( $elixar_menu_bar_position != 'below_hero' ) {
	if ( is_front_page() ) {
		do_action( 'elixar_header_end' );
	}
} ?>