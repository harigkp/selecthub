<?php
/**
 * The template used for displaying hierarchical series of hyperlinks displayed at the top of a web page, indicating the page's position in the overall structure of the website.
 *
 * @package Elixar
 */
?>
<!-- SECTION HEADING -->
<?php
$elixar_crumb_and_title = '';
$elixar_page_title_bar_enable = intval( get_theme_mod( 'elixar_page_title_bar_enable', 1 ) );
$elixar_page_title_type = sanitize_text_field( get_theme_mod( 'elixar_page_title_type', 'allow_both' ) );
if( get_post_meta(get_the_ID(), 'elixar_page_breadcrumb_enabled', true) == true ) {
	$elixar_crumb_and_title = get_post_meta(get_the_ID(), 'elixar_page_crumb_and_title', true);
} else if( $elixar_page_title_bar_enable == 1 ) {
	$elixar_crumb_and_title = $elixar_page_title_type;
}
if ( $elixar_crumb_and_title == 'allow_both' || $elixar_crumb_and_title == 'allow_title' ) { ?>

<?php } ?>