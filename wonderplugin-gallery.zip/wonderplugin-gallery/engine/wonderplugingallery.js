/** Wonderplugin Gallery Plugin Free Version
 * Copyright 2022 Magic Hills Pty Ltd All Rights Reserved
 * Website: http://www.wonderplugin.com
 * Version 14.8 
 */
var html5GalleryObjects = new function () {
   this.objects = [];
   this.addObject = function (obj) {
      this.objects.push(obj)
   };
   this.loadNext = function (id) {
      this.objects[id].onVideoEnd();
      if (!this.objects[id].isPaused) this.objects[id].slideRun(-1)
   };
   this.setHd = function (id, isHd, switching) {
      this.objects[id].setHd(isHd, switching)
   };
   this.gotoSlide = function (slideId, galleryId) {
      if (typeof galleryId === "undefined") galleryId = 0;
      if (this.objects[galleryId]) this.objects[galleryId].slideRun(slideId)
   }
};
if (typeof ASYouTubeIframeAPIReady === "undefined") {
   var ASYouTubeIframeAPIReady = false;
   var ASYouTubeTimeout = 0;

   function onYouTubeIframeAPIReady() {
      ASYouTubeIframeAPIReady = true
   }
}
var ASVimeoTimeout = 0;

function loadHtml5Gallery(jsFolder) {
   (function ($) {
      var pow = Math.pow,
         sqrt = Math.sqrt,
         sin = Math.sin,
         cos = Math.cos,
         PI = Math.PI,
         c1 = 1.70158,
         c2 = c1 * 1.525,
         c3 = c1 + 1,
         c4 = 2 * PI / 3,
         c5 = 2 * PI / 4.5;

      function bounceOut(x) {
         var n1 = 7.5625,
            d1 = 2.75;
         if (x < 1 / d1) return n1 * x * x;
         else if (x < 2 / d1) return n1 * (x -= 1.5 / d1) * x + 0.75;
         else if (x < 2.5 / d1) return n1 * (x -= 2.25 / d1) * x + 0.9375;
         else return n1 * (x -= 2.625 / d1) * x + 0.984375
      }
      $.extend($.easing, {
         def: "easeOutQuad",
         easeInQuad: function (x) {
            return x * x
         },
         easeOutQuad: function (x) {
            return 1 - (1 - x) * (1 - x)
         },
         easeInOutQuad: function (x) {
            return x <
               0.5 ? 2 * x * x : 1 - pow(-2 * x + 2, 2) / 2
         },
         easeInCubic: function (x) {
            return x * x * x
         },
         easeOutCubic: function (x) {
            return 1 - pow(1 - x, 3)
         },
         easeInOutCubic: function (x) {
            return x < 0.5 ? 4 * x * x * x : 1 - pow(-2 * x + 2, 3) / 2
         },
         easeInQuart: function (x) {
            return x * x * x * x
         },
         easeOutQuart: function (x) {
            return 1 - pow(1 - x, 4)
         },
         easeInOutQuart: function (x) {
            return x < 0.5 ? 8 * x * x * x * x : 1 - pow(-2 * x + 2, 4) / 2
         },
         easeInQuint: function (x) {
            return x * x * x * x * x
         },
         easeOutQuint: function (x) {
            return 1 - pow(1 - x, 5)
         },
         easeInOutQuint: function (x) {
            return x < 0.5 ? 16 * x * x * x * x * x : 1 - pow(-2 * x + 2, 5) / 2
         },
         easeInSine: function (x) {
            return 1 -
               cos(x * PI / 2)
         },
         easeOutSine: function (x) {
            return sin(x * PI / 2)
         },
         easeInOutSine: function (x) {
            return -(cos(PI * x) - 1) / 2
         },
         easeInExpo: function (x) {
            return x === 0 ? 0 : pow(2, 10 * x - 10)
         },
         easeOutExpo: function (x) {
            return x === 1 ? 1 : 1 - pow(2, -10 * x)
         },
         easeInOutExpo: function (x) {
            return x === 0 ? 0 : x === 1 ? 1 : x < 0.5 ? pow(2, 20 * x - 10) / 2 : (2 - pow(2, -20 * x + 10)) / 2
         },
         easeInCirc: function (x) {
            return 1 - sqrt(1 - pow(x, 2))
         },
         easeOutCirc: function (x) {
            return sqrt(1 - pow(x - 1, 2))
         },
         easeInOutCirc: function (x) {
            return x < 0.5 ? (1 - sqrt(1 - pow(2 * x, 2))) / 2 : (sqrt(1 - pow(-2 * x + 2, 2)) + 1) /
               2
         },
         easeInElastic: function (x) {
            return x === 0 ? 0 : x === 1 ? 1 : -pow(2, 10 * x - 10) * sin((x * 10 - 10.75) * c4)
         },
         easeOutElastic: function (x) {
            return x === 0 ? 0 : x === 1 ? 1 : pow(2, -10 * x) * sin((x * 10 - 0.75) * c4) + 1
         },
         easeInOutElastic: function (x) {
            return x === 0 ? 0 : x === 1 ? 1 : x < 0.5 ? -(pow(2, 20 * x - 10) * sin((20 * x - 11.125) * c5)) / 2 : pow(2, -20 * x + 10) * sin((20 * x - 11.125) * c5) / 2 + 1
         },
         easeInBack: function (x) {
            return c3 * x * x * x - c1 * x * x
         },
         easeOutBack: function (x) {
            return 1 + c3 * pow(x - 1, 3) + c1 * pow(x - 1, 2)
         },
         easeInOutBack: function (x) {
            return x < 0.5 ? pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2) / 2 : (pow(2 *
               x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2
         },
         easeInBounce: function (x) {
            return 1 - bounceOut(1 - x)
         },
         easeOutBounce: bounceOut,
         easeInOutBounce: function (x) {
            return x < 0.5 ? (1 - bounceOut(1 - 2 * x)) / 2 : (1 + bounceOut(2 * x - 1)) / 2
         }
      })
   })(jQuery);
   (function ($) {
      $.fn.touchSwipe = function (options) {
         var defaults = {
            preventWebBrowser: false,
            instance: null,
            preventWebBrowserCallback: null,
            swipeLeft: null,
            swipeRight: null,
            swipeTop: null,
            swipeBottom: null
         };
         if (options) $.extend(defaults, options);
         return this.each(function () {
            var startX = -1,
               startY = -1;
            var curX = -1,
               curY = -1;

            function touchStart(event) {
               var e = event.originalEvent;
               if (e.targetTouches.length >= 1) {
                  startX = e.targetTouches[0].pageX;
                  startY = e.targetTouches[0].pageY
               } else touchCancel(event)
            }

            function touchMove(event) {
               var prevent = defaults.preventWebBrowser;
               var e = event.originalEvent;
               if (e.targetTouches.length >= 1) {
                  curX = e.targetTouches[0].pageX;
                  curY = e.targetTouches[0].pageY;
                  if (defaults.instance && defaults.preventWebBrowserCallback) prevent = defaults.instance[defaults.preventWebBrowserCallback](curY < startY)
               } else touchCancel(event);
               if (prevent) event.preventDefault()
            }

            function touchEnd(event) {
               if (curX > 0 || curY > 0) {
                  triggerHandler();
                  touchCancel(event)
               } else touchCancel(event)
            }

            function touchCancel(event) {
               startX = -1;
               startY = -1;
               curX = -1;
               curY = -1
            }

            function triggerHandler() {
               if (Math.abs(curX - startX) > 100)
                  if (curX > startX) {
                     if (defaults.swipeRight) defaults.swipeRight.call()
                  } else if (defaults.swipeLeft) defaults.swipeLeft.call();
               if (Math.abs(curY - startY) > 100)
                  if (curY > startY) {
                     if (defaults.swipeBottom) defaults.swipeBottom.call()
                  } else if (defaults.swipeTop) defaults.swipeTop.call()
            }
            try {
               $(this).on("touchstart", touchStart);
               $(this).on("touchmove", touchMove);
               $(this).on("touchend", touchEnd);
               $(this).on("touchcancel", touchCancel)
            } catch (e) {}
         })
      }
   })(jQuery);
   (function ($) {
      $.fn.html5boxTransition = function (id, $prev, $next, transition, callback) {
         $parent = this;
         var effects = transition.effect;
         var easing = transition.easing;
         var duration = transition.duration;
         var direction = transition.direction;
         var effect = null;
         if (effects) {
            effects = effects.split(",");
            effect = effects[Math.floor(Math.random() * effects.length)];
            effect = $.trim(effect.toLowerCase())
         }
         if (effect && transition[effect]) {
            if ("duration" in transition[effect]) duration = transition[effect].duration;
            if (transition[effect].easing) easing = transition[effect].easing
         }
         if (effect == "fade" || effect == "fadein") {
            $next.hide();
            $prev.insertBefore($next);
            $next.fadeIn(duration, easing, function () {
               $prev.remove();
               callback()
            })
         } else if (effect == "fadeout") {
            $next.show();
            $prev.fadeOut(duration, easing, function () {
               $prev.remove();
               callback()
            })
         } else if (effect == "fadeinout") {
            $next.hide();
            $prev.insertBefore($next);
            $prev.fadeOut(duration, easing);
            $next.fadeIn(duration, easing, function () {
               $prev.remove();
               callback()
            })
         } else if (effect == "crossfade") {
            $next.hide();
            $prev.fadeOut(duration / 2, easing, function () {
               $next.fadeIn(duration / 2, easing, function () {
                  $prev.remove();
                  callback()
               })
            })
         } else if (effect == "slide") {
            $parent.css({
               overflow: "hidden"
            });
            if (direction) {
               $next.css({
                  left: "100%"
               });
               $next.animate({
                  left: "0%"
               }, duration, easing);
               $prev.animate({
                  left: "-100%"
               }, duration, easing, function () {
                  $prev.remove();
                  callback()
               })
            } else {
               $next.css({
                  left: "-100%"
               });
               $next.animate({
                  left: "0%"
               }, duration, easing);
               $prev.animate({
                  left: "100%"
               }, duration, easing, function () {
                  $prev.remove();
                  callback()
               })
            }
         } else {
            $next.show();
            $prev.remove();
            callback()
         }
      }
   })(jQuery);
   (function ($) {
      $.fn.addHTML5VideoControls = function (skinFolder, parentInst, videoElem, hideControls, hidePlayButton, defaultVolume, fullscreenNativeControls, html5VideoNoDownload, skinImages, showsubtitle, vttline, showsubtitlebydefault) {
         var isTouch = "ontouchstart" in window;
         var eStart = isTouch ? "touchstart" : "mousedown";
         var eMove = isTouch ?
            "touchmove" : "mousemove";
         var eCancel = isTouch ? "touchcancel" : "mouseup";
         var eClick = "click";
         var BUTTON_SIZE = 32;
         var BAR_HEIGHT = isTouch ? 48 : 36;
         var hideControlsTimerId = null;
         var hideVolumeBarTimeoutId = null;
         var sliderDragging = false;
         var isFullscreen = false;
         var userActive = true;
         var isHd = $(this).data("ishd");
         var hd = $(this).data("hd");
         var src = $(this).data("src");
         var $videoObj = $(this);
         $videoObj.get(0).removeAttribute("controls");
         var $videoPlay = $("<div class='html5boxVideoPlay'></div>");
         $videoObj.after($videoPlay);
         var playbuttonImage = skinImages && "playbutton" in skinImages && skinImages.playbutton && skinImages.playbutton.length > 0 ? skinImages.playbutton : skinFolder + "html5boxplayer_playvideo.png";
         $videoPlay.css({
            position: "absolute",
            top: "50%",
            left: "50%",
            display: "block",
            cursor: "pointer",
            width: 64,
            height: 64,
            "margin-left": -32,
            "margin-top": -32,
            "background-image": "url('" + playbuttonImage + "')",
            "background-position": "center center",
            "background-repeat": "no-repeat"
         }).on(eClick, function () {
            if (parentInst.options.stopallplaying) parentInst.stopAllPlaying();
            $videoObj.get(0).play()
         });
         var $videoFullscreenBg = $("<div class='html5boxVideoFullscreenBg'></div>");
         var $videoControls = $("<div class='html5boxVideoControls'>" + "<div class='html5boxVideoControlsBg'></div>" + "<div class='html5boxPlayPause'>" + "<div class='html5boxPlay'></div>" + "<div class='html5boxPause'></div>" + "</div>" + "<div class='html5boxTimeCurrent'>--:--</div>" + "<div class='html5boxFullscreen'></div>" + "<div class='html5boxCaption'></div>" + "<div class='html5boxHD'></div>" + "<div class='html5boxVolume'>" +
            "<div class='html5boxVolumeButton'></div>" + "<div class='html5boxVolumeBar'>" + "<div class='html5boxVolumeBarBg'>" + "<div class='html5boxVolumeBarActive'></div>" + "</div>" + "</div>" + "</div>" + "<div class='html5boxTimeTotal'>--:--</div>" + "<div class='html5boxSeeker'>" + "<div class='html5boxSeekerBuffer'></div>" + "<div class='html5boxSeekerPlay'></div>" + "<div class='html5boxSeekerHandler'></div>" + "</div>" + "<div style='clear:both;'></div>" + "</div>");
         $videoObj.after($videoControls);
         $videoObj.after($videoFullscreenBg);
         $videoFullscreenBg.css({
            display: "none",
            position: "fixed",
            left: 0,
            top: 0,
            bottom: 0,
            right: 0
         });
         $videoControls.css({
            display: "block",
            position: "absolute",
            width: "100%",
            height: BAR_HEIGHT,
            left: 0,
            bottom: 0,
            right: 0,
            margin: "0 auto"
         });
         var userActivate = function () {
            userActive = true
         };
         $videoObj.on("touch click mousemove mouseenter", function () {
            userActive = true
         });
         if (!hideControls) setInterval(function () {
            if (userActive) {
               $videoControls.show();
               userActive = false;
               clearTimeout(hideControlsTimerId);
               hideControlsTimerId = setTimeout(function () {
                     if (!$videoObj.get(0).paused) $videoControls.fadeOut()
                  },
                  5E3)
            }
         }, 250);
         $(".html5boxVideoControlsBg", $videoControls).css({
            display: "block",
            position: "absolute",
            width: "100%",
            height: "100%",
            left: 0,
            top: 0,
            "background-color": "#000000",
            opacity: 0.7,
            filter: "alpha(opacity=70)"
         });
         $(".html5boxPlayPause", $videoControls).css({
            display: "block",
            position: "relative",
            width: BUTTON_SIZE + "px",
            height: BUTTON_SIZE + "px",
            margin: Math.floor((BAR_HEIGHT - BUTTON_SIZE) / 2),
            "float": "left"
         });
         var $videoBtnPlay = $(".html5boxPlay", $videoControls);
         var $videoBtnPause = $(".html5boxPause", $videoControls);
         $videoBtnPlay.css({
            display: "block",
            position: "absolute",
            top: 0,
            left: 0,
            width: BUTTON_SIZE + "px",
            height: BUTTON_SIZE + "px",
            cursor: "pointer",
            "background-image": "url('" + skinFolder + "html5boxplayer_playpause.png" + "')",
            "background-position": "top left"
         }).hover(function () {
            $(this).css({
               "background-position": "bottom left"
            })
         }, function () {
            $(this).css({
               "background-position": "top left"
            })
         }).on(eClick, function () {
            if (parentInst.options.stopallplaying) parentInst.stopAllPlaying();
            $videoObj.get(0).play()
         });
         $videoBtnPause.css({
            display: "none",
            position: "absolute",
            top: 0,
            left: 0,
            width: BUTTON_SIZE + "px",
            height: BUTTON_SIZE + "px",
            cursor: "pointer",
            "background-image": "url('" + skinFolder + "html5boxplayer_playpause.png" + "')",
            "background-position": "top right"
         }).hover(function () {
            $(this).css({
               "background-position": "bottom right"
            })
         }, function () {
            $(this).css({
               "background-position": "top right"
            })
         }).on(eClick, function () {
            $videoObj.get(0).pause()
         });
         var $videoTimeCurrent = $(".html5boxTimeCurrent", $videoControls);
         var $videoTimeTotal = $(".html5boxTimeTotal", $videoControls);
         var $videoSeeker = $(".html5boxSeeker", $videoControls);
         var $videoSeekerPlay = $(".html5boxSeekerPlay", $videoControls);
         var $videoSeekerBuffer = $(".html5boxSeekerBuffer", $videoControls);
         var $videoSeekerHandler = $(".html5boxSeekerHandler", $videoControls);
         $videoTimeCurrent.css({
            display: "block",
            position: "relative",
            "float": "left",
            "line-height": BAR_HEIGHT + "px",
            "font-weight": "normal",
            "font-size": "12px",
            margin: "0 8px",
            "font-family": "Arial, Helvetica, sans-serif",
            color: "#fff"
         });
         $videoTimeTotal.css({
            display: "block",
            position: "relative",
            "float": "right",
            "line-height": BAR_HEIGHT + "px",
            "font-weight": "normal",
            "font-size": "12px",
            margin: "0 8px",
            "font-family": "Arial, Helvetica, sans-serif",
            color: "#fff"
         });
         $videoSeeker.css({
            display: "block",
            cursor: "pointer",
            overflow: "hidden",
            position: "relative",
            height: "10px",
            "background-color": "#222",
            margin: Math.floor((BAR_HEIGHT - 10) / 2) + "px 4px"
         }).on(eStart, function (e) {
            var e0 = isTouch ? e.originalEvent.touches[0] : e;
            var pos = e0.pageX - $videoSeeker.offset().left;
            $videoSeekerPlay.css({
               width: pos
            });
            $videoObj.get(0).currentTime = pos * $videoObj.get(0).duration / $videoSeeker.width();
            $videoSeeker.on(eMove, function (e) {
               var e0 = isTouch ? e.originalEvent.touches[0] : e;
               var pos = e0.pageX - $videoSeeker.offset().left;
               $videoSeekerPlay.css({
                  width: pos
               });
               $videoObj.get(0).currentTime = pos * $videoObj.get(0).duration / $videoSeeker.width()
            })
         }).on(eCancel, function () {
            $videoSeeker.off(eMove)
         });
         $videoSeekerBuffer.css({
            display: "block",
            position: "absolute",
            left: 0,
            top: 0,
            height: "100%",
            "background-color": "#444"
         });
         $videoSeekerPlay.css({
            display: "block",
            position: "absolute",
            left: 0,
            top: 0,
            height: "100%",
            "background-color": "#fcc500"
         });
         var $videoFSObj = fullscreenNativeControls ? $videoObj : $videoObj.parent();
         if ($videoFSObj.get(0).requestFullscreen || $videoFSObj.get(0).webkitRequestFullScreen || $videoFSObj.get(0).mozRequestFullScreen || $videoFSObj.get(0).webkitEnterFullScreen || $videoFSObj.get(0).msRequestFullscreen) {
            var switchScreen = function (fullscreen) {
               if (fullscreen) {
                  if (fullscreenNativeControls) {
                     $videoObj.get(0).setAttribute("controls", "controls");
                     if (html5VideoNoDownload) $videoObj.get(0).setAttribute("controlsList",
                        "nodownload")
                  }
                  if ($videoFSObj.get(0).requestFullscreen) $videoFSObj.get(0).requestFullscreen();
                  else if ($videoFSObj.get(0).webkitRequestFullScreen) $videoFSObj.get(0).webkitRequestFullScreen();
                  else if ($videoFSObj.get(0).mozRequestFullScreen) $videoFSObj.get(0).mozRequestFullScreen();
                  else if ($videoFSObj.get(0).webkitEnterFullScreen) $videoFSObj.get(0).webkitEnterFullScreen();
                  if ($videoFSObj.get(0).msRequestFullscreen) $videoFSObj.get(0).msRequestFullscreen()
               } else if (document.cancelFullScreen) document.cancelFullScreen();
               else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
               else if (document.webkitCancelFullScreen) document.webkitCancelFullScreen();
               else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
               else if (document.msExitFullscreen) document.msExitFullscreen()
            };
            var switchScreenCSS = function (fullscreen) {
               if (fullscreenNativeControls)
                  if (fullscreen) {
                     $videoObj.get(0).setAttribute("controls", "controls");
                     if (html5VideoNoDownload) $videoObj.get(0).setAttribute("controlsList", "nodownload")
                  } else $videoObj.get(0).removeAttribute("controls");
               else if (fullscreen) {
                  $(document).on("mousemove", userActivate);
                  $videoControls.css({
                     "z-index": 2147483647,
                     position: "fixed"
                  });
                  $videoFullscreenBg.css({
                     "z-index": 2147483647,
                     display: "block"
                  });
                  $videoPlay.css({
                     "z-index": 2147483647
                  })
               } else {
                  $(document).off("mousemove", userActivate);
                  $videoControls.css({
                     "z-index": "",
                     position: "absolute"
                  });
                  $videoFullscreenBg.css({
                     "z-index": "",
                     display: "none"
                  });
                  $videoPlay.css({
                     "z-index": ""
                  })
               }
            };
            document.addEventListener("MSFullscreenChange", function () {
               isFullscreen = document.msFullscreenElement !=
                  null;
               switchScreenCSS(isFullscreen)
            }, false);
            document.addEventListener("fullscreenchange", function () {
               isFullscreen = document.fullscreen;
               switchScreenCSS(isFullscreen)
            }, false);
            document.addEventListener("mozfullscreenchange", function () {
               isFullscreen = document.mozFullScreen;
               switchScreenCSS(isFullscreen)
            }, false);
            document.addEventListener("webkitfullscreenchange", function () {
               isFullscreen = document.webkitIsFullScreen;
               switchScreenCSS(isFullscreen)
            }, false);
            $videoFSObj.get(0).addEventListener("webkitbeginfullscreen",
               function () {
                  isFullscreen = true;
                  switchScreenCSS(isFullscreen)
               }, false);
            $videoFSObj.get(0).addEventListener("webkitendfullscreen", function () {
               isFullscreen = false;
               switchScreenCSS(isFullscreen)
            }, false);
            if (!fullscreenNativeControls) $("head").append("<style type='text/css'>video" + videoElem + "::-webkit-media-controls { display:none !important; }</style>");
            var $videoFullscreen = $(".html5boxFullscreen", $videoControls);
            $videoFullscreen.css({
               display: "block",
               position: "relative",
               "float": "right",
               width: BUTTON_SIZE + "px",
               height: BUTTON_SIZE + "px",
               margin: Math.floor((BAR_HEIGHT - BUTTON_SIZE) / 2),
               cursor: "pointer",
               "background-image": "url('" + skinFolder + "html5boxplayer_fullscreen.png" + "')",
               "background-position": "left top"
            }).hover(function () {
               var backgroundPosX = $(this).css("background-position") ? $(this).css("background-position").split(" ")[0] : $(this).css("background-position-x");
               $(this).css({
                  "background-position": backgroundPosX + " bottom"
               })
            }, function () {
               var backgroundPosX = $(this).css("background-position") ? $(this).css("background-position").split(" ")[0] :
                  $(this).css("background-position-x");
               $(this).css({
                  "background-position": backgroundPosX + " top"
               })
            }).on(eClick, function () {
               isFullscreen = !isFullscreen;
               switchScreen(isFullscreen)
            })
         }
         if (hd) {
            var $videoHD = $(".html5boxHD", $videoControls);
            $videoHD.css({
               display: "block",
               position: "relative",
               "float": "right",
               width: BUTTON_SIZE + "px",
               height: BUTTON_SIZE + "px",
               margin: Math.floor((BAR_HEIGHT - BUTTON_SIZE) / 2),
               cursor: "pointer",
               "background-image": "url('" + skinFolder + "html5boxplayer_hd.png" + "')",
               "background-position": (isHd ? "right" :
                  "left") + " center"
            }).on(eClick, function () {
               isHd = !isHd;
               $(this).css({
                  "background-position": (isHd ? "right" : "left") + " center"
               });
               parentInst.isHd = isHd;
               var isPaused = $videoObj.get(0).isPaused;
               $videoObj.get(0).setAttribute("src", (isHd ? hd : src) + "#t=" + $videoObj.get(0).currentTime);
               if (!isPaused) $videoObj.get(0).play();
               else $videoObj.get(0).pause()
            })
         }
         if (showsubtitle) {
            var $videoCaption = $(".html5boxCaption", $videoControls);
            $videoCaption.css({
               display: "block",
               position: "relative",
               "float": "right",
               width: BUTTON_SIZE + "px",
               height: BUTTON_SIZE + "px",
               margin: Math.floor((BAR_HEIGHT - BUTTON_SIZE) / 2),
               cursor: "pointer",
               "background-image": "url('" + skinFolder + "html5boxplayer_caption.png" + "')",
               "background-position": showsubtitlebydefault ? "right center" : "left center"
            }).data("showcaption", showsubtitlebydefault).on(eClick, function () {
               var showcaption = !$videoCaption.data("showcaption");
               $videoCaption.data("showcaption", showcaption).css({
                  "background-position": (showcaption ? "right" : "left") + " center"
               });
               if ($videoObj.get(0).textTracks)
                  for (var i =
                        0; i < $videoObj.get(0).textTracks.length; i++) $videoObj.get(0).textTracks[i].mode = showcaption ? "showing" : "hidden"
            })
         }
         $videoObj.get(0).volume = defaultVolume;
         var volumeSaved = defaultVolume == 0 ? 1 : defaultVolume;
         var volume = $videoObj.get(0).volume;
         $videoObj.get(0).volume = volume / 2 + 0.1;
         if ($videoObj.get(0).volume === volume / 2 + 0.1) {
            $videoObj.get(0).volume = volume;
            var $videoVolume = $(".html5boxVolume", $videoControls);
            var $videoVolumeButton = $(".html5boxVolumeButton", $videoControls);
            var $videoVolumeBar = $(".html5boxVolumeBar",
               $videoControls);
            var $videoVolumeBarBg = $(".html5boxVolumeBarBg", $videoControls);
            var $videoVolumeBarActive = $(".html5boxVolumeBarActive", $videoControls);
            $videoVolume.css({
               display: "block",
               position: "relative",
               "float": "right",
               width: BUTTON_SIZE + "px",
               height: BUTTON_SIZE + "px",
               margin: Math.floor((BAR_HEIGHT - BUTTON_SIZE) / 2)
            }).hover(function () {
               clearTimeout(hideVolumeBarTimeoutId);
               var volume = $videoObj.get(0).volume;
               $videoVolumeBarActive.css({
                  height: Math.round(volume * 100) + "%"
               });
               $videoVolumeBar.show()
            }, function () {
               clearTimeout(hideVolumeBarTimeoutId);
               hideVolumeBarTimeoutId = setTimeout(function () {
                  $videoVolumeBar.hide()
               }, 1E3)
            });
            $videoVolumeButton.css({
               display: "block",
               position: "absolute",
               top: 0,
               left: 0,
               width: BUTTON_SIZE + "px",
               height: BUTTON_SIZE + "px",
               cursor: "pointer",
               "background-image": "url('" + skinFolder + "html5boxplayer_volume.png" + "')",
               "background-position": "top " + (volume > 0 ? "left" : "right")
            }).hover(function () {
               var backgroundPosX = $(this).css("background-position") ? $(this).css("background-position").split(" ")[0] : $(this).css("background-position-x");
               $(this).css({
                  "background-position": backgroundPosX +
                     " bottom"
               })
            }, function () {
               var backgroundPosX = $(this).css("background-position") ? $(this).css("background-position").split(" ")[0] : $(this).css("background-position-x");
               $(this).css({
                  "background-position": backgroundPosX + " top"
               })
            }).on(eClick, function () {
               var volume = $videoObj.get(0).volume;
               if (volume > 0) {
                  volumeSaved = volume;
                  volume = 0
               } else volume = volumeSaved;
               var backgroundPosY = $(this).css("background-position") ? $(this).css("background-position").split(" ")[1] : $(this).css("background-position-y");
               $videoVolumeButton.css({
                  "background-position": (volume >
                     0 ? "left" : "right") + " " + backgroundPosY
               });
               if (volume > 0) $videoObj.get(0).muted = false;
               $videoObj.get(0).volume = volume;
               $videoVolumeBarActive.css({
                  height: Math.round(volume * 100) + "%"
               })
            });
            $videoVolumeBar.css({
               display: "none",
               position: "absolute",
               left: 4,
               bottom: "100%",
               width: 24,
               height: 80,
               "margin-bottom": Math.floor((BAR_HEIGHT - BUTTON_SIZE) / 2),
               "background-color": "#000000",
               opacity: 0.7,
               filter: "alpha(opacity=70)"
            });
            $videoVolumeBarBg.css({
               display: "block",
               position: "relative",
               width: 10,
               height: 68,
               margin: 7,
               cursor: "pointer",
               "background-color": "#222"
            });
            $videoVolumeBarActive.css({
               display: "block",
               position: "absolute",
               bottom: 0,
               left: 0,
               width: "100%",
               height: "100%",
               "background-color": "#fcc500"
            });
            $videoVolumeBarBg.on(eStart, function (e) {
               var e0 = isTouch ? e.originalEvent.touches[0] : e;
               var vol = 1 - (e0.pageY - $videoVolumeBarBg.offset().top) / $videoVolumeBarBg.height();
               vol = vol > 1 ? 1 : vol < 0 ? 0 : vol;
               $videoVolumeBarActive.css({
                  height: Math.round(vol * 100) + "%"
               });
               $videoVolumeButton.css({
                  "background-position": "left " + (vol > 0 ? "top" : "bottom")
               });
               if (vol > 0) $videoObj.get(0).muted =
                  false;
               $videoObj.get(0).volume = vol;
               $videoVolumeBarBg.on(eMove, function (e) {
                  var e0 = isTouch ? e.originalEvent.touches[0] : e;
                  var vol = 1 - (e0.pageY - $videoVolumeBarBg.offset().top) / $videoVolumeBarBg.height();
                  vol = vol > 1 ? 1 : vol < 0 ? 0 : vol;
                  $videoVolumeBarActive.css({
                     height: Math.round(vol * 100) + "%"
                  });
                  $videoVolumeButton.css({
                     "background-position": "left " + (vol > 0 ? "top" : "bottom")
                  });
                  if (vol > 0) $videoObj.get(0).muted = false;
                  $videoObj.get(0).volume = vol
               })
            }).on(eCancel, function () {
               $videoVolumeBarBg.off(eMove)
            })
         }
         var calcTimeFormat =
            function (seconds) {
               var h0 = Math.floor(seconds / 3600);
               var h = h0 < 10 ? "0" + h0 : h0;
               var m0 = Math.floor((seconds - h0 * 3600) / 60);
               var m = m0 < 10 ? "0" + m0 : m0;
               var s0 = Math.floor(seconds - (h0 * 3600 + m0 * 60));
               var s = s0 < 10 ? "0" + s0 : s0;
               var r = m + ":" + s;
               if (h0 > 0) r = h + ":" + r;
               return r
            };
         if (hidePlayButton) $videoPlay.hide();
         if (hideControls) $videoControls.hide();
         var setVttline = function (vttline) {
            if ($videoObj.get(0).textTracks) {
               for (var i = 0; i < $videoObj.get(0).textTracks.length; i++) {
                  $videoObj.get(0).textTracks[i].mode = "hidden";
                  if ($videoObj.get(0).textTracks[i].activeCues)
                     for (var j =
                           0; j < $videoObj.get(0).textTracks[i].activeCues.length; j++) $videoObj.get(0).textTracks[i].activeCues[j].line = vttline;
                  if ($videoObj.get(0).textTracks[i].cues)
                     for (var j = 0; j < $videoObj.get(0).textTracks[i].cues.length; j++) $videoObj.get(0).textTracks[i].cues[j].line = vttline
               }
               var showcaption = $(".html5boxCaption", $videoControls).data("showcaption");
               for (var i = 0; i < $videoObj.get(0).textTracks.length; i++) $videoObj.get(0).textTracks[i].mode = showcaption ? "showing" : "hidden"
            }
         };
         var onVideoPlay = function () {
            if (!hidePlayButton) $videoPlay.hide();
            if (!hideControls) {
               $videoBtnPlay.hide();
               $videoBtnPause.show()
            }
         };
         var onVideoPause = function () {
            if (!hidePlayButton) $videoPlay.show();
            if (!hideControls) {
               $videoControls.show();
               clearTimeout(hideControlsTimerId);
               $videoBtnPlay.show();
               $videoBtnPause.hide()
            }
         };
         var onVideoEnded = function () {
            $(window).trigger("html5lightbox.videoended");
            if (!hidePlayButton) $videoPlay.show();
            if (!hideControls) {
               $videoControls.show();
               clearTimeout(hideControlsTimerId);
               $videoBtnPlay.show();
               $videoBtnPause.hide()
            }
         };
         var onVideoUpdate = function () {
            var curTime =
               $videoObj.get(0).currentTime;
            if (curTime) {
               $videoTimeCurrent.text(calcTimeFormat(curTime));
               var duration = $videoObj.get(0).duration;
               if (duration) {
                  $videoTimeTotal.text(calcTimeFormat(duration));
                  if (!sliderDragging) {
                     var sliderW = $videoSeeker.width();
                     var pos = Math.round(sliderW * curTime / duration);
                     $videoSeekerPlay.css({
                        width: pos
                     });
                     $videoSeekerHandler.css({
                        left: pos
                     })
                  }
               }
            }
         };
         var onVideoProgress = function () {
            if ($videoObj.get(0).buffered && $videoObj.get(0).buffered.length > 0 && !isNaN($videoObj.get(0).buffered.end(0)) && !isNaN($videoObj.get(0).duration)) {
               var sliderW =
                  $videoSeeker.width();
               $videoSeekerBuffer.css({
                  width: Math.round(sliderW * $videoObj.get(0).buffered.end(0) / $videoObj.get(0).duration)
               })
            }
         };
         try {
            $videoObj.on("canplay", function () {
               if (showsubtitle) setVttline(vttline)
            });
            $videoObj.on("play", onVideoPlay);
            $videoObj.on("pause", onVideoPause);
            $videoObj.on("ended", onVideoEnded);
            $videoObj.on("timeupdate", onVideoUpdate);
            $videoObj.on("progress", onVideoProgress)
         } catch (e) {}
      }
   })(jQuery);
   (function ($) {
      var ELEM_ID = 0,
         ELEM_THUMBNAIL = 1,
         ELEM_SRC = 2,
         ELEM_SRC_OGG = 3,
         ELEM_SRC_WEBM =
         4,
         ELEM_LINK = 5,
         ELEM_LINKTARGET = 6,
         ELEM_TITLE = 7,
         ELEM_INFORMATION = 8,
         ELEM_TYPE = 9,
         ELEM_WIDTH = 10,
         ELEM_HEIGHT = 11,
         ELEM_POSTER = 12,
         ELEM_HD = 13,
         ELEM_HD_OGG = 14,
         ELEM_HD_WEBM = 15,
         ELEM_DURATION = 16,
         ELEM_LIGHTBOXWIDTH = 17,
         ELEM_LIGHTBOXHEIGHT = 18,
         ELEM_YOUTUBEAPIKEY = 19,
         ELEM_YOUTUBEPLAYLISTID = 20,
         ELEM_YOUTUBEPLAYLISTMAXRESULTS = 21,
         ELEM_LIGHTBOX = 22,
         ELEM_POSTERWIDTH = 23,
         ELEM_POSTERHEIGHT = 24,
         ELEM_ALT = 25;
      ELEM_VTT = 26;
      ELEM_VTTLANG = 27;
      ELEM_VTTLABEL = 28;
      ELEM_CATEGORY = 29;
      var TYPE_IMAGE = 1,
         TYPE_SWF = 2,
         TYPE_MP3 = 3,
         TYPE_PDF = 4,
         TYPE_VIDEO_FLASH =
         5,
         TYPE_VIDEO_MP4 = 6,
         TYPE_VIDEO_OGG = 7,
         TYPE_VIDEO_WEBM = 8,
         TYPE_VIDEO_YOUTUBE = 9,
         TYPE_VIDEO_VIMEO = 10,
         TYPE_EMBED_VIDEO = 11,
         TYPE_IFRAME = 12,
         TYPE_YOUTUBE_PLAYLIST = 13;
      var html5GalleryId = 0;
      $.fn.wonderplugingallery = function (options) {
         var Html5Gallery = function (container, options, id) {
            this.container = container;
            this.options = options;
            this.id = id;
            $(window).trigger("html5gallery.begin", [this.id]);
            this.options.flashInstalled = false;
            this.options.html5VideoSupported = !!document.createElement("video").canPlayType;
            this.options.isChrome =
               navigator.userAgent.match(/Chrome/i) != null;
            this.options.isFirefox = navigator.userAgent.match(/Firefox/i) != null;
            this.options.isOpera = navigator.userAgent.match(/Opera/i) != null || navigator.userAgent.match(/OPR\//i) != null;
            this.options.isSafari = navigator.userAgent.match(/Safari/i) != null;
            this.options.isIE11 = navigator.userAgent.match(/Trident\/7/) != null && navigator.userAgent.match(/rv:11/) != null;
            this.options.isIE = navigator.userAgent.match(/MSIE/i) != null && !this.options.isOpera;
            this.options.isIE10 = navigator.userAgent.match(/MSIE 10/i) !=
               null && !this.options.isOpera;
            this.options.isIE9 = navigator.userAgent.match(/MSIE 9/i) != null && !this.options.isOpera;
            this.options.isIE8 = navigator.userAgent.match(/MSIE 8/i) != null && !this.options.isOpera;
            this.options.isIE7 = navigator.userAgent.match(/MSIE 7/i) != null && !this.options.isOpera;
            this.options.isIE6 = navigator.userAgent.match(/MSIE 6/i) != null && !this.options.isOpera;
            this.options.isIE678 = this.options.isIE6 || this.options.isIE7 || this.options.isIE8;
            this.options.isIE6789 = this.options.isIE6 || this.options.isIE7 ||
               this.options.isIE8 || this.options.isIE9;
            this.options.isAndroid = navigator.userAgent.match(/Android/i) != null;
            this.options.isIPad = navigator.userAgent.match(/iPad/i) != null;
            this.options.isIPhone = navigator.userAgent.match(/iPod/i) != null || navigator.userAgent.match(/iPhone/i) != null;
            this.options.isIOS = this.options.isIPad || this.options.isIPhone;
            this.options.isMobile = this.options.isAndroid || this.options.isIPad || this.options.isIPhone;
            this.options.isIOSLess5 = this.options.isIPad && this.options.isIPhone && (navigator.userAgent.match(/OS 4/i) !=
               null || navigator.userAgent.match(/OS 3/i) != null);
            this.options.supportCSSPositionFixed = !this.options.isIE6 && !this.options.isIOSLess5;
            this.isTouch = "ontouchstart" in window || this.options.forcetouch;
            this.eStart = this.isTouch ? "touchstart" : "mousedown";
            this.eMove = this.isTouch ? "touchmove" : "mousemove";
            this.eCancel = this.isTouch ? "touchcancel" : "mouseup";
            this.eClick = "click";
            var v = document.createElement("video");
            this.options.canplaymp4 = v && v.canPlayType && v.canPlayType("video/mp4").replace(/no/, "");
            this.slideshowTimeout =
               null;
            this.looptimes = 0;
            this.updateCarouselTimeout = null;
            this.disableupdatecarousel = false;
            this.hideTitleTimeout = null;
            this.hideToolboxTimeout = null;
            this.isHd = this.options.hddefault;
            this.isHTML5 = false;
            this.elemArray = [];
            $(".html5gallery-loading").hide();
            this.container.children().hide();
            this.container.css({
               "display": "block",
               "position": "relative"
            });
            if (this.options.googlefonts && this.options.googlefonts.length > 0) {
               var fontRef = "https://fonts.googleapis.com/css?family=" + this.options.googlefonts;
               var fontLink = document.createElement("link");
               fontLink.setAttribute("rel", "stylesheet");
               fontLink.setAttribute("type", "text/css");
               fontLink.setAttribute("href", fontRef);
               document.getElementsByTagName("head")[0].appendChild(fontLink)
            }
            this.initData(this.processElemArray)
         };
         Html5Gallery.prototype = {
            getParams: function () {
               var result = {};
               var params = window.location.search.substring(1).split("&");
               for (var i = 0; i < params.length; i++) {
                  var value = params[i].split("=");
                  if (value && value.length == 2) result[value[0].toLowerCase()] = unescape(value[1])
               }
               return result
            },
            initCategory: function () {
               this.selectedcategory =
                  this.options.categorydefault;
               if (!this.options.categorylist || this.options.categorylist.length < 2) this.options.showcategory = false
            },
            init: function (instance) {
               if (instance.options.random)
                  for (var i = instance.elemArray.length - 1; i > 0; i--) {
                     var index = Math.floor(Math.random() * i);
                     var t = instance.elemArray[i];
                     instance.elemArray[i] = instance.elemArray[index];
                     instance.elemArray[index] = t
                  }
               if (instance.options.reverse) instance.elemArray.reverse();
               instance.initYoutubeApi();
               instance.options.showcarousel = (instance.elemArray.length >
                  1 || instance.options.showcarouselforsingle) && instance.options.showcarousel;
               instance.options.watermarkcode = "";
               if (instance.options.frve) instance.options.watermarkcode = "";
               else if (instance.options.watermarklink.length > 0) instance.options.watermarkcode = "";
               var freeCss;
               if (instance.options.frve) freeCss = "";
               else if (instance.options.watermark.length > 0) freeCss = "";
               else freeCss = "display:none;";
               instance.options.watermarkcode += "<div " + (instance.options.frve ? "" : "class='html5gallery-watermark-" + instance.id + "' ") + "style='" + freeCss + "' >";
               if (instance.options.frve) instance.options.watermarkcode += instance.options.frvem;
               else if (instance.options.watermark.length > 0) instance.options.watermarkcode += "<img src='" + instance.options.watermark + "' alt='' />";
               instance.options.watermarkcode +=
                  "</div>";
               if (instance.options.frve || instance.options.watermarklink.length > 0) instance.options.watermarkcode += "</a>";
               instance.createMarkup();
               instance.createImageToolbox();
               if (instance.elemArray.length <= 0) return;
               instance.initCategory();
               instance.createSliderTimeout();
               instance.createEvents();
               instance.loadCarousel();
               instance.createStyle();
               instance.savedElem = -1;
               instance.curElem = -1;
               instance.nextElem = -1;
               instance.prevElem = -1;
               instance.firstrun = true;
               instance.isPaused = !instance.options.autoslide;
               instance.isFullscreen =
                  false;
               instance.isVideoPlaying = false;
               instance.showingPoster = false;
               instance.disableTouchSwipe = false;
               instance.createSocial(false);
               var params = instance.getParams();
               var firstid = instance.options.firstitemid;
               if ("html5galleryid" in params && params.html5galleryid in instance.elemArray) firstid = params["html5galleryid"];
               if ("galleryshareid" in params && params.galleryshareid in instance.elemArray) firstid = params["galleryshareid"];
               if ("html5gallerybackid" in params && params.html5gallerybackid in instance.elemArray) firstid =
                  instance.elemArray.length - 1 - parseInt(params["html5gallerybackid"]);
               instance.slideRun(firstid);
               instance.firstrun = false;
               if (instance.options.responsive) {
                  instance.resizeGallery();
                  $(window).resize(function () {
                     setTimeout(function () {
                        instance.resizeGallery()
                     }, instance.options.resizedelay)
                  });
                  if (instance.options.isMobile && !instance.options.mobileresizeevent) $(window).on("orientationchange", function () {
                     setTimeout(function () {
                        instance.resizeGallery()
                     }, instance.options.resizedelay)
                  })
               }
               $(window).trigger("html5gallery.inited",
                  [instance.id, instance.curElem]);
               instance.initSearch()
            },
            initSearch: function () {
               var instance = this;
               $(".wondergallery-search").on("keyup", function (e) {
                  var searchText = String($.trim($(this).val())).toLowerCase();
                  var galleryId = $(this).data("galleryid");
                  if (!galleryId || galleryId == instance.id) instance.searchGallery(searchText)
               })
            },
            searchGallery: function (searchText) {
               var instance = this;
               if (searchText && searchText.length > 0)
                  for (var i = 0; i < instance.elemArray.length; i++) {
                     var match = instance.elemArray[i][ELEM_ALT] && instance.elemArray[i][ELEM_ALT].toLowerCase().indexOf(searchText) >=
                        0 || instance.elemArray[i][ELEM_TITLE] && instance.elemArray[i][ELEM_TITLE].toLowerCase().indexOf(searchText) >= 0 || instance.elemArray[i][ELEM_INFORMATION] && instance.elemArray[i][ELEM_INFORMATION].toLowerCase().indexOf(searchText) >= 0;
                     $("#html5gallery-tn-" + instance.id + "-" + i).css({
                        display: match ? "block" : "none"
                     })
                  } else $(".html5gallery-tn-" + instance.id).css({
                     display: "block"
                  })
            },
            resizeGallery: function () {
               switch (this.options.skin) {
                  case "vertical":
                  case "verticallight":
                  case "verticalwithleft":
                  case "verticallightwithleft":
                  case "showcase":
                     this.resizeStyleVertical();
                     break;
                  case "light":
                  case "horizontal":
                  case "darkness":
                  case "gallery":
                  default:
                     this.resizeStyleDefault()
               }
               this.resizeImageToolbox()
            },
            absoluteUrl: function (href) {
               var link = document.createElement("a");
               link.href = href;
               return link.protocol + "//" + link.host + link.pathname + link.search + link.hash
            },
            createSocial: function (isfullscreen) {
               if (this.options.initsocial) $("head").append('<link rel="stylesheet" href="' + this.options.jsfolder + 'icons/css/mhfontello.css" type="text/css" />');
               if (!this.options.showsocial) return;
               var instance =
                  this;
               var styleCss = ".html5gallery-rotate { border-radius:50%; -webkit-transition:-webkit-transform .4s ease-in; transition: transform .4s ease-in; } .html5gallery-rotate:hover { -webkit-transform: rotate(360deg); transform: rotate(360deg); }";
               $("head").append("<style type='text/css' data-creator='html5gallery'>" + styleCss + "</style>");
               var socialCode = "<div";
               if (isfullscreen) socialCode += ' class="html5gallery-fullscreen-social-' + this.id + '" style="display:none;' + this.options.socialpositionlightbox + '"';
               else socialCode +=
                  ' class="html5gallery-social-' + this.id + '" style="display:' + (this.options.socialmode == "mouseover" ? "none" : "block") + ";" + this.options.socialposition + '"';
               socialCode += ">";
               var socialBtnCSS = (this.options.socialdirection == "horizontal" ? "display:inline-block;" : "display:block;") + "margin:4px;";
               var socialCSS = "display:table-cell;width:" + this.options.socialbuttonsize + "px;height:" + this.options.socialbuttonsize + "px;font-size:" + this.options.socialbuttonfontsize + "px;border-radius:50%;color:#fff;vertical-align:middle;text-align:center;cursor:pointer;padding:0;";
               if (this.options.showemail) socialCode += '<div class="html5gallery-social-btn-' + this.id + (this.options.socialrotateeffect ? " html5gallery-rotate" : "") + ' html5gallery-social-email" style="' + socialBtnCSS + '"><div class="mh-icon-mail" style="' + socialCSS + 'background-color:#4d83ff;"></div></div>';
               if (this.options.showfacebook) socialCode += '<div class="html5gallery-social-btn-' + this.id + (this.options.socialrotateeffect ? " html5gallery-rotate" : "") + ' html5gallery-social-facebook" style="' + socialBtnCSS + '"><div class="mh-icon-facebook" style="' +
                  socialCSS + 'background-color:#3b5998;"></div></div>';
               if (this.options.showtwitter) socialCode += '<div class="html5gallery-social-btn-' + this.id + (this.options.socialrotateeffect ? " html5gallery-rotate" : "") + ' html5gallery-social-twitter" style="' + socialBtnCSS + '"><div class="mh-icon-twitter" style="' + socialCSS + 'background-color:#03b3ee;"></div></div>';
               if (this.options.showpinterest) socialCode += '<div class="html5gallery-social-btn-' + this.id + (this.options.socialrotateeffect ? " html5gallery-rotate" : "") + ' html5gallery-social-pinterest" style="' +
                  socialBtnCSS + '"><div class="mh-icon-pinterest" style="' + socialCSS + 'background-color:#c92228;"></div></div>';
               if (this.options.showlinkedin) socialCode += '<div class="html5gallery-social-btn-' + this.id + (this.options.socialrotateeffect ? " html5gallery-rotate" : "") + ' html5gallery-social-linkedin" style="' + socialBtnCSS + '"><div class="mh-icon-linkedin" style="' + socialCSS + 'background-color:#0274b3;"></div></div>';
               if (this.options.showgplus) socialCode += '<div class="html5gallery-social-btn-' + this.id + (this.options.socialrotateeffect ?
                  " html5gallery-rotate" : "") + ' html5gallery-social-gplus" style="' + socialBtnCSS + '"><div class="mh-icon-gplus" style="' + socialCSS + 'background-color:#dd5144;"></div></div>';
               socialCode += '<div style="clear:both;"></div></div>';
               if (isfullscreen) $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).append(socialCode);
               else {
                  $(".html5gallery-box-" + this.id, this.$gallery).append(socialCode);
                  if (this.options.socialmode == "mouseover") $(".html5gallery-box-" + this.id).hover(function () {
                     $(".html5gallery-social-" +
                        instance.id).fadeIn()
                  }, function () {
                     $(".html5gallery-social-" + instance.id).fadeOut()
                  })
               }
               $(".html5gallery-social-btn-" + this.id).click(function () {
                  var shareUrl = window.location.href + (window.location.href.indexOf("?") < 0 ? "?" : "&") + "galleryshareid=" + instance.elemArray[instance.curElem][ELEM_ID];
                  var shareTitle = instance.elemArray[instance.curElem][ELEM_TITLE];
                  var shareMedia = instance.absoluteUrl(instance.elemArray[instance.curElem][ELEM_SRC]);
                  if (instance.options.sharemediaurl) shareUrl = shareMedia;
                  var isVideo = instance.elemArray[instance.curElem][ELEM_TYPE] ==
                     TYPE_VIDEO_FLASH || instance.elemArray[instance.curElem][ELEM_TYPE] == TYPE_VIDEO_MP4 || instance.elemArray[instance.curElem][ELEM_TYPE] == TYPE_VIDEO_OGG || instance.elemArray[instance.curElem][ELEM_TYPE] == TYPE_VIDEO_WEBM || instance.elemArray[instance.curElem][ELEM_TYPE] == TYPE_VIDEO_YOUTUBE || instance.elemArray[instance.curElem][ELEM_TYPE] == TYPE_VIDEO_VIMEO || instance.elemArray[instance.curElem][ELEM_TYPE] == TYPE_EMBED_VIDEO;
                  if (!shareTitle) shareTitle = "";
                  else shareTitle = instance.html2Text(shareTitle);
                  if (isVideo &&
                     instance.elemArray[instance.curElem][ELEM_POSTER]) shareMedia = instance.absoluteUrl(instance.elemArray[instance.curElem][ELEM_POSTER]);
                  if ($(this).hasClass("html5gallery-social-facebook")) window.open("https://www.facebook.com/sharer/sharer.php?u=" + encodeURIComponent(shareUrl) + "&t=" + encodeURIComponent(shareTitle), "_blank");
                  else if ($(this).hasClass("html5gallery-social-twitter")) window.open("https://twitter.com/share?url=" + encodeURIComponent(shareUrl) + "&text=" + encodeURIComponent(shareTitle), "_blank");
                  else if ($(this).hasClass("html5gallery-social-pinterest")) window.open("https://pinterest.com/pin/create/bookmarklet/?media=" + encodeURIComponent(shareMedia) + "&url=" + encodeURIComponent(shareUrl) + "&description=" + encodeURIComponent(shareTitle) + "&is_video=" + (isVideo ? "true" : "false"), "_blank");
                  else if ($(this).hasClass("html5gallery-social-linkedin")) window.open("https://www.linkedin.com/shareArticle?mini=true&url=" + encodeURIComponent(shareUrl) + "&title=" + encodeURIComponent(shareTitle) + "&summary=" + encodeURIComponent(shareTitle),
                     "_blank");
                  else if ($(this).hasClass("html5gallery-social-gplus")) window.open("https://plus.google.com/share?url=" + encodeURIComponent(shareUrl), "_blank");
                  else if ($(this).hasClass("html5gallery-social-email")) window.open("mailto:?subject=" + encodeURIComponent(shareTitle) + "&body=Check out this: " + encodeURIComponent(shareUrl));
                  return false
               })
            },
            html2Text: function (html) {
               var tag = document.createElement("div");
               tag.innerHTML = html;
               return tag.innerText
            },
            checkMK: function () {
               if (this.options.frve) {
                  var item = $(".html5gallery-elem-" +
                     this.id, this.container);
                  var mklink = $('a[href="' + this.options.freelink + '"]', item);
                  if (item.text().indexOf(this.options.frvem) < 0 || mklink.length < 0) item.append("" +
                     this.options.frvem + "");
                  else {
                     var mkdiv = mklink.find("div");
                     if (mklink.css("display") == "none" || mklink.css("visibility") == "hidden" || parseInt(mklink.css("font-size")) < 8 || mkdiv.css("display") == "none" || mkdiv.css("visibility") == "hidden" || parseInt(mkdiv.css("font-size")) < 8) {
                        mklink.attr({
                           style: (mklink.attr("style") || "") + "display:block!important;visibility:visible!important;font-size:12px!important;"
                        });
                        mkdiv.attr({
                           style: mkdiv.attr("style") + "display:block!important;visibility:visible!important;font-size:12px!important;"
                        })
                     }
                  }
               }
            },
            initData: function (onSuccess) {
               this.elemArray = [];
               if (this.options.src && this.options.src.length > 0) {
                  var mediaType = this.options.mediatype ? this.options.mediatype : this.checkType(this.options.src);
                  this.elemArray.push(new Array(0, "", this.options.src, this.options.webm, this.options.ogg, "", "", this.options.title ? this.options.title : "", this.options.title ? this.options.title : "", mediaType, this.options.width, this.options.height, this.options.poster, this.options.hd, this.options.hdogg, this.options.hdwebm));
                  this.readTags();
                  onSuccess(this)
               } else if (this.options.xml && this.options.xml.length > 0) {
                  if (this.options.xmlnocache) {
                     this.options.xml += this.options.xml.indexOf("?") < 0 ? "?" : "&";
                     this.options.xml += Math.random()
                  }
                  var instance = this;
                  $.ajax({
                     type: "GET",
                     url: this.options.xml,
                     dataType: "xml",
                     success: function (xmldata) {
                        $(xmldata).find("slide").each(function (index, value) {
                           var title = $(this).find("title").text();
                           var information = $(this).find("description").text() ? $(this).find("description").text() : $(this).find("information").text();
                           if (!title) title =
                              "";
                           if (!information) information = "";
                           var mediaType = $(this).find("mediatype").text() ? $(this).find("mediatype").text() : instance.checkType($(this).find("file").text());
                           instance.elemArray.push(new Array($(this).find("id").length ? $(this).find("id").text() : index, $(this).find("thumbnail").text(), $(this).find("file").text(), $(this).find("file-ogg").text(), $(this).find("file-webm").text(), $(this).find("link").text(), $(this).find("linktarget").text(), title, information, mediaType, $(this).find("width").length && !isNaN(parseInt($(this).find("width").text())) ?
                              parseInt($(this).find("width").text()) : instance.options.width, $(this).find("height").length && !isNaN(parseInt($(this).find("height").text())) ? parseInt($(this).find("height").text()) : instance.options.height, $(this).find("poster").text(), $(this).find("hd").text(), $(this).find("hdogg").text(), $(this).find("hdwebm").text(), $(this).find("duration").text(), $(this).find("lightboxwidth").text(), $(this).find("lightboxheight").text(), $(this).find("youtubeapikey").text(), $(this).find("youtubeplaylistid").text(),
                              $(this).find("youtubeplaylistmaxresults").text(), $(this).find("lightbox").text().toLowerCase() == "true", $(this).find("width").length && !isNaN(parseInt($(this).find("width").text())) ? parseInt($(this).find("width").text()) : instance.options.width, $(this).find("height").length && !isNaN(parseInt($(this).find("height").text())) ? parseInt($(this).find("height").text()) : instance.options.height, $(this).find("alt").text(), $(this).find("vtt").text(), $(this).find("vttlang").text(), $(this).find("vttlabel").text(),
                              $(this).find("category").text()))
                        });
                        instance.readTags();
                        onSuccess(instance)
                     }
                  })
               } else if (this.options.remote && this.options.remote.length > 0) {
                  var instance = this;
                  $.getJSON(this.options.remote, function (data) {
                     for (var i = 0; i < data.length; i++) {
                        var mediaType = data[i].mediatype ? data[i].mediatype : instance.checkType(data[i].file);
                        instance.elemArray.push(new Array(i, data[i].thumbnail, data[i].file, data[i].fileogg, data[i].filewebm, data[i].link, data[i].linktarget, data[i].title, data[i].description, mediaType, data[i].width &&
                           !isNaN(parseInt(data[i].width)) ? parseInt(data[i].width) : instance.options.width, data[i].height && !isNaN(parseInt(data[i].height)) ? parseInt(data[i].height) : instance.options.height, data[i].poster, data[i].hd, data[i].hdogg, data[i].hdwebm, data[i].duration, data[i].lightboxwidth, data[i].lightboxheight, data[i].youtubeapikey, data[i].youtubeplaylistid, data[i].youtubeplaylistmaxresults, data[i].lightbox, data[i].width && !isNaN(parseInt(data[i].width)) ? parseInt(data[i].width) : instance.options.width, data[i].height &&
                           !isNaN(parseInt(data[i].height)) ? parseInt(data[i].height) : instance.options.height, data[i].alt, data[i].vtt, data[i].vttlang, data[i].vttlabel, data[i].category))
                     }
                     instance.readTags();
                     onSuccess(instance)
                  })
               } else if (this.options.youtubechannel) {
                  var base = "https://gdata.youtube.com/feeds/api/videos?";
                  var params = {
                     alt: "json",
                     v: 2,
                     "orderby": this.options.youtubechannel.orderby ? this.options.youtubechannel.orderby : "published",
                     "start-index": this.options.youtubechannel["start-index"] ? this.options.youtubechannel["start-index"] : 1,
                     "max-results": this.options.youtubechannel["max-results"] ? this.options.youtubechannel["max-results"] : 10
                  };
                  if (this.options.youtubechannel.author) params.author = this.options.youtubechannel.author;
                  else if (this.options.youtubechannel.q) params.q = this.options.youtubechannel.q;
                  base += $.param(params);
                  var instance = this;
                  $.getJSON(base, function (data) {
                     if (data && data.feed && data.feed.entry)
                        for (var i = 1; i < data.feed.entry.length; i++) instance.elemArray.push(new Array(i, "https://img.youtube.com/vi/" + data.feed.entry[i].media$group.yt$videoid.$t +
                           "/" + instance.options.youtubethumb, data.feed.entry[i].media$group.media$player.url, null, null, null, null, data.feed.entry[i].media$group.media$title.$t, data.feed.entry[i].media$group.media$description.$t, TYPE_VIDEO_YOUTUBE, 640, 480, "https://img.youtube.com/vi/" + data.feed.entry[i].media$group.yt$videoid.$t + "/" + instance.options.youtubeimage, null, null, null, null));
                     instance.readTags();
                     onSuccess(instance)
                  })
               } else if (this.options.youtubeapikey && this.options.youtubeplaylistid) {
                  var instance = this;
                  this.getYouTubePlaylist(this.options.youtubeapikey,
                     this.options.youtubeplaylistid, this.options.youtubeplaylistmaxresults, -1,
                     function () {
                        instance.readTags();
                        onSuccess(instance)
                     }, this, null, null)
               } else {
                  this.readTags();
                  onSuccess(this)
               }
            },
            readTags: function () {
               var instance = this;
               var imagelist = $("img.html5galleryimg", this.container).length ? $("img.html5galleryimg", this.container) : $("img", this.container);
               imagelist.each(function (index, value) {
                  var imgsrc = $(this).attr("src");
                  var lazytags = instance.options.lazyloadtags.split(",");
                  for (var i = 0; i < lazytags.length; i++)
                     if ($(this).data(lazytags[i]) &&
                        $(this).data(lazytags[i]).length > 0) {
                        imgsrc = $(this).data(lazytags[i]);
                        break
                     } var src = imgsrc;
                  var title = $(this).data("title") ? $(this).data("title") : $(this).attr("alt");
                  var information = $(this).data("description") ? $(this).data("description") : $(this).data("information");
                  var alt = $(this).attr("alt") ? $(this).attr("alt") : $(this).data("title");
                  if (!title) title = "";
                  if (!information) information = "";
                  if (!alt) alt = "";
                  var width = instance.options.width;
                  var height = instance.options.height;
                  var duration = $(this).data("duration") ?
                     $(this).data("duration") : 0;
                  var videoOgg = null,
                     videoWebm = null;
                  var link = null,
                     linktarget = null;
                  var poster = null;
                  var hd = null,
                     hdogg = null,
                     hdwebm = null;
                  var lightboxwidth = null,
                     lightboxheight = null;
                  var youtubeapikey = null,
                     youtubeplaylistid = null,
                     youtubeplaylistmaxresults = null;
                  var lightbox = false;
                  var parent = $(this).closest("a.html5galleryimglink");
                  if (parent.length <= 0) parent = $(this).parent();
                  var category = "";
                  if (parent.is("a")) {
                     src = parent.attr("href");
                     videoOgg = parent.data("ogg");
                     videoWebm = parent.data("webm");
                     link = parent.data("link");
                     linktarget = parent.data("linktarget");
                     poster = parent.data("poster");
                     if (!isNaN(parent.data("width"))) width = parent.data("width");
                     if (!isNaN(parent.data("height"))) height = parent.data("height");
                     hd = parent.data("hd");
                     hdogg = parent.data("hdogg");
                     hdwebm = parent.data("hdwebm");
                     lightboxwidth = parent.data("lightboxwidth");
                     lightboxheight = parent.data("lightboxheight");
                     youtubeapikey = parent.data("youtubeapikey");
                     youtubeplaylistid = parent.data("youtubeplaylistid");
                     youtubeplaylistmaxresults = parent.data("youtubeplaylistmaxresults");
                     lightbox = parent.hasClass("html5gallerylightbox");
                     category = parent.data("category")
                  }
                  var mediaType = parent.data("mediatype") ? parent.data("mediatype") : instance.checkType(src);
                  var vtt = parent.data("vtt") ? parent.data("vtt") : "";
                  var vttlang = parent.data("vttlang") ? parent.data("vttlang") : instance.options.vttlang;
                  var vttlabel = parent.data("vttlabel") ? parent.data("vttlabel") : instance.options.vttlabel;
                  instance.elemArray.push(new Array(instance.elemArray.length, imgsrc, src, videoOgg, videoWebm, link, linktarget, title,
                     information, mediaType, width, height, poster, hd, hdogg, hdwebm, duration, lightboxwidth, lightboxheight, youtubeapikey, youtubeplaylistid, youtubeplaylistmaxresults, lightbox, width, height, alt, vtt, vttlang, vttlabel, category))
               })
            },
            getYouTubePlaylist: function (youtubeapikey, youtubeplaylistid, youtubeplaylistmaxresults, index, onsuccess, instance, pagetoken, category) {
               if (index >= 0) instance.elemArray.splice(index, 1);
               var youtube_url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=" + youtubeplaylistid +
                  "&key=" + youtubeapikey;
               if (youtubeplaylistmaxresults)
                  if (youtubeplaylistmaxresults > 50) youtube_url += "&maxResults=50";
                  else youtube_url += "&maxResults=" + youtubeplaylistmaxresults;
               if (pagetoken) youtube_url += "&pageToken=" + pagetoken;
               var all_done = true;
               $.getJSON(youtube_url, function (data) {
                  if (data && data.items)
                     for (var i = 0; i < data.items.length; i++) {
                        var video_id = data.items[i]["snippet"]["resourceId"]["videoId"];
                        var poster_image = "https://img.youtube.com/vi/" + video_id + "/" + instance.options.youtubeimage;
                        if (instance.options.youtubeplaylistusemaxres &&
                           data.items[i]["snippet"]["thumbnails"] && data.items[i]["snippet"]["thumbnails"]["maxres"]) poster_image = data.items[i]["snippet"]["thumbnails"]["maxres"]["url"];
                        var new_item = new Array(i, "https://img.youtube.com/vi/" + video_id + "/" + instance.options.youtubethumb, "https://www.youtube.com/embed/" + video_id, null, null, null, null, data.items[i]["snippet"]["title"], data.items[i]["snippet"]["description"], TYPE_VIDEO_YOUTUBE, 640, 480, poster_image, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                           null, null, category);
                        if (index >= 0) {
                           instance.elemArray.splice(index, 0, new_item);
                           index++
                        } else instance.elemArray.push(new_item)
                     }
                  if (data && data.nextPageToken && youtubeplaylistmaxresults && youtubeplaylistmaxresults > 50) {
                     all_done = false;
                     instance.getYouTubePlaylist(youtubeapikey, youtubeplaylistid, youtubeplaylistmaxresults - 50, index, onsuccess, instance, data.nextPageToken, category)
                  }
               }).always(function () {
                  if (all_done) onsuccess(instance)
               })
            },
            processElemArray: function (instance) {
               var found = false;
               for (var i = 0; i < instance.elemArray.length; i++)
                  if (!instance.elemArray[i][ELEM_ALT]) instance.elemArray[i][ELEM_ALT] =
                     instance.elemArray[i][ELEM_TITLE];
               for (var i = 0; i < instance.elemArray.length; i++)
                  if (instance.elemArray[i][ELEM_TYPE] == TYPE_YOUTUBE_PLAYLIST)
                     if (instance.elemArray[i][ELEM_YOUTUBEAPIKEY] && instance.elemArray[i][ELEM_YOUTUBEPLAYLISTID]) {
                        found = true;
                        break
                     } if (found) instance.getYouTubePlaylist(instance.elemArray[i][ELEM_YOUTUBEAPIKEY], instance.elemArray[i][ELEM_YOUTUBEPLAYLISTID], instance.elemArray[i][ELEM_YOUTUBEPLAYLISTMAXRESULTS], i, instance.processElemArray, instance, null, instance.elemArray[i][ELEM_CATEGORY]);
               else instance.init(instance)
            },
            createMarkup: function () {
               this.$gallery = jQuery("" + "<div class='html5gallery-container-" + this.id + "'>" + "<div class='html5gallery-box-" + this.id + "'>" + "<div class='html5gallery-elem-" + this.id + "'></div>" + "<div class='html5gallery-title-" + this.id + "'></div>" + "<div class='html5gallery-timer-" + this.id + "'></div>" + "<div class='html5gallery-viral-" + this.id + "'></div>" + "<div class='html5gallery-toolbox-" + this.id + "'>" + "<div class='html5gallery-toolbox-bg-" + this.id + "'></div>" + "<div class='html5gallery-toolbox-buttons-" +
                  this.id + "'>" + "<div class='html5gallery-play-" + this.id + "'></div>" + "<div class='html5gallery-pause-" + this.id + "'></div>" + "<div class='html5gallery-left-" + this.id + "'></div>" + "<div class='html5gallery-right-" + this.id + "'></div>" + "<div class='html5gallery-lightbox-" + this.id + "'></div>" + "</div>" + "</div>" + "</div>" + "<div class='html5gallery-car-" + this.id + "'>" + "<div class='html5gallery-car-list-" + this.id + "'>" + "<div class='html5gallery-car-mask-" + this.id + "'>" + "<div class='html5gallery-thumbs-" + this.id + "'></div>" +
                  "</div>" + "<div class='html5gallery-car-slider-bar-" + this.id + "'>" + "<div class='html5gallery-car-slider-bar-top-" + this.id + "'></div>" + "<div class='html5gallery-car-slider-bar-middle-" + this.id + "'></div>" + "<div class='html5gallery-car-slider-bar-bottom-" + this.id + "'></div>" + "</div>" + "<div class='html5gallery-car-left-" + this.id + "'></div>" + "<div class='html5gallery-car-right-" + this.id + "'></div>" + "<div class='html5gallery-car-slider-" + this.id + "'></div>" + "</div>" + "</div>" + "</div>");
               this.$gallery.appendTo(this.container);
               if (!this.options.socialurlforeach) this.createSocialMedia();
               if (this.options.enablega4 && this.options.ga4account && typeof window.gtag !== "function") {
                  window.dataLayer = window.dataLayer || [];
                  window.gtag = function () {
                     dataLayer.push(arguments)
                  };
                  window.gtag("js", new Date);
                  window.gtag("config", this.options.ga4account);
                  $.getScript("https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(this.options.ga4account))
               }
               if (this.options.googleanalyticsaccount && !window._gaq) {
                  window._gaq = window._gaq || [];
                  window._gaq.push(["_setAccount",
                     this.options.googleanalyticsaccount
                  ]);
                  window._gaq.push(["_trackPageview"]);
                  $.getScript("https://ssl.google-analytics.com/ga.js")
               }
            },
            createSocialMedia: function () {
               $(".html5gallery-viral-" + this.id, this.$gallery).empty();
               var elemUrl = window.location.href;
               if (this.options.socialurlforeach) elemUrl += (window.location.href.indexOf("?") < 0 ? "?" : "&") + "html5galleryid=" + this.elemArray[this.curElem][ELEM_ID];
               if (this.options.showsocialmedia && this.options.showfacebooklike) {
                  var facebook = "<div style='display:block; float:left; width:110px; height:21px;'><iframe src='" +
                     "https://www.facebook.com/plugins/like.php?href=";
                  if (this.options.facebooklikeurl && this.options.facebooklikeurl.length > 0) facebook += encodeURIComponent(this.options.facebooklikeurl);
                  else facebook += elemUrl;
                  facebook += "&send=false&layout=button_count&width=450&show_faces=false&action=like&colorscheme=light&font&height=21' scrolling='no' frameborder='0' style='border:none;;overflow:hidden; width:110px; height:21px;' allowTransparency='true'></iframe></div>";
                  $(".html5gallery-viral-" +
                     this.id, this.$gallery).append(facebook)
               }
               if (this.options.showsocialmedia && this.options.showtwitter) {
                  var twitter = "<div style='display:block; float:left; width:110px; height:21px;'><a href='https://twitter.com/share' class='twitter-share-button'";
                  if (this.options.twitterurl && this.options.twitterurl.length > 0) twitter += " data-url='" + this.options.twitterurl + "'";
                  else twitter += " data-url='" + elemUrl + "'";
                  if (this.options.twitterusername && this.options.twitterusername.length > 0) twitter += " data-via='" + this.options.twittervia +
                     "' data-related='" + this.options.twitterusername + "'";
                  twitter += ">Tweet</a></div>";
                  $(".html5gallery-viral-" + this.id, this.$gallery).append(twitter);
                  $.getScript("https://platform.twitter.com/widgets.js")
               }
               if (this.options.showsocialmedia && this.options.showgoogleplus) {
                  var googlePlus = "<div style='display:block; float:left; width:100px; height:21px;'><div class='g-plusone' data-size='medium'";
                  if (this.options.googleplusurl && this.options.googleplusurl.length > 0) googlePlus += " data-href='" + this.options.googleplusurl +
                     "'";
                  else googlePlus += " data-href='" + elemUrl + "'";
                  googlePlus += "></div></div>";
                  $(".html5gallery-viral-" + this.id, this.$gallery).append(googlePlus);
                  $.getScript("https://apis.google.com/js/plusone.js")
               }
            },
            playGallery: function () {
               var instance = this;
               $(".html5gallery-play-" + instance.id, instance.$gallery).hide();
               $(".html5gallery-pause-" + instance.id, instance.$gallery).show();
               instance.isPaused = false;
               var slideshowinterval = instance.elemArray[instance.curElem][ELEM_DURATION] ? instance.elemArray[instance.curElem][ELEM_DURATION] :
                  instance.options.slideshowinterval;
               instance.slideshowTimeout.setInterval(slideshowinterval);
               instance.slideshowTimeout.start();
               $(".html5gallery-timer-" + instance.id, instance.$gallery).css({
                  width: 0
               })
            },
            pauseGallery: function () {
               var instance = this;
               $(".html5gallery-play-" + instance.id, instance.$gallery).show();
               $(".html5gallery-pause-" + instance.id, instance.$gallery).hide();
               instance.isPaused = true;
               instance.slideshowTimeout.stop();
               $(".html5gallery-timer-" + instance.id, instance.$gallery).css({
                  width: 0
               })
            },
            createSliderTimeout: function () {
               var instance =
                  this;
               instance.slideshowTimeout = new HTML5GalleryTimer(instance.options.slideshowinterval, function () {
                  instance.slideRun(-1)
               }, instance.options.showtimer ? function (percent) {
                  instance.updateTimer(percent)
               } : null);
               if (instance.options.pauseonmouseover) $(".html5gallery-elem-" + this.id, this.$gallery).hover(function () {
                  if (!instance.isPaused) instance.slideshowTimeout.pause()
               }, function () {
                  if (!instance.isPaused) instance.slideshowTimeout.resume(false)
               })
            },
            updateTimer: function (percent) {
               if (this.isFullscreen) {
                  var w = Math.max(0,
                     Math.floor($(".html5gallery-fullscreen-elem-wrapper-" + this.id, this.$fullscreen).width() * percent));
                  $(".html5gallery-fullscreen-timer-" + this.id, this.$fullscreen).css({
                     width: w + "px"
                  })
               } else {
                  var w = Math.max(0, Math.floor($(".html5gallery-elem-" + this.id, this.$gallery).width() * percent));
                  $(".html5gallery-timer-" + this.id, this.$gallery).css({
                     width: w + "px"
                  })
               }
            },
            createEvents: function () {
               var instance = this;
               $(".html5gallery-play-" + this.id, this.$gallery).click(function () {
                  instance.playGallery()
               });
               $(".html5gallery-pause-" +
                  this.id, this.$gallery).click(function () {
                  instance.pauseGallery()
               });
               $(".html5gallery-lightbox-" + this.id, this.$gallery).click(function () {
                  instance.goFullscreen()
               });
               $(".html5gallery-left-" + this.id, this.$gallery).click(function () {
                  instance.slideRun(-2, true)
               });
               $(".html5gallery-right-" + this.id, this.$gallery).click(function () {
                  instance.slideRun(-1, true)
               });
               if (instance.options.enabletouchswipe) {
                  var preventBrowser = instance.options.isAndroid && instance.options.enabletouchswipeonandroid ? true : false;
                  $(".html5gallery-box-" +
                     this.id, this.$gallery).touchSwipe({
                     preventWebBrowser: preventBrowser,
                     swipeLeft: function () {
                        if (!instance.disableTouchSwipe) instance.slideRun(-1, true)
                     },
                     swipeRight: function () {
                        if (!instance.disableTouchSwipe) instance.slideRun(-2, true)
                     }
                  })
               }
               var isTouch = "ontouchstart" in window;
               if (!isTouch || !instance.options.disablehovereventontouch) {
                  $(".html5gallery-box-" + this.id, this.$gallery).mousemove(function () {
                     if (instance.options.imagetoolboxmode == "mouseover") {
                        var type = instance.elemArray[instance.curElem][ELEM_TYPE];
                        if (instance.options.showimagetoolbox ==
                           "always" || instance.options.showimagetoolbox == "image" && type == TYPE_IMAGE) instance.showimagetoolbox(type, true)
                     }
                     if (instance.options.titleoverlay && instance.options.titleautohide && !(instance.options.hidetitlewhenvideoisplaying && instance.isVideoPlaying)) {
                        $(".html5gallery-title-" + instance.id, instance.$gallery).show();
                        clearTimeout(instance.hideTitleTimeout);
                        instance.hideTitleTimeout = setTimeout(function () {
                           $(".html5gallery-title-" + instance.id, instance.$gallery).fadeOut()
                        }, 3E3)
                     }
                  });
                  $(".html5gallery-box-" + this.id,
                     this.$gallery).hover(function () {
                     instance.onSlideshowOver();
                     if (instance.options.imagetoolboxmode == "mouseover") {
                        var type = instance.elemArray[instance.curElem][ELEM_TYPE];
                        if (instance.options.showimagetoolbox == "always" || instance.options.showimagetoolbox == "image" && type == TYPE_IMAGE) instance.showimagetoolbox(type)
                     }
                     if (instance.options.titleoverlay && instance.options.titleautohide && !(instance.options.hidetitlewhenvideoisplaying && instance.isVideoPlaying)) {
                        $(".html5gallery-title-" + instance.id, instance.$gallery).fadeIn();
                        clearTimeout(instance.hideTitleTimeout);
                        instance.hideTitleTimeout = setTimeout(function () {
                           $(".html5gallery-title-" + instance.id, instance.$gallery).fadeOut()
                        }, 3E3)
                     }
                  }, function () {
                     if (instance.options.imagetoolboxmode == "mouseover") instance.hideimagetoolbox();
                     if (instance.options.titleoverlay && instance.options.titleautohide) {
                        $(".html5gallery-title-" + instance.id, instance.$gallery).fadeOut();
                        clearTimeout(instance.hideTitleTimeout)
                     }
                  })
               }
               $(".html5gallery-car-left-" + this.id, this.$gallery).css({
                  "background-position": "-" +
                     String(this.options.carouselarrowwidth * 2) + "px 0px",
                  cursor: ""
               });
               $(".html5gallery-car-left-" + this.id, this.$gallery).data("disabled", true);
               $(".html5gallery-car-right-" + this.id, this.$gallery).css({
                  "background-position": "0px 0px"
               });
               $(".html5gallery-car-left-" + this.id, this.$gallery).click(function () {
                  if (!$(this).data("disabled")) {
                     instance.disableupdatecarousel = true;
                     instance.updateCarouselTimeout = setTimeout(function () {
                        instance.enableUpdateCarousel()
                     }, instance.options.updatecarouselinterval);
                     instance.carouselPrev()
                  }
               });
               $(".html5gallery-car-right-" + this.id, this.$gallery).click(function () {
                  if (!$(this).data("disabled")) {
                     instance.disableupdatecarousel = true;
                     instance.updateCarouselTimeout = setTimeout(function () {
                        instance.enableUpdateCarousel()
                     }, instance.options.updatecarouselinterval);
                     instance.carouselNext()
                  }
               });
               $(".html5gallery-car-slider-" + this.id, this.$gallery).on("mousedown", function (e) {
                  var dragged = $(this);
                  var y = dragged.offset().top - e.pageY;
                  $(document).on("mousemove.h5gallerydraggable", function (e) {
                     var t = y + e.pageY;
                     dragged.offset({
                        top: t
                     });
                     instance.disableupdatecarousel = true;
                     instance.updateCarouselTimeout = setTimeout(function () {
                        instance.enableUpdateCarousel()
                     }, instance.options.updatecarouselinterval);
                     instance.carouselSliderDrag(t);
                     e.preventDefault()
                  });
                  $(document).one("mouseup", function (e) {
                     $(this).off("mousemove.h5gallerydraggable")
                  })
               });
               $(".html5gallery-car-slider-bar-" + this.id, this.$gallery).click(function (event) {
                  instance.disableupdatecarousel = true;
                  instance.updateCarouselTimeout = setTimeout(function () {
                        instance.enableUpdateCarousel()
                     },
                     instance.options.updatecarouselinterval);
                  instance.carouselBarClicked(event)
               });
               if (this.options.skin == "vertical" || this.options.skin == "verticallight" || this.options.skin == "showcase" || this.options.skin == "verticalwithleft" || this.options.skin == "verticallightwithleft") $(".html5gallery-car-list-" + this.id, this.$gallery).on("DOMMouseScroll mousewheel wheel", function (event) {
                  var totalLength = instance.visibleElemLength * (instance.options.thumbheight + instance.options.thumbgap);
                  if (totalLength < instance.options.thumbMaskHeight) return;
                  var maxM = -1 * (totalLength - instance.options.thumbMaskHeight);
                  var dis = 0;
                  if (event.originalEvent)
                     if (event.originalEvent.wheelDeltaY) dis = event.originalEvent.wheelDeltaY;
                     else if (event.originalEvent.detail) dis = event.originalEvent.detail * -20;
                  else if (event.originalEvent.wheelDelta) dis = event.originalEvent.wheelDelta;
                  else if (event.originalEvent.deltaY)
                     if (instance.options.isFirefox) dis = event.originalEvent.deltaY * -10;
                     else dis = event.originalEvent.deltaY * -1;
                  var m1 = parseInt($(".html5gallery-thumbs-" + instance.id, instance.$gallery).css("marginTop")) +
                     dis;
                  if (m1 < 0 && m1 > maxM) event.preventDefault();
                  if (m1 > 0) m1 = 0;
                  if (m1 < maxM) m1 = maxM;
                  var pos = (instance.options.carouselSliderMax - instance.options.carouselSliderMin) * m1 / maxM;
                  $(".html5gallery-car-slider-" + instance.id, instance.$gallery).css({
                     top: pos
                  });
                  $(".html5gallery-thumbs-" + instance.id, instance.$gallery).css({
                     marginTop: m1
                  })
               });
               if (!("ontouchstart" in window)) {
                  $(".html5gallery-car-left-" + this.id, this.$gallery).hover(function () {
                     if (!$(this).data("disabled")) $(this).css({
                        "background-position": "-" + instance.options.carouselarrowwidth +
                           "px 0px"
                     })
                  }, function () {
                     if (!$(this).data("disabled")) $(this).css({
                        "background-position": "0px 0px"
                     })
                  });
                  $(".html5gallery-car-right-" + this.id, this.$gallery).hover(function () {
                     if (!$(this).data("disabled")) $(this).css({
                        "background-position": "-" + instance.options.carouselarrowwidth + "px 0px"
                     })
                  }, function () {
                     if (!$(this).data("disabled")) $(this).css({
                        "background-position": "0px 0px"
                     })
                  })
               }
               if ("ontouchstart" in window)
                  if (this.options.skin == "vertical" || this.options.skin == "verticallight" || this.options.skin == "showcase" ||
                     this.options.skin == "verticalwithleft" || this.options.skin == "verticallightwithleft") $(".html5gallery-car-" + this.id, this.$gallery).touchSwipe({
                     preventWebBrowser: true,
                     swipeTop: function (data) {
                        $(".html5gallery-car-right-" + instance.id, instance.$gallery).click()
                     },
                     swipeBottom: function () {
                        $(".html5gallery-car-left-" + instance.id, instance.$gallery).click()
                     },
                     instance: instance,
                     preventWebBrowserCallback: "verticalPreventWebBrowserCallback"
                  });
                  else $(".html5gallery-car-" + this.id, this.$gallery).touchSwipe({
                     preventWebBrowser: false,
                     swipeLeft: function (data) {
                        $(".html5gallery-car-right-" + instance.id, instance.$gallery).click()
                     },
                     swipeRight: function () {
                        $(".html5gallery-car-left-" + instance.id, instance.$gallery).click()
                     }
                  })
            },
            verticalPreventWebBrowserCallback: function (moveup) {
               var thumbPos = parseInt($(".html5gallery-thumbs-" + this.id, this.$gallery).css("margin-top"));
               if (moveup) return thumbPos > this.options.thumbMaskHeight - this.options.thumbTotalHeight;
               else return thumbPos < 0
            },
            createStyle: function () {
               switch (this.options.skin) {
                  case "vertical":
                  case "verticallight":
                  case "verticalwithleft":
                  case "verticallightwithleft":
                  case "showcase":
                     this.createStyleVertical();
                     break;
                  case "light":
                  case "horizontal":
                  case "darkness":
                  case "gallery":
                  case "mediapage":
                  default:
                     this.createStyleDefault()
               }
            },
            resizeStyleVertical: function () {
               if (!this.container.parent() || !this.container.parent().width()) return;
               var instance = this;
               this.visibleElemLength = this.elemArray.length;
               if (this.options.showcarousel && this.options.showcategory)
                  if (this.selectedcategory == "all") {
                     $(".html5gallery-tn-" + this.id).css({
                        display: "block"
                     });
                     $(".html5gallery-tn-" + this.id).removeClass("html5gallery-tn-hidden")
                  } else {
                     this.visibleElemLength =
                        0;
                     $(".html5gallery-tn-" + this.id).each(function () {
                        var match = false;
                        if ($(this).data("category")) {
                           var cats = String($(this).data("category")).split(":");
                           if ($.inArray(instance.selectedcategory, cats) >= 0) {
                              match = true;
                              instance.visibleElemLength++
                           }
                        }
                        $(this).css({
                           display: match ? "block" : "none"
                        });
                        if (!match) $(this).addClass("html5gallery-tn-hidden");
                        else $(this).removeClass("html5gallery-tn-hidden")
                     })
                  } this.options.containerWidth = this.container.parent().width();
               this.options.totalWidth = this.options.containerWidth;
               if (this.options.carouselposresponsive) {
                  var fullW =
                     $(window).width();
                  if (fullW < this.options.carouselposresponsiveonscreenwidth) this.options.carouselposition = "bottom";
                  else {
                     this.options.carouselposition = this.options.originalcarouselposition;
                     this.options.thumbwidth = this.options.originalthumbwidth
                  }
               }
               if (this.options.showcarousel)
                  if (this.options.carouselposition == "bottom") this.options.carouselWidth = this.options.width;
                  else this.options.carouselWidth = this.options.thumbwidth;
               if (this.options.carouselposition == "bottom") this.options.width = this.options.totalWidth -
                  2 * this.options.padding;
               else {
                  this.options.width = this.options.totalWidth - 2 * this.options.padding;
                  if (this.options.carouselWidth + this.options.carouselmargin > 0) this.options.width -= this.options.carouselWidth + this.options.carouselmargin
               }
               if (this.options.responsivefullscreen && this.container.parent().height() > 0) {
                  this.options.containerHeight = this.container.parent().height();
                  this.options.totalHeight = this.options.containerHeight;
                  if (this.options.carouselposition == "bottom") this.options.height = this.options.totalHeight -
                     (this.options.headerHeight + 2 * this.options.padding + this.options.carouselheight);
                  else this.options.height = this.options.totalHeight - (this.options.headerHeight + 2 * this.options.padding)
               } else {
                  this.options.height = Math.round(this.options.width * this.options.originalHeight / this.options.originalWidth);
                  if (this.options.carouselposition == "bottom") this.options.totalHeight = this.options.height + this.options.headerHeight + 3 * this.options.padding + this.options.carouselHeight;
                  else this.options.totalHeight = this.options.height +
                     this.options.headerHeight + 2 * this.options.padding;
                  this.options.containerHeight = this.options.totalHeight
               }
               this.container.css({
                  "width": this.options.containerWidth,
                  "height": this.options.containerHeight
               });
               this.options.boxWidth = this.options.width;
               this.options.boxHeight = this.options.height + this.options.headerHeight;
               this.options.boxLeft = this.options.padding;
               if (this.options.slideshadow) this.options.boxWidth += 8;
               if (this.options.showcarousel) {
                  if (this.options.carouselposition == "bottom") {
                     this.options.carouselWidth =
                        this.options.width;
                     this.options.carouselHeight = this.options.carouselheight;
                     this.options.carouselLeft = this.options.padding;
                     this.options.carouselTop = this.options.height + this.options.headerHeight + 2 * this.options.padding;
                     this.options.carAreaLength = this.options.carouselHeight;
                     this.options.carouselSlider = Math.floor(this.options.carAreaLength / (this.options.thumbheight + this.options.thumbgap)) < this.visibleElemLength;
                     this.options.thumbwidth = this.options.width;
                     if (this.options.carouselSlider) this.options.thumbwidth -=
                        20;
                     this.options.carTop = this.options.showcategory ? this.options.categoryheight : 0;
                     if (this.options.showcategory) this.options.carouselHeight += this.options.categoryheight;
                     this.options.totalHeight = this.options.height + this.options.headerHeight + 3 * this.options.padding + this.options.carouselHeight
                  } else {
                     this.options.carouselWidth = this.options.thumbwidth;
                     this.options.carouselHeight = this.options.height + this.options.headerHeight;
                     this.options.carTop = this.options.showcategory ? this.options.categoryheight : 0;
                     this.options.carBottom =
                        0;
                     this.options.carAreaLength = this.options.carouselHeight - this.options.carTop - this.options.carBottom;
                     this.options.carouselSlider = Math.floor(this.options.carAreaLength / (this.options.thumbheight + this.options.thumbgap)) < this.visibleElemLength;
                     if (this.options.carouselSlider) {
                        this.options.carouselWidth += 20;
                        this.options.width -= 20;
                        this.options.height = Math.round(this.options.width * this.options.originalHeight / this.options.originalWidth);
                        this.options.boxWidth = this.options.width;
                        this.options.boxHeight = this.options.height +
                           this.options.headerHeight;
                        this.options.carouselHeight = this.options.height + this.options.headerHeight;
                        this.options.totalHeight = this.options.height + this.options.headerHeight + 2 * this.options.padding;
                        this.options.containerHeight = this.options.totalHeight;
                        if (this.options.slideshadow) this.options.boxWidth += 8;
                        this.container.css({
                           "height": this.options.containerHeight
                        });
                        if (this.options.showcategory) this.options.carAreaLength = this.options.carouselHeight - this.options.categoryheight
                     }
                     if (this.options.carouselposition ==
                        "left") {
                        this.options.boxLeft = this.options.padding + this.options.carouselWidth + this.options.carouselmargin;
                        this.options.carouselLeft = this.options.padding
                     } else this.options.carouselLeft = this.options.padding + this.options.width + this.options.carouselmargin;
                     this.options.carouselTop = this.options.padding
                  }
                  $(".html5gallery-car-mask-" + this.id).css({
                     width: this.options.thumbwidth + "px"
                  });
                  $(".html5gallery-tn-" + this.id).css({
                     width: this.options.thumbwidth + "px"
                  });
                  $(".html5gallery-tn-selected-" + this.id).css({
                     width: this.options.thumbwidth +
                        "px"
                  });
                  $(".html5gallery-car-slider-bar-" + this.id).css({
                     left: String(this.options.thumbwidth + 6) + "px"
                  });
                  if (this.options.isMobile || this.isTouch && this.options.splitvsliderontouch) {
                     $(".html5gallery-car-left-" + this.id).css({
                        left: String(this.options.thumbwidth + 5) + "px"
                     });
                     $(".html5gallery-car-right-" + this.id).css({
                        left: String(this.options.thumbwidth + 5) + "px"
                     })
                  } else $(".html5gallery-car-slider-" + this.id).css({
                     left: String(this.options.thumbwidth + 5) + "px"
                  });
                  var titleWidth = this.options.thumbwidth - 3 * this.options.thumbmargin;
                  if (this.options.thumbshowimage) titleWidth -= this.options.thumbimagewidth + 2 * this.options.thumbimageborder;
                  if (this.options.thumbshowtitle) $("head").append("<style type='text/css' data-creator='html5gallery'>.html5gallery-tn-title-" + this.id + " {width: " + titleWidth + "px;}</style>")
               }
               $(".html5gallery-container-" + this.id).css({
                  width: this.options.totalWidth + "px",
                  height: this.options.totalHeight + "px"
               });
               $(".html5gallery-box-" + this.id).css({
                  width: this.options.boxWidth + "px",
                  height: this.options.boxHeight + "px",
                  left: this.options.boxLeft +
                     "px"
               });
               var type = this.elemArray[this.curElem][ELEM_TYPE];
               if (type == TYPE_IMAGE || this.showingPoster) {
                  var imageWidth = this.showingPoster ? this.elemArray[this.curElem][ELEM_POSTERWIDTH] : this.elemArray[this.curElem][ELEM_WIDTH];
                  var imageHeight = this.showingPoster ? this.elemArray[this.curElem][ELEM_POSTERHEIGHT] : this.elemArray[this.curElem][ELEM_HEIGHT];
                  var scale;
                  if (this.isFullscreen) {
                     var fullW = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) :
                        this.fullscreenWidth;
                     var fullH = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : this.fullscreenHeight;
                     scale = Math.min(fullW / imageWidth, fullH / imageHeight);
                     scale = scale > 1 ? 1 : scale
                  } else if (this.options.resizemode == "fill") scale = Math.max(this.options.width / imageWidth, this.options.height / imageHeight);
                  else scale = Math.min(this.options.width / imageWidth, this.options.height / imageHeight);
                  var w = Math.round(scale * imageWidth);
                  var h = Math.round(scale *
                     imageHeight);
                  var w1 = this.isFullscreen ? w : this.options.width;
                  var h1 = this.isFullscreen ? h : this.options.height;
                  var l = Math.round(w1 / 2 - w / 2);
                  var t = Math.round(h1 / 2 - h / 2);
                  if (this.isFullscreen) this.adjustFullscreen(w1, h1, true);
                  $(".html5gallery-elem-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-img-" + this.id).css({
                     width: w1 + "px",
                     height: h1 + "px"
                  });
                  $(".html5gallery-elem-image-" + this.id).css({
                     width: w + "px",
                     height: h + "px",
                     top: t + "px",
                     left: l + "px"
                  })
               } else if (type == TYPE_IFRAME || type == TYPE_VIDEO_FLASH ||
                  type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM || type == TYPE_VIDEO_YOUTUBE || type == TYPE_VIDEO_VIMEO || type == TYPE_EMBED_VIDEO) {
                  var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
                  var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
                  var w1, h1;
                  if (this.isFullscreen) {
                     var fullW = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : this.fullscreenWidth;
                     var fullH = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT],
                        this.fullscreenHeight) : this.fullscreenHeight;
                     scale = Math.min(fullW / dataW, fullH / dataH);
                     scale = scale > 1 ? 1 : scale;
                     w1 = Math.round(scale * dataW);
                     h1 = Math.round(scale * dataH);
                     this.adjustFullscreen(w1, h1, true)
                  } else {
                     w1 = this.options.width;
                     h1 = this.options.height
                  }
                  $(".html5gallery-elem-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-video-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-video-container-" + this.id).css({
                     "width": "100%",
                     "height": "100%"
                  });
                  $(".html5gallery-elem-video-container-" +
                     this.id).find("video").css({
                     "width": "100%",
                     "height": "100%"
                  });
                  $("#html5gallery-elem-video-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $("#html5gallery-elem-video-" + this.id).attr("width", w1);
                  $("#html5gallery-elem-video-" + this.id).attr("height", h1);
                  $(".html5gallery-elem-video-" + this.id).find("iframe").attr("width", w1);
                  $(".html5gallery-elem-video-" + this.id).find("iframe").attr("height", h1);
                  $("#html5gallery-elem-video-" + this.id).find("iframe").attr("width", w1);
                  $("#html5gallery-elem-video-" + this.id).find("iframe").attr("height",
                     h1);
                  $(".html5gallery-elem-iframe-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-iframe-" + this.id).find("iframe").attr("width", w1);
                  $(".html5gallery-elem-iframe-" + this.id).find("iframe").attr("height", h1)
               }
               var titleTop = 0;
               var socialTop = 0;
               if (this.options.headerpos == "bottom") {
                  titleTop = this.options.titleoverlay ? this.options.height - this.options.titleheight : this.options.height;
                  socialTop = this.options.titleoverlay ? this.options.height : this.options.height + this.options.titleheight
               }
               var titleWidth =
                  this.options.slideshadow ? this.options.boxWidth - 8 : this.options.boxWidth;
               $(".html5gallery-title-" + this.id).css({
                  width: titleWidth + "px"
               });
               if (!this.options.titleoverlay) $(".html5gallery-title-" + this.id).css({
                  top: titleTop + "px"
               });
               $(".html5gallery-viral-" + this.id).css({
                  top: socialTop + "px"
               });
               $(".html5gallery-timer-" + this.id).css({
                  top: String(this.options.elemTop + this.options.height - 2) + "px"
               });
               if (this.options.showcarousel) {
                  $(".html5gallery-car-" + this.id).css({
                     width: this.options.carouselWidth + "px",
                     height: this.options.carouselHeight +
                        "px",
                     top: this.options.carouselTop + "px",
                     left: this.options.carouselLeft + "px",
                     top: this.options.carouselTop + "px"
                  });
                  $(".html5gallery-car-list-" + this.id).css({
                     top: this.options.carTop + "px",
                     height: String(this.options.carAreaLength) + "px",
                     width: this.options.carouselWidth + "px"
                  });
                  $(".html5gallery-thumbs-" + this.id).css({
                     height: String(this.visibleElemLength * (this.options.thumbheight + this.options.thumbgap)) + "px"
                  });
                  this.options.thumbShowNum = Math.floor(this.options.carAreaLength / (this.options.thumbheight + this.options.thumbgap));
                  if (this.options.thumbShowNum < 1) this.options.thumbShowNum = 1;
                  this.options.thumbMaskHeight = this.options.thumbShowNum * this.options.thumbheight + (this.options.thumbShowNum - 1) * this.options.thumbgap;
                  this.options.thumbTotalHeight = this.visibleElemLength * this.options.thumbheight + (this.visibleElemLength - 1) * this.options.thumbgap;
                  if (this.options.carouselSlider) {
                     this.options.carouselSliderMin = 0;
                     this.options.carouselSliderMax = this.options.thumbMaskHeight - 54;
                     $(".html5gallery-car-slider-bar-" + this.id).css({
                        height: this.options.thumbMaskHeight +
                           "px"
                     });
                     $(".html5gallery-car-slider-bar-middle-" + this.id).css({
                        height: String(this.options.thumbMaskHeight - 32) + "px"
                     });
                     if (this.options.isMobile || this.isTouch && this.options.splitvsliderontouch) $(".html5gallery-car-right-" + this.id).css({
                        top: String(this.options.thumbMaskHeight - 35) + "px"
                     });
                     $(".html5gallery-car-slider-bar-" + this.id).css({
                        display: "block"
                     });
                     $(".html5gallery-car-left-" + this.id).css({
                        display: "block"
                     });
                     $(".html5gallery-car-right-" + this.id).css({
                        display: "block"
                     });
                     $(".html5gallery-car-slider-" + this.id).css({
                        display: "block"
                     })
                  }
                  var maskTop =
                     0;
                  if (this.options.carouselNavButton) maskTop = Math.round(this.options.carAreaLength / 2 - this.options.thumbMaskHeight / 2);
                  $(".html5gallery-car-mask-" + this.id).css({
                     top: maskTop + "px",
                     height: this.options.thumbMaskHeight + "px"
                  });
                  if (this.options.carouselposition == "bottom") {
                     var diff = this.options.thumbMaskHeight - this.options.carAreaLength;
                     $(".html5gallery-container-" + this.id).css({
                        height: String(this.options.totalHeight + diff) + "px"
                     });
                     $(".html5gallery-car-" + this.id).css({
                        height: String(this.options.carouselHeight +
                           diff) + "px"
                     });
                     $(".html5gallery-car-list-" + this.id).css({
                        height: this.options.thumbMaskHeight + "px"
                     })
                  }
                  this.carouselHighlight(this.curElem)
               }
            },
            createStyleVertical: function () {
               this.visibleElemLength = this.elemArray.length;
               this.options.originalcarouselposition = this.options.carouselposition;
               this.options.originalthumbwidth = this.options.thumbwidth;
               if (this.options.thumbshowtitle) this.options.thumbimagewidth = this.options.thumbheight - 2 * this.options.thumbimageborder - 4;
               else this.options.thumbimagewidth = this.options.thumbwidth -
                  2 * this.options.thumbimageborder - 4;
               this.options.thumbimageheight = this.options.thumbheight - 2 * this.options.thumbimageborder - 4;
               if (!this.options.showtitle) this.options.titleheight = 0;
               if (!this.options.showsocialmedia || !this.options.showfacebooklike && !this.options.showtwitter && !this.options.showgoogleplus) this.options.socialheight = 0;
               this.options.headerHeight = this.options.titleoverlay ? this.options.socialheight : this.options.titleheight + this.options.socialheight;
               this.options.boxWidth = this.options.width;
               this.options.boxHeight =
                  this.options.height + this.options.headerHeight;
               this.options.boxLeft = this.options.padding;
               this.options.boxTop = this.options.padding;
               if (this.options.slideshadow) this.options.boxWidth += 8;
               if (this.options.showcarousel)
                  if (this.options.carouselposition == "bottom") {
                     this.options.carouselWidth = this.options.width;
                     this.options.carouselHeight = this.options.carouselheight;
                     this.options.carouselLeft = this.options.padding;
                     this.options.carouselTop = this.options.height + this.options.headerHeight + 2 * this.options.padding;
                     this.options.carAreaLength =
                        this.options.carouselHeight;
                     this.options.carouselSlider = Math.floor(this.options.carAreaLength / (this.options.thumbheight + this.options.thumbgap)) < this.visibleElemLength;
                     this.options.thumbwidth = this.options.width;
                     if (this.options.carouselSlider) this.options.thumbwidth -= 20;
                     this.options.carTop = this.options.showcategory ? this.options.categoryheight : 0;
                     if (this.options.showcategory) this.options.carouselHeight += this.options.categoryheight
                  } else {
                     this.options.carouselWidth = this.options.thumbwidth;
                     this.options.carouselHeight =
                        this.options.height + this.options.headerHeight;
                     this.options.carTop = this.options.showcategory ? this.options.categoryheight : 0;
                     this.options.carBottom = 0;
                     this.options.carAreaLength = this.options.carouselHeight - this.options.carTop - this.options.carBottom;
                     this.options.carouselSlider = Math.floor(this.options.carAreaLength / (this.options.thumbheight + this.options.thumbgap)) < this.visibleElemLength;
                     if (this.options.carouselSlider) this.options.carouselWidth += 20;
                     if (this.options.carouselposition == "left") {
                        this.options.boxLeft =
                           this.options.padding + this.options.carouselWidth + this.options.carouselmargin;
                        this.options.carouselLeft = this.options.padding
                     } else this.options.carouselLeft = this.options.padding + this.options.width + this.options.carouselmargin;
                     this.options.carouselTop = this.options.padding
                  }
               else {
                  this.options.carouselWidth = 0;
                  this.options.carouselHeight = 0;
                  this.options.carouselLeft = 0;
                  this.options.carouselTop = 0;
                  this.options.carouselmargin = 0
               }
               if (this.options.carouselposition == "bottom") {
                  this.options.totalWidth = this.options.width +
                     2 * this.options.padding;
                  this.options.totalHeight = this.options.height + this.options.headerHeight + 2 * this.options.padding + this.options.carouselmargin + this.options.carouselHeight
               } else {
                  this.options.totalWidth = this.options.width + this.options.carouselWidth + this.options.carouselmargin + 2 * this.options.padding;
                  this.options.totalHeight = this.options.height + this.options.headerHeight + 2 * this.options.padding
               }
               this.options.containerWidth = this.options.totalWidth;
               this.options.containerHeight = this.options.totalHeight;
               if (this.options.responsive) {
                  this.options.originalWidth =
                     this.options.width;
                  this.options.originalHeight = this.options.height;
                  this.container.css({
                     "max-width": "100%"
                  })
               } else this.container.css({
                  "width": this.options.containerWidth,
                  "height": this.options.containerHeight
               });
               var titleTop = 0;
               var socialTop = 0;
               this.options.elemTop = 0;
               if (this.options.headerpos == "top") {
                  socialTop = 0;
                  titleTop = this.options.socialheight;
                  this.options.elemTop = this.options.headerHeight
               } else if (this.options.headerpos == "bottom") {
                  this.options.elemTop = 0;
                  titleTop = this.options.titleoverlay ? this.options.height -
                     this.options.titleheight : this.options.height;
                  socialTop = this.options.titleoverlay ? this.options.height : this.options.height + this.options.titleheight
               } else if (this.options.headerpos == "bottomoutside")
                  if (this.options.showcarousel) titleTop = this.options.height + this.options.carouselHeight;
                  else titleTop = this.options.height;
               var styleCss = "";
               $(".html5gallery-container-" + this.id).css({
                  display: "block",
                  position: "absolute",
                  left: 0,
                  top: 0,
                  width: this.options.totalWidth + "px",
                  height: this.options.totalHeight + "px",
                  "background-color": this.options.bgcolor
               });
               if (this.options.bgimage) $(".html5gallery-container-" + this.id).css({
                  background: "url('" + this.options.bgimage + "') center top"
               });
               if (this.options.galleryshadow) styleCss += " .html5gallery-container-" + this.id + " { -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}";
               $(".html5gallery-box-" + this.id).css({
                  display: "block",
                  position: "absolute",
                  "text-align": "center",
                  left: this.options.boxLeft + "px",
                  top: this.options.boxTop + "px",
                  width: this.options.boxWidth + "px",
                  height: this.options.boxHeight +
                     "px"
               });
               var viralPaddingTop = Math.round(this.options.socialheight / 2 - 12);
               styleCss += " .html5gallery-title-text-" + this.id + " " + this.options.titlecss + " .html5gallery-title-text-" + this.id + " " + this.options.titlecsslink + " .html5gallery-error-" + this.id + " " + this.options.errorcss;
               styleCss += " .html5gallery-description-text-" + this.id + " " + this.options.descriptioncss + " .html5gallery-description-text-" + this.id + " " + this.options.descriptioncsslink;
               styleCss += " .html5gallery-fullscreen-title-" + this.id + "" + this.options.lightboxtitlecss +
                  " .html5gallery-fullscreen-title-" + this.id + "" + this.options.lightboxtitlelinkcss;
               styleCss += " .html5gallery-fullscreen-description-" + this.id + "" + this.options.lightboxdescriptioncss + " .html5gallery-fullscreen-description-" + this.id + "" + this.options.lightboxdescriptionlinkcss;
               styleCss += " .html5gallery-viral-" + this.id + " {display:block; overflow:hidden; position:absolute; text-align:left; top:" + socialTop + "px; left:0px; width:" + this.options.boxWidth + "px; height:" + this.options.socialheight + "px; padding-top:" +
                  viralPaddingTop + "px;}";
               var titleWidth = this.options.slideshadow ? this.options.boxWidth - 8 : this.options.boxWidth;
               styleCss += " .html5gallery-title-" + this.id + " {display:" + (this.options.titleoverlay && this.options.titleautohide ? "none" : "block") + "; overflow:hidden; position:absolute; left:0px; width:" + titleWidth + "px; ";
               if (!this.options.titleoverlay) styleCss += "top:" + titleTop + "px; height:" + this.options.titleheight + "px; }";
               else if (this.options.headerpos == "top") styleCss += "top:0px; height:auto; }";
               else styleCss +=
                  "bottom:0px; height:auto; }";
               styleCss += " .html5gallery-timer-" + this.id + " {display:block; position:absolute; top:" + String(this.options.elemTop + this.options.height - 2) + "px; left:0px; width:0px; height:2px; background-color:#ccc; filter:alpha(opacity=60); opacity:0.6; }";
               $(".html5gallery-elem-" + this.id).css({
                  display: "block",
                  overflow: "hidden",
                  position: "absolute",
                  top: this.options.elemTop + "px",
                  left: 0,
                  width: this.options.boxWidth + "px",
                  height: this.options.height + "px"
               });
               if (this.options.isIE7 || this.options.isIE6) {
                  styleCss +=
                     " .html5gallery-loading-" + this.id + " {display:none; }";
                  styleCss += " .html5gallery-loading-center-" + this.id + " {display:none; }"
               } else {
                  styleCss += " .html5gallery-loading-" + this.id + " {display:block; position:absolute; top:4px; right:4px; width:100%; height:100%; background:url('" + this.options.skinfolder + "loading.gif') no-repeat top right;}";
                  styleCss += " .html5gallery-loading-center-" + this.id + " {display:block; position:absolute; top:0px; left:0px; width:100%; height:100%; background:url('" + this.options.skinfolder +
                     "loading_center.gif') no-repeat center center;}"
               }
               if (this.options.borderradius > 0) styleCss += " .html5gallery-elem-" + this.id + " { overflow:hidden; border-radius:" + this.options.borderradius + "px; -moz-border-radius:" + this.options.borderradius + "px; -webkit-border-radius:" + this.options.borderradius + "px;}";
               if (this.options.slideshadow) {
                  styleCss += " .html5gallery-title-" + this.id + " { padding:4px;}";
                  styleCss += " .html5gallery-timer-" + this.id + " { margin:4px;}";
                  styleCss += " .html5gallery-elem-" + this.id + " { overflow:hidden; padding:4px; -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}"
               }
               if (this.options.showcarousel) {
                  $(".html5gallery-car-" +
                     this.id).css({
                     position: "absolute",
                     display: "block",
                     overflow: "hidden",
                     width: this.options.carouselWidth + "px",
                     height: this.options.carouselHeight + "px",
                     left: this.options.carouselLeft + "px",
                     top: this.options.carouselTop + "px"
                  });
                  styleCss += " .html5gallery-car-list-" + this.id + " { position:absolute; display:block; overflow:hidden; top:" + this.options.carTop + "px; height:" + String(this.options.carAreaLength) + "px; left:0px; width:" + this.options.carouselWidth + "px; " + "}";
                  styleCss += ".html5gallery-thumbs-" + this.id + " {margin-top:0px; height:" +
                     String(this.visibleElemLength * (this.options.thumbheight + this.options.thumbgap)) + "px;}";
                  this.options.thumbShowNum = Math.floor(this.options.carAreaLength / (this.options.thumbheight + this.options.thumbgap));
                  if (this.options.thumbShowNum < 1) this.options.thumbShowNum = 1;
                  this.options.thumbMaskHeight = this.options.thumbShowNum * this.options.thumbheight + (this.options.thumbShowNum - 1) * this.options.thumbgap;
                  this.options.thumbTotalHeight = this.visibleElemLength * this.options.thumbheight + (this.visibleElemLength - 1) * this.options.thumbgap;
                  this.options.carouselSliderMin = 0;
                  this.options.carouselSliderMax = this.options.thumbMaskHeight - 54;
                  styleCss += " .html5gallery-car-slider-bar-" + this.id + " { position:absolute; display:" + (this.options.carouselSlider ? "block" : "none") + "; overflow:hidden; top:0px; height:" + this.options.thumbMaskHeight + "px; left:" + String(this.options.thumbwidth + 6) + "px; width:14px;}";
                  styleCss += " .html5gallery-car-slider-bar-top-" + this.id + " { position:absolute; display:block; top:0px; left:0px; width:14px; height:16px; background:url('" +
                     this.options.skinfolder + "bartop.png')}";
                  styleCss += " .html5gallery-car-slider-bar-middle-" + this.id + " { position:absolute; display:block; top:16px; left:0px; width:14px; height:" + String(this.options.thumbMaskHeight - 32) + "px; background:url('" + this.options.skinfolder + "bar.png')}";
                  styleCss += " .html5gallery-car-slider-bar-bottom-" + this.id + " { position:absolute; display:block; bottom:0px; left:0px; width:14px; height:16px; background:url('" + this.options.skinfolder + "barbottom.png')}";
                  if (this.options.isMobile ||
                     this.isTouch && this.options.splitvsliderontouch) styleCss += " .html5gallery-car-left-" + this.id + " { position:absolute; display:" + (this.options.carouselSlider ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:16px; height:35px; left:" + String(this.options.thumbwidth + 5) + "px; top:0px; background:url('" + this.options.skinfolder + "slidertop.png')} " + " .html5gallery-car-right-" + this.id + " { position:absolute; display:" + (this.options.carouselSlider ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:16px; height:35px; left:" +
                     String(this.options.thumbwidth + 5) + "px; top:" + String(this.options.thumbMaskHeight - 35) + "px; background:url('" + this.options.skinfolder + "sliderbottom.png')} ";
                  else styleCss += " .html5gallery-car-slider-" + this.id + " { position:absolute; display:" + (this.options.carouselSlider ? "block" : "none") + "; overflow:hidden; cursor:pointer; top:0px; height:54px; left:" + String(this.options.thumbwidth + 5) + "px; width:16px; background:url('" + this.options.skinfolder + "slider.png');}";
                  var maskTop = 0;
                  if (this.options.carouselNavButton) maskTop =
                     Math.round(this.options.carAreaLength / 2 - this.options.thumbMaskHeight / 2);
                  $(".html5gallery-car-mask-" + this.id).css({
                     position: "absolute",
                     display: "block",
                     overflow: "hidden",
                     top: maskTop + "px",
                     height: this.options.thumbMaskHeight + "px",
                     left: 0,
                     width: this.options.thumbwidth + "px"
                  });
                  var tabHeight = this.options.thumbheight;
                  if (!this.options.isIE) tabHeight = this.options.thumbheight - 2;
                  styleCss += " .html5gallery-tn-" + this.id + " { ";
                  $(".html5gallery-tn-" + this.id).css({
                     display: "block",
                     "margin-bottom": this.options.thumbgap +
                        "px",
                     "text-align": "center",
                     cursor: "pointer",
                     width: this.options.thumbwidth + "px",
                     height: tabHeight + "px",
                     overflow: "hidden"
                  });
                  if (this.options.carouselbgtransparent) styleCss += "background-color:transparent;";
                  else {
                     if (!this.options.isIE) styleCss += "border-top:1px solid " + this.options.carouseltopborder + "; border-bottom:1px solid " + this.options.carouselbottomborder + ";";
                     styleCss += "background-color: " + this.options.carouselbgcolorend + "; " + "background: " + this.options.carouselbgcolorend + " -webkit-gradient(linear, left top, left bottom, from(" +
                        this.options.carouselbgcolorstart + "), to(" + this.options.carouselbgcolorend + ")) no-repeat; " + "background: " + this.options.carouselbgcolorend + " -moz-linear-gradient(top, " + this.options.carouselbgcolorstart + ", " + this.options.carouselbgcolorend + ") no-repeat; " + "filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselbgcolorstart + ", endColorstr=" + this.options.carouselbgcolorend + ") no-repeat; " + "-ms-filter: 'progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselbgcolorstart +
                        ", endColorstr=" + this.options.carouselbgcolorend + ")' no-repeat;"
                  }
                  if (this.options.carouselbgimage) styleCss += "background:url('" + this.options.skinfolder + this.options.carouselbgimage + "') center top;";
                  styleCss += "}";
                  styleCss += " .html5gallery-tn-selected-" + this.id + " { display:block; margin-bottom:" + this.options.thumbgap + "px;text-align:center; cursor:pointer; width:" + this.options.thumbwidth + "px;height:" + tabHeight + "px;overflow:hidden;";
                  if (this.options.carouselbgtransparent) styleCss += "background-color:transparent;";
                  else {
                     if (!this.options.isIE) styleCss += "border-top:1px solid " + this.options.carouselhighlighttopborder + "; border-bottom:1px solid " + this.options.carouselhighlightbottomborder + ";";
                     styleCss += "background-color: " + this.options.carouselhighlightbgcolorend + "; " + "background: " + this.options.carouselhighlightbgcolorend + " -webkit-gradient(linear, left top, left bottom, from(" + this.options.carouselhighlightbgcolorstart + "), to(" + this.options.carouselhighlightbgcolorend + ")) no-repeat; " + "background: " + this.options.carouselhighlightbgcolorend +
                        " -moz-linear-gradient(top, " + this.options.carouselhighlightbgcolorstart + ", " + this.options.carouselhighlightbgcolorend + ") no-repeat; " + "filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselhighlightbgcolorstart + ", endColorstr=" + this.options.carouselhighlightbgcolorend + ") no-repeat; " + "-ms-filter: 'progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselhighlightbgcolorstart + ", endColorstr=" + this.options.carouselhighlightbgcolorend + ")' no-repeat;"
                  }
                  if (this.options.carouselbgimage) styleCss +=
                     "background:url('" + this.options.skinfolder + this.options.carouselbgimage + "') center top;";
                  styleCss += "}";
                  styleCss += " .html5gallery-tn-selected-" + this.id + " .html5gallery-tn-img-" + this.id + " {background-color:" + this.options.thumbimagebordercolor + ";}" + " .html5gallery-tn-" + this.id + " { filter:alpha(opacity=" + Math.round(this.options.thumbopacity * 100) + "); opacity:" + this.options.thumbopacity + "; } " + " .html5gallery-tn-selected-" + this.id + " { filter:alpha(opacity=100); opacity:1; } ";
                  var titleWidth = this.options.thumbwidth -
                     3 * this.options.thumbmargin;
                  if (this.options.thumbshowimage) {
                     titleWidth -= this.options.thumbimagewidth + 2 * this.options.thumbimageborder;
                     var imgLeft;
                     if (this.options.thumbshowtitle) imgLeft = this.options.thumbmargin;
                     else imgLeft = this.options.thumbwidth / 2 - (this.options.thumbimagewidth + 2 * this.options.thumbimageborder) / 2;
                     var imgTop = Math.round((this.options.thumbheight - 2) / 2 - (this.options.thumbimageheight + 2 * this.options.thumbimageborder) / 2);
                     styleCss += " .html5gallery-tn-img-" + this.id + " {display:block; overflow:hidden; float:left; margin-top:" +
                        imgTop + "px; margin-left:" + imgLeft + "px; width:" + String(this.options.thumbimagewidth + 2 * this.options.thumbimageborder) + "px;height:" + String(this.options.thumbimageheight + 2 * this.options.thumbimageborder) + "px;}"
                  } else styleCss += " .html5gallery-tn-img-" + this.id + " {display:none;}";
                  if (this.options.thumbshowtitle) {
                     styleCss += " .html5gallery-tn-title-" + this.id + " {display:block; overflow:hidden; float:left; margin-top:0px; margin-left:" + this.options.thumbmargin + "px; width:" + titleWidth + "px;height:" + String(this.options.thumbheight -
                        2) + "px;" + (this.options.thumbshowdescription ? "" : "line-height:" + String(this.options.thumbheight - 2) + "px;") + "}";
                     styleCss += " .html5gallery-tn-title-" + this.id + this.options.thumbtitlecss;
                     styleCss += " .html5gallery-tn-description-" + this.id + this.options.thumbdescriptioncss
                  } else {
                     styleCss += " .html5gallery-tn-title-" + this.id + " {display:none;}";
                     styleCss += " .html5gallery-tn-description-" + this.id + " {display:none;}"
                  }
                  this.carouselHighlight = function (index) {
                     $("#html5gallery-tn-" + this.id + "-" + index, this.$gallery).addClass("html5gallery-tn-selected-" +
                        this.id);
                     if (this.options.thumbShowNum >= this.visibleElemLength) {
                        $(".html5gallery-thumbs-" + this.id, this.$gallery).css({
                           "margin-top": 0
                        });
                        return
                     }
                     var pos = Math.floor(index / this.options.thumbShowNum) * this.options.thumbShowNum * (this.options.thumbheight + this.options.thumbgap);
                     if (pos >= this.options.thumbTotalHeight - this.options.thumbMaskHeight) pos = this.options.thumbTotalHeight - this.options.thumbMaskHeight;
                     var m1 = pos / (this.visibleElemLength * (this.options.thumbheight + this.options.thumbgap) - this.options.thumbMaskHeight);
                     m1 = m1 * (this.options.carouselSliderMax - this.options.carouselSliderMin);
                     $(".html5gallery-car-slider-" + this.id, this.$gallery).stop(true).animate({
                        top: m1
                     }, 300);
                     $(".html5gallery-thumbs-" + this.id, this.$gallery).stop(true).animate({
                        marginTop: -1 * pos
                     }, 300);
                     this.updateCarouseButtons(-pos)
                  };
                  this.carouselBarClicked = function (event) {
                     var $thumbContainer = $(".html5gallery-thumbs-" + this.id, this.$gallery);
                     var pos;
                     if (event.pageY > $(".html5gallery-car-slider-" + this.id, this.$gallery).offset().top) {
                        pos = -1 * parseInt($thumbContainer.css("margin-top")) +
                           this.options.thumbShowNum * (this.options.thumbheight + this.options.thumbgap);
                        if (pos >= this.options.thumbTotalHeight - this.options.thumbMaskHeight) pos = this.options.thumbTotalHeight - this.options.thumbMaskHeight
                     } else {
                        pos = -1 * parseInt($thumbContainer.css("margin-top")) - this.options.thumbShowNum * (this.options.thumbheight + this.options.thumbgap);
                        if (pos < 0) pos = 0
                     }
                     $thumbContainer.stop(true).animate({
                        marginTop: -pos
                     }, 500);
                     this.updateCarouseButtons(-pos);
                     var m1 = this.visibleElemLength * (this.options.thumbheight + this.options.thumbgap) -
                        this.options.thumbMaskHeight;
                     pos = pos * (this.options.carouselSliderMax - this.options.carouselSliderMin) / m1;
                     if (pos < this.options.carouselSliderMin) pos = this.options.carouselSliderMin;
                     if (pos > this.options.carouselSliderMax) pos = this.options.carouselSliderMax;
                     $(".html5gallery-car-slider-" + this.id, this.$gallery).stop(true).animate({
                        top: pos
                     }, 500)
                  };
                  this.carouselSliderDrag = function (offsetY) {
                     var pos = offsetY - $(".html5gallery-car-slider-bar-" + this.id, this.$gallery).offset().top;
                     if (pos < this.options.carouselSliderMin) pos =
                        this.options.carouselSliderMin;
                     if (pos > this.options.carouselSliderMax) pos = this.options.carouselSliderMax;
                     $(".html5gallery-car-slider-" + this.id, this.$gallery).css({
                        top: pos
                     });
                     var m1 = this.visibleElemLength * (this.options.thumbheight + this.options.thumbgap) - this.options.thumbMaskHeight;
                     m1 = m1 * pos / (this.options.carouselSliderMax - this.options.carouselSliderMin);
                     m1 = Math.round(m1 / (this.options.thumbheight + this.options.thumbgap));
                     m1 = -1 * m1 * (this.options.thumbheight + this.options.thumbgap);
                     $(".html5gallery-thumbs-" +
                        this.id, this.$gallery).stop(true).animate({
                        marginTop: m1
                     }, 300)
                  };
                  this.carouselPrev = function () {
                     var $thumbContainer = $(".html5gallery-thumbs-" + this.id, this.$gallery);
                     if (parseInt($thumbContainer.css("margin-top")) == 0) return;
                     else {
                        var pos = -1 * parseInt($thumbContainer.css("margin-top")) - this.options.thumbShowNum * (this.options.thumbheight + this.options.thumbgap);
                        if (pos < 0) pos = 0;
                        $thumbContainer.animate({
                           marginTop: -pos
                        }, 500, this.options.carouseleasing);
                        this.updateCarouseButtons(-pos)
                     }
                  };
                  this.carouselNext = function () {
                     var $thumbContainer =
                        $(".html5gallery-thumbs-" + this.id, this.$gallery);
                     if (parseInt($thumbContainer.css("margin-top")) == -(this.options.thumbTotalHeight - this.options.thumbMaskHeight)) return;
                     else {
                        var pos = -1 * parseInt($thumbContainer.css("margin-top")) + this.options.thumbShowNum * (this.options.thumbheight + this.options.thumbgap);
                        if (pos >= this.options.thumbTotalHeight - this.options.thumbMaskHeight) pos = this.options.thumbTotalHeight - this.options.thumbMaskHeight;
                        $thumbContainer.animate({
                           marginTop: -pos
                        }, 500, this.options.carouseleasing);
                        this.updateCarouseButtons(-pos)
                     }
                  };
                  this.updateCarouseButtons = function (pos) {
                     var $leftButton = $(".html5gallery-car-left-" + this.id, this.$gallery);
                     var $rightButton = $(".html5gallery-car-right-" + this.id, this.$gallery);
                     var rightMost = -1 * (this.options.thumbTotalHeight - this.options.thumbMaskHeight);
                     if (pos == 0) {
                        $leftButton.css({
                           "background-position": "-" + String(this.options.carouselarrowwidth * 2) + "px 0px",
                           cursor: ""
                        });
                        $leftButton.data("disabled", true)
                     } else if ($leftButton.data("disabled")) {
                        $leftButton.css({
                           "background-position": "0px 0px",
                           cursor: "pointer"
                        });
                        $leftButton.data("disabled", false)
                     }
                     if (pos == rightMost) {
                        $rightButton.css({
                           "background-position": "-" + String(this.options.carouselarrowwidth * 2) + "px 0px",
                           cursor: ""
                        });
                        $rightButton.data("disabled", true)
                     } else if ($rightButton.data("disabled")) {
                        $rightButton.css({
                           "background-position": "0px 0px",
                           cursor: "pointer"
                        });
                        $rightButton.data("disabled", false)
                     }
                  }
               } else $(".html5gallery-car-" + this.id).css({
                  display: "none"
               });
               styleCss += ".html5gallery-container-" + this.id + " div {box-sizing:content-box;}";
               styleCss +=
                  this.addCommonStyle();
               if (this.options.showcarousel && this.options.showcategory) {
                  var catSelect = '<div class="html5gallery-cat-selection-' + this.id + '">';
                  catSelect += '<select class="html5gallery-cat-dropdown-' + this.id + '">';
                  for (var i = 0; i < this.options.categorylist.length; i++) catSelect += "<option" + (this.selectedcategory == this.options.categorylist[i].slug ? " selected" : "") + ' value="' + this.options.categorylist[i].slug + '">' + this.options.categorylist[i].caption + "</option>";
                  catSelect += "</select>";
                  catSelect += "</div>";
                  $(".html5gallery-car-" + this.id).prepend(catSelect);
                  var instance = this;
                  $(".html5gallery-cat-dropdown-" + this.id).change(function () {
                     instance.selectedcategory = String($(this).val());
                     instance.resizeStyleVertical()
                  })
               }
               $("head").append("<style type='text/css' data-creator='html5gallery'>" + styleCss + "</style>")
            },
            resizeImageToolbox: function () {
               if (this.options.imagetoolboxstyle != "center") {
                  var buttonT = Math.round((this.options.headerpos == "bottom" || this.options.headerpos == "bottomoutside" ? 0 : this.options.headerHeight) +
                     this.options.height / 2 - 24);
                  var buttonB = buttonT + Math.round(this.options.height / 2) - 32;
                  var buttonR = this.options.boxWidth - 48;
                  var buttonR1 = buttonR;
                  var buttonR2 = this.options.showfullscreenbutton ? buttonR1 - 48 : buttonR1;
                  $(".html5gallery-play-" + this.id).css({
                     "top": buttonB + "px",
                     "left": buttonR2 + "px"
                  });
                  $(".html5gallery-pause-" + this.id).css({
                     "top": buttonB + "px",
                     "left": buttonR2 + "px"
                  });
                  $(".html5gallery-left-" + this.id).css({
                     "top": buttonT + "px"
                  });
                  $(".html5gallery-right-" + this.id).css({
                     "top": buttonT + "px",
                     "left": buttonR1 +
                        "px"
                  });
                  $(".html5gallery-lightbox-" + this.id).css({
                     "top": buttonB + "px",
                     "left": buttonR1 + "px"
                  })
               }
            },
            createImageToolbox: function () {
               if (this.elemArray.length <= 1) this.options.showplaybutton = this.options.showprevbutton = this.options.shownextbutton = false;
               if (this.options.showimagetoolbox != "never") {
                  var styleCss;
                  if (this.options.imagetoolboxstyle == "center") {
                     var toolboxH = 40;
                     styleCss = " .html5gallery-toolbox-" + this.id + " {display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; overflow:hidden; position:relative; margin:0px auto; text-align:center; height:" +
                        toolboxH + "px;}";
                     styleCss += " .html5gallery-toolbox-bg-" + this.id + " {display:block; left:0px; top:0px; width:100%; height:100%; position:absolute; filter:alpha(opacity=60); opacity:0.6; background-color:#222222; }";
                     styleCss += " .html5gallery-toolbox-buttons-" + this.id + " {display:block; margin:0px auto; height:100%;}";
                     styleCss += " .html5gallery-play-" + this.id + " { position:relative; float:left; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:32px; height:32px; margin-left:2px; margin-right:2px; margin-top:" +
                        Math.round(toolboxH / 2 - 16) + "px; background:url('" + this.options.skinfolder + "play.png') no-repeat top left; } ";
                     styleCss += " .html5gallery-pause-" + this.id + " { position:relative; float:left; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:32px; height:32px; margin-left:2px; margin-right:2px; margin-top:" + Math.round(toolboxH / 2 - 16) + "px; background:url('" + this.options.skinfolder + "pause.png') no-repeat top left; } ";
                     styleCss += " .html5gallery-left-" +
                        this.id + " { position:relative; float:left; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:32px; height:32px; margin-left:2px; margin-right:2px; margin-top:" + Math.round(toolboxH / 2 - 16) + "px; background:url('" + this.options.skinfolder + "prev.png') no-repeat top left; } ";
                     styleCss += " .html5gallery-right-" + this.id + " { position:relative; float:left; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:32px; height:32px; margin-left:2px; margin-right:2px; margin-top:" +
                        Math.round(toolboxH / 2 - 16) + "px; background:url('" + this.options.skinfolder + "next.png') no-repeat top left; } ";
                     styleCss += " .html5gallery-lightbox-" + this.id + " {position:relative; float:left; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; overflow:hidden; width:32px; height:32px; margin-left:2px; margin-right:2px; margin-top:" + Math.round(toolboxH / 2 - 16) + "px; background:url('" + this.options.skinfolder + "lightbox.png') no-repeat top left; } "
                  } else {
                     var buttonT = Math.round((this.options.headerpos ==
                        "bottom" ? 0 : this.options.headerHeight) + this.options.height / 2 - 24);
                     var buttonB = buttonT + Math.round(this.options.height / 2) - 32;
                     var buttonR = this.options.width - 54;
                     var buttonR1 = buttonR;
                     var buttonR2 = this.options.showfullscreenbutton ? buttonR1 - 48 : buttonR1;
                     styleCss = " .html5gallery-toolbox-" + this.id + " {display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + ";}";
                     styleCss += " .html5gallery-toolbox-bg-" + this.id + " {display:none;}";
                     styleCss += " .html5gallery-toolbox-buttons-" + this.id + " {display:block;}";
                     styleCss +=
                        " .html5gallery-play-" + this.id + " { position:absolute; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; top:" + buttonB + "px; left:" + buttonR2 + "px; width:48px; height:48px; background:url('" + this.options.skinfolder + "side_play.png') no-repeat top left;} ";
                     styleCss += " .html5gallery-pause-" + this.id + " { position:absolute; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; top:" + buttonB + "px; left:" + buttonR2 + "px; width:48px; height:48px; background:url('" +
                        this.options.skinfolder + "side_pause.png') no-repeat top left;} ";
                     styleCss += " .html5gallery-left-" + this.id + " { position:absolute; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; top:" + buttonT + "px; left:0px; width:48px; height:48px; background:url('" + this.options.skinfolder + "side_prev.png') no-repeat center center;} ";
                     styleCss += " .html5gallery-right-" + this.id + " { position:absolute; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; top:" +
                        buttonT + "px; left:" + buttonR1 + "px; width:48px; height:48px; background:url('" + this.options.skinfolder + "side_next.png')  no-repeat center center;} ";
                     styleCss += " .html5gallery-lightbox-" + this.id + " {position:absolute; display:" + (this.options.imagetoolboxmode == "show" ? "block" : "none") + "; cursor:pointer; top:" + buttonB + "px; left:" + buttonR1 + "px; width:48px; height:48px; background:url('" + this.options.skinfolder + "side_lightbox.png') no-repeat top left;} "
                  }
                  $(".html5gallery-play-" + this.id, this.$gallery).hover(function () {
                        $(this).css({
                           "background-position": "right top"
                        })
                     },
                     function () {
                        $(this).css({
                           "background-position": "left top"
                        })
                     });
                  $(".html5gallery-pause-" + this.id, this.$gallery).hover(function () {
                     $(this).css({
                        "background-position": "right top"
                     })
                  }, function () {
                     $(this).css({
                        "background-position": "left top"
                     })
                  });
                  $(".html5gallery-left-" + this.id, this.$gallery).hover(function () {
                     $(this).css({
                        "background-position": "right top"
                     })
                  }, function () {
                     $(this).css({
                        "background-position": "left top"
                     })
                  });
                  $(".html5gallery-right-" + this.id, this.$gallery).hover(function () {
                        $(this).css({
                           "background-position": "right top"
                        })
                     },
                     function () {
                        $(this).css({
                           "background-position": "left top"
                        })
                     });
                  $(".html5gallery-lightbox-" + this.id, this.$gallery).hover(function () {
                     $(this).css({
                        "background-position": "right top"
                     })
                  }, function () {
                     $(this).css({
                        "background-position": "left top"
                     })
                  });
                  $("head").append("<style type='text/css' data-creator='html5gallery'>" + styleCss + "</style>")
               }
               this.showimagetoolbox = function (type, noeffect) {
                  if (!this.options.showplaybutton && !this.options.showprevbutton && !this.options.shownextbutton && !this.options.showfullscreenbutton) return;
                  var instance = this;
                  clearTimeout(instance.hideToolboxTimeout);
                  instance.hideToolboxTimeout = setTimeout(function () {
                     instance.hideimagetoolbox()
                  }, 3E3);
                  if (this.options.imagetoolboxstyle == "center") {
                     var toolboxT = Math.round((this.options.headerpos == "bottom" ? 0 : this.options.headerHeight) + this.options.height / 2);
                     if (type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM || type == TYPE_VIDEO_YOUTUBE || type == TYPE_VIDEO_VIMEO || type == TYPE_EMBED_VIDEO) toolboxT += 45;
                     $(".html5gallery-toolbox-" + this.id, this.$gallery).css({
                        "top": toolboxT
                     });
                     var toolboxW = 0;
                     if (this.options.showplaybutton && (type == TYPE_IMAGE || this.options.showplaypausefullscreenforall && (!this.options.hideplaypausefullscreenwhenvideoisplaying || !this.isVideoPlaying))) {
                        toolboxW += 36;
                        if (this.isPaused) {
                           $(".html5gallery-play-" + this.id, this.$gallery).show();
                           $(".html5gallery-pause-" + this.id, this.$gallery).hide()
                        } else {
                           $(".html5gallery-play-" + this.id, this.$gallery).hide();
                           $(".html5gallery-pause-" + this.id, this.$gallery).show()
                        }
                     } else {
                        $(".html5gallery-play-" + this.id, this.$gallery).hide();
                        $(".html5gallery-pause-" + this.id, this.$gallery).hide()
                     }
                     if (this.options.showprevbutton) {
                        toolboxW += 36;
                        $(".html5gallery-left-" + this.id, this.$gallery).show()
                     } else $(".html5gallery-left-" + this.id, this.$gallery).hide();
                     if (this.options.shownextbutton) {
                        toolboxW += 36;
                        $(".html5gallery-right-" + this.id, this.$gallery).show()
                     } else $(".html5gallery-right-" + this.id, this.$gallery).hide();
                     if (this.options.showfullscreenbutton && (type == TYPE_IMAGE || this.options.showplaypausefullscreenforall && (!this.options.hideplaypausefullscreenwhenvideoisplaying ||
                           !this.isVideoPlaying))) {
                        toolboxW += 36;
                        $(".html5gallery-lightbox-" + this.id, this.$gallery).show()
                     } else $(".html5gallery-lightbox-" + this.id, this.$gallery).hide();
                     $(".html5gallery-toolbox-" + this.id, this.$gallery).css({
                        width: toolboxW + 16
                     });
                     $(".html5gallery-toolbox-buttons-" + this.id, this.$gallery).css({
                        width: toolboxW
                     })
                  } else {
                     if (this.options.showplaybutton && (type == TYPE_IMAGE || this.options.showplaypausefullscreenforall && (!this.options.hideplaypausefullscreenwhenvideoisplaying || !this.isVideoPlaying)))
                        if (this.isPaused) {
                           $(".html5gallery-play-" +
                              this.id, this.$gallery).show();
                           $(".html5gallery-pause-" + this.id, this.$gallery).hide()
                        } else {
                           $(".html5gallery-play-" + this.id, this.$gallery).hide();
                           $(".html5gallery-pause-" + this.id, this.$gallery).show()
                        }
                     else {
                        $(".html5gallery-play-" + this.id, this.$gallery).hide();
                        $(".html5gallery-pause-" + this.id, this.$gallery).hide()
                     }
                     if (this.options.showprevbutton) $(".html5gallery-left-" + this.id, this.$gallery).show();
                     else $(".html5gallery-left-" + this.id, this.$gallery).hide();
                     if (this.options.shownextbutton) $(".html5gallery-right-" +
                        this.id, this.$gallery).show();
                     else $(".html5gallery-right-" + this.id, this.$gallery).hide();
                     if (this.options.showfullscreenbutton && (type == TYPE_IMAGE || this.options.showplaypausefullscreenforall && (!this.options.hideplaypausefullscreenwhenvideoisplaying || !this.isVideoPlaying))) $(".html5gallery-lightbox-" + this.id, this.$gallery).show();
                     else $(".html5gallery-lightbox-" + this.id, this.$gallery).hide()
                  }
                  if (this.options.isIE678 || noeffect) $(".html5gallery-toolbox-" + this.id, this.$gallery).show();
                  else $(".html5gallery-toolbox-" +
                     this.id, this.$gallery).fadeIn()
               };
               this.hideimagetoolbox = function () {
                  if (this.options.imagetoolboxmode == "show") return;
                  clearTimeout(this.hideToolboxTimeout);
                  if (this.options.isIE678) $(".html5gallery-toolbox-" + this.id, this.$gallery).hide();
                  else $(".html5gallery-toolbox-" + this.id, this.$gallery).fadeOut()
               }
            },
            resizeStyleDefault: function () {
               if (!this.container.parent() || !this.container.parent().width()) return;
               var instance = this;
               this.options.containerWidth = this.container.parent().width();
               this.options.totalWidth =
                  this.options.containerWidth;
               this.options.width = this.options.totalWidth - 2 * this.options.padding;
               this.visibleElemLength = this.elemArray.length;
               if (this.options.showcarousel && this.options.showcategory)
                  if (this.selectedcategory == "all") {
                     $(".html5gallery-tn-" + this.id).css({
                        display: "block"
                     });
                     $(".html5gallery-tn-" + this.id).removeClass("html5gallery-tn-hidden")
                  } else {
                     this.visibleElemLength = 0;
                     $(".html5gallery-tn-" + this.id).each(function () {
                        var match = false;
                        if ($(this).data("category")) {
                           var cats = String($(this).data("category")).split(":");
                           if ($.inArray(instance.selectedcategory, cats) >= 0) {
                              match = true;
                              instance.visibleElemLength++
                           }
                        }
                        $(this).css({
                           display: match ? "block" : "none"
                        });
                        if (!match) $(this).addClass("html5gallery-tn-hidden");
                        else $(this).removeClass("html5gallery-tn-hidden")
                     })
                  } if (this.options.titlesmallscreen) {
                  var fullW = $(window).width();
                  if (fullW < this.options.titlesmallscreenwidth) this.options.titleheight = this.options.titleheightsmallscreen;
                  else this.options.titleheight = this.options.titleheightlargescreen;
                  this.options.headerHeight = this.options.titleoverlay ?
                     this.options.socialheight : this.options.titleheight + this.options.socialheight
               }
               if (this.options.showcarousel) {
                  this.options.carouselHeight = this.options.thumbheight + 2 * this.options.thumbmargin;
                  if (this.options.carouselmultirows) {
                     if (this.options.thumbresponsive == "samecolumn") {
                        this.options.carouselcolumn = this.options.thumbcolumns;
                        if (this.options.thumbcolumnsresponsive) {
                           var fullW = $(window).width();
                           if (fullW < this.options.thumbsmallsize) this.options.carouselcolumn = this.options.thumbsmallcolumns;
                           else if (fullW <
                              this.options.thumbmediumsize) this.options.carouselcolumn = this.options.thumbmediumcolumns
                        }
                        this.options.thumbwidth = Math.min((this.options.width - this.options.thumbgap * (this.options.carouselcolumn - 1)) / this.options.carouselcolumn);
                        this.options.thumbheight = this.options.thumbwidth * this.options.thumboriginalheight / this.options.thumboriginalwidth;
                        this.options.thumbimagewidth = this.options.thumbwidth - 2 * this.options.thumbimageborder;
                        this.options.thumbimageheight = this.options.thumbheight - 2 * this.options.thumbimageborder;
                        if (this.options.thumbshowtitle) this.options.thumbheight += this.options.thumbtitleheight;
                        this.options.carouselHeight = Math.ceil(this.visibleElemLength / this.options.carouselcolumn) * (this.options.thumbheight + this.options.thumbrowgap)
                     } else {
                        if (this.options.thumbcolumnsresponsive) {
                           var fullW = $(window).width();
                           if (fullW < this.options.thumbsmallsize) {
                              this.options.thumbwidth = this.options.thumbsmallwidth;
                              this.options.thumbheight = this.options.thumbsmallheight;
                              this.options.thumbtitleheight = this.options.thumbsmalltitleheight
                           } else if (fullW <
                              this.options.thumbmediumsize) {
                              this.options.thumbwidth = this.options.thumbmediumwidth;
                              this.options.thumbheight = this.options.thumbmediumheight;
                              this.options.thumbtitleheight = this.options.thumbmediumtitleheight
                           } else {
                              this.options.thumbwidth = this.options.thumboriginalwidth;
                              this.options.thumbheight = this.options.thumboriginalheight;
                              this.options.thumbtitleheight = this.options.thumboriginaltitleheight
                           }
                           this.options.thumbimagewidth = this.options.thumbwidth - 2 * this.options.thumbimageborder;
                           this.options.thumbimageheight =
                              this.options.thumbheight - 2 * this.options.thumbimageborder;
                           if (this.options.thumbshowtitle) this.options.thumbheight += this.options.thumbtitleheight
                        }
                        this.options.carouselcolumn = Math.floor(this.options.width / (this.options.thumbwidth + this.options.thumbgap));
                        if (this.options.carouselcolumn < 1) this.options.carouselcolumn = 1;
                        this.options.carouselHeight = Math.ceil(this.visibleElemLength / this.options.carouselcolumn) * (this.options.thumbheight + this.options.thumbrowgap)
                     }
                     if (this.options.carouselpagination)
                        if (this.visibleElemLength >
                           this.options.carouselcolumn * this.options.carouselpaginationrow) {
                           this.options.carouselHeight = this.options.carouselpaginationrow * (this.options.thumbheight + this.options.thumbrowgap);
                           var activepage = 0;
                           if ($(".html5gallery-pagination-" + this.id).length > 0) {
                              var itemindex = $(".html5gallery-pagination-" + this.id).data("itemindex");
                              activepage = Math.floor(itemindex / (this.options.carouselcolumn * this.options.carouselpaginationrow))
                           }
                           this.drawPagination(activepage)
                        } else this.resetPagination()
                  } else if (this.options.thumbcolumnsresponsive) {
                     var fullW =
                        $(window).width();
                     if (fullW < this.options.thumbsmallsize) {
                        this.options.thumbwidth = this.options.thumbsmallwidth;
                        this.options.thumbheight = this.options.thumbsmallheight;
                        this.options.thumbtitleheight = this.options.thumbsmalltitleheight
                     } else if (fullW < this.options.thumbmediumsize) {
                        this.options.thumbwidth = this.options.thumbmediumwidth;
                        this.options.thumbheight = this.options.thumbmediumheight;
                        this.options.thumbtitleheight = this.options.thumbmediumtitleheight
                     } else {
                        this.options.thumbwidth = this.options.thumboriginalwidth;
                        this.options.thumbheight = this.options.thumboriginalheight;
                        this.options.thumbtitleheight = this.options.thumboriginaltitleheight
                     }
                     this.options.thumbimagewidth = this.options.thumbwidth - 2 * this.options.thumbimageborder;
                     this.options.thumbimageheight = this.options.thumbheight - 2 * this.options.thumbimageborder;
                     if (this.options.thumbshowtitle) this.options.thumbheight += this.options.thumbtitleheight
                  }
               }
               if (this.options.responsivefullscreen && this.container.parent().height() > 0) {
                  this.options.containerHeight = this.container.parent().height();
                  this.options.totalHeight = this.options.containerHeight;
                  this.options.height = this.options.totalHeight - (this.options.headerHeight + 2 * this.options.padding);
                  if (this.options.carouselHeight + this.options.carouselmargin > 0) this.options.height -= this.options.carouselHeight + this.options.carouselmargin
               } else {
                  this.options.height = Math.round(this.options.width * this.options.originalHeight / this.options.originalWidth);
                  this.options.totalHeight = this.options.height + this.options.carouselHeight + this.options.carouselmargin + this.options.headerHeight +
                     2 * this.options.padding;
                  this.options.containerHeight = this.options.totalHeight
               }
               if (this.options.showcarousel && this.options.showcategory) {
                  this.options.totalHeight += this.options.categoryheight;
                  this.options.containerHeight += this.options.categoryheight
               }
               this.container.css({
                  "width": this.options.containerWidth,
                  "height": this.options.containerHeight
               });
               this.options.boxWidth = this.options.width;
               if (this.options.headerpos == "bottomoutside") this.options.boxHeight = this.options.height;
               else this.options.boxHeight = this.options.height +
                  this.options.headerHeight;
               if (this.options.slideshadow) this.options.boxWidth += 8;
               if (this.options.showcarousel) {
                  this.options.carouselWidth = this.options.width;
                  this.options.carouselLeft = this.options.padding;
                  if (this.options.carouselposition == "top") this.options.carouselTop = this.options.padding;
                  else this.options.carouselTop = this.options.padding + this.options.boxHeight + this.options.carouselmargin
               }
               $(".html5gallery-container-" + this.id).css({
                  width: this.options.totalWidth + "px",
                  height: this.options.totalHeight + "px"
               });
               $(".html5gallery-box-" + this.id).css({
                  width: this.options.boxWidth + "px",
                  height: this.options.boxHeight + "px"
               });
               var type = this.elemArray[this.curElem][ELEM_TYPE];
               if (type == TYPE_IMAGE || this.showingPoster) {
                  var imageWidth = this.showingPoster ? this.elemArray[this.curElem][ELEM_POSTERWIDTH] : this.elemArray[this.curElem][ELEM_WIDTH];
                  var imageHeight = this.showingPoster ? this.elemArray[this.curElem][ELEM_POSTERHEIGHT] : this.elemArray[this.curElem][ELEM_HEIGHT];
                  var scale;
                  if (this.isFullscreen) {
                     var fullW = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ?
                        Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : this.fullscreenWidth;
                     var fullH = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : this.fullscreenHeight;
                     scale = Math.min(fullW / imageWidth, fullH / imageHeight);
                     scale = scale > 1 ? 1 : scale
                  } else if (this.options.resizemode == "fill") scale = Math.max(this.options.width / imageWidth, this.options.height / imageHeight);
                  else scale = Math.min(this.options.width / imageWidth,
                     this.options.height / imageHeight);
                  var w = Math.round(scale * imageWidth);
                  var h = Math.round(scale * imageHeight);
                  var w1 = this.isFullscreen ? w : this.options.width;
                  var h1 = this.isFullscreen ? h : this.options.height;
                  var l = Math.round(w1 / 2 - w / 2);
                  var t = Math.round(h1 / 2 - h / 2);
                  if (this.isFullscreen) this.adjustFullscreen(w1, h1, true);
                  $(".html5gallery-elem-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-img-" + this.id).css({
                     width: w1 + "px",
                     height: h1 + "px"
                  });
                  $(".html5gallery-elem-image-" + this.id).css({
                     width: w +
                        "px",
                     height: h + "px",
                     top: t + "px",
                     left: l + "px"
                  })
               } else if (type == TYPE_IFRAME || type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM || type == TYPE_VIDEO_YOUTUBE || type == TYPE_VIDEO_VIMEO || type == TYPE_EMBED_VIDEO) {
                  var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
                  var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
                  var w1, h1;
                  if (this.isFullscreen) {
                     var fullW = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) :
                        this.fullscreenWidth;
                     var fullH = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : this.fullscreenHeight;
                     scale = Math.min(fullW / dataW, fullH / dataH);
                     scale = scale > 1 ? 1 : scale;
                     w1 = Math.round(scale * dataW);
                     h1 = Math.round(scale * dataH);
                     this.adjustFullscreen(w1, h1, true)
                  } else {
                     w1 = this.options.width;
                     h1 = this.options.height
                  }
                  $(".html5gallery-elem-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-video-" + this.id).css({
                     "width": w1 +
                        "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-video-container-" + this.id).css({
                     "width": "100%",
                     "height": "100%"
                  });
                  $(".html5gallery-elem-video-container-" + this.id).find("video").css({
                     "width": "100%",
                     "height": "100%"
                  });
                  $("#html5gallery-elem-video-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $("#html5gallery-elem-video-" + this.id).attr("width", w1);
                  $("#html5gallery-elem-video-" + this.id).attr("height", h1);
                  $(".html5gallery-elem-video-" + this.id).find("iframe").attr("width", w1);
                  $(".html5gallery-elem-video-" +
                     this.id).find("iframe").attr("height", h1);
                  $("#html5gallery-elem-video-" + this.id).find("iframe").attr("width", w1);
                  $("#html5gallery-elem-video-" + this.id).find("iframe").attr("height", h1);
                  $(".html5gallery-elem-iframe-" + this.id).css({
                     "width": w1 + "px",
                     "height": h1 + "px"
                  });
                  $(".html5gallery-elem-iframe-" + this.id).find("iframe").attr("width", w1);
                  $(".html5gallery-elem-iframe-" + this.id).find("iframe").attr("height", h1)
               }
               var titleTop = 0;
               var socialTop = 0;
               if (this.options.headerpos == "bottom") {
                  titleTop = this.options.titleoverlay ?
                     this.options.height - this.options.titleheight : this.options.height;
                  socialTop = this.options.titleoverlay ? this.options.height : this.options.height + this.options.titleheight
               } else if (this.options.headerpos == "bottomoutside")
                  if (this.options.showcarousel) {
                     titleTop = this.options.height + this.options.carouselHeight;
                     if (this.options.showcategory) titleTop += this.options.categoryheight
                  } else titleTop = this.options.height;
               var titleWidth = this.options.slideshadow ? this.options.boxWidth - 8 : this.options.boxWidth;
               $(".html5gallery-title-" +
                  this.id).css({
                  width: titleWidth + "px"
               });
               if (!this.options.titleoverlay) $(".html5gallery-title-" + this.id).css({
                  top: titleTop + "px"
               });
               $(".html5gallery-viral-" + this.id).css({
                  top: socialTop + "px"
               });
               $(".html5gallery-timer-" + this.id).css({
                  top: String(this.options.elemTop + this.options.height - 2) + "px"
               });
               if (this.options.showcarousel) {
                  $(".html5gallery-car-" + this.id).css({
                     width: this.options.width + "px",
                     top: this.options.carouselTop + "px"
                  });
                  var carLeft = 4;
                  var carRight = 4;
                  $(".html5gallery-car-list-" + this.id).css({
                     width: String(this.options.width -
                        carLeft - carRight) + "px"
                  });
                  this.options.carouselNavButton = false;
                  if (!this.options.carouselmultirows && Math.floor((this.options.width - carLeft - carRight) / (this.options.thumbwidth + this.options.thumbgap)) < this.visibleElemLength) this.options.carouselNavButton = true;
                  var carButtonW = this.options.carouselNavButton ? this.options.carouselarrowwidth * 2 + 8 : 0;
                  $(".html5gallery-car-left-" + this.id).css({
                     display: this.options.carouselNavButton ? "block" : "none"
                  });
                  $(".html5gallery-car-right-" + this.id).css({
                     display: this.options.carouselNavButton ?
                        "block" : "none"
                  });
                  this.options.thumbShowNum = Math.floor((this.options.width - carLeft - carRight - carButtonW) / (this.options.thumbwidth + this.options.thumbgap));
                  if (this.options.thumbShowNum < 1) this.options.thumbShowNum = 1;
                  this.options.thumbMaskWidth = this.options.thumbShowNum * this.options.thumbwidth + this.options.thumbShowNum * this.options.thumbgap;
                  this.options.thumbTotalWidth = this.visibleElemLength * this.options.thumbwidth + (this.visibleElemLength - 1) * this.options.thumbgap;
                  var marginL = 0;
                  if (this.options.carouselmultirows) {
                     if (this.options.thumbresponsive ==
                        "samecolumn") $(".html5gallery-thumbs-" + this.id).css({
                        "margin-left": "0px",
                        width: String((this.options.thumbwidth + this.options.thumbgap) * this.options.carouselcolumn) + "px"
                     });
                     else {
                        var column = Math.floor(this.options.width / (this.options.thumbwidth + this.options.thumbgap));
                        if (column < 1) column = 1;
                        marginL = (this.options.width - column * this.options.thumbwidth - (column - 1) * this.options.thumbgap) / 2;
                        $(".html5gallery-thumbs-" + this.id).css({
                           "margin-left": marginL + "px",
                           width: this.options.width + "px"
                        })
                     }
                     $(".html5gallery-tn-" +
                        this.id).css({
                        width: this.options.thumbwidth + "px",
                        height: this.options.thumbheight + "px"
                     });
                     $(".html5gallery-tn-selected-" + this.id).css({
                        width: this.options.thumbwidth + "px",
                        height: this.options.thumbheight + "px"
                     });
                     $(".html5gallery-tn-img-" + this.id).css({
                        width: String(this.options.thumbimagewidth + 2 * this.options.thumbimageborder) + "px",
                        height: String(this.options.thumbimageheight + 2 * this.options.thumbimageborder) + "px"
                     });
                     $(".html5gallery-tn-image-" + this.id).parent().css({
                        width: this.options.thumbimagewidth + "px",
                        height: this.options.thumbimageheight + "px"
                     });
                     $(".html5gallery-tn-title-" + this.id).css({
                        width: String(this.options.thumbwidth - 2) + "px"
                     });
                     $(".html5gallery-tn-title-" + this.id).css({
                        height: this.options.thumbtitleheight + "px"
                     })
                  } else {
                     this.options.thumbShowNum = Math.floor((this.options.width - carLeft - carRight - carButtonW) / (this.options.thumbwidth + this.options.thumbgap));
                     if (this.options.thumbShowNum < 1) this.options.thumbShowNum = 1;
                     this.options.thumbMaskWidth = this.options.thumbShowNum * this.options.thumbwidth + this.options.thumbShowNum *
                        this.options.thumbgap;
                     this.options.thumbTotalWidth = this.visibleElemLength * this.options.thumbwidth + (this.visibleElemLength - 1) * this.options.thumbgap;
                     var marginL = 0;
                     if (this.options.thumbMaskWidth > this.options.thumbTotalWidth) marginL = this.options.thumbMaskWidth / 2 - this.options.thumbTotalWidth / 2 - this.options.thumbgap / 2;
                     this.options.carouselTotalHeight = this.options.carouselHeight + (this.options.showcategory ? this.options.categoryheight : 0);
                     $(".html5gallery-car-" + this.id).css({
                        height: this.options.carouselTotalHeight +
                           "px"
                     });
                     $(".html5gallery-car-list-" + this.id).css({
                        height: this.options.carouselHeight + "px"
                     });
                     $(".html5gallery-car-left-" + this.id).css({
                        top: String(this.options.carouselHeight / 2 - this.options.carouselarrowheight / 2) + "px"
                     });
                     $(".html5gallery-car-right-" + this.id).css({
                        top: String(this.options.carouselHeight / 2 - this.options.carouselarrowheight / 2) + "px"
                     });
                     $(".html5gallery-tn-title-" + this.id).css({
                        width: String(this.options.thumbwidth - 2) + "px"
                     });
                     $(".html5gallery-tn-title-" + this.id).css({
                        height: this.options.thumbtitleheight +
                           "px"
                     });
                     $(".html5gallery-tn-" + this.id).css({
                        width: this.options.thumbwidth + "px",
                        height: this.options.thumbheight + "px"
                     });
                     $(".html5gallery-tn-selected-" + this.id).css({
                        width: this.options.thumbwidth + "px",
                        height: this.options.thumbheight + "px"
                     });
                     $(".html5gallery-tn-img-" + this.id).css({
                        width: String(this.options.thumbimagewidth + 2 * this.options.thumbimageborder) + "px",
                        height: String(this.options.thumbimageheight + 2 * this.options.thumbimageborder) + "px"
                     });
                     $(".html5gallery-tn-image-" + this.id).parent().css({
                        width: this.options.thumbimagewidth +
                           "px",
                        height: this.options.thumbimageheight + "px"
                     });
                     $(".html5gallery-thumbs-" + this.id).css({
                        "margin-left": marginL + "px",
                        width: String(this.visibleElemLength * (this.options.thumbwidth + this.options.thumbgap)) + "px"
                     })
                  }
                  var w = "100%";
                  var h = "auto";
                  $(".html5gallery-tn-image-" + this.id).each(function () {
                     var originalwidth = $(this).data("originalwidth");
                     var originalheight = $(this).data("originalheight");
                     if (originalwidth > 0 && originalheight > 0) {
                        var scale = Math.max(instance.options.thumbimagewidth / originalwidth, instance.options.thumbimageheight /
                           originalheight);
                        w = Math.round(scale * originalwidth) + "px";
                        h = Math.round(scale * originalheight) + "px"
                     }
                     $(this).css({
                        width: w,
                        height: h
                     })
                  });
                  var maskLeft = Math.round((this.options.width - carLeft - carRight) / 2 - this.options.thumbMaskWidth / 2);
                  $(".html5gallery-car-mask-" + this.id).css({
                     left: maskLeft + "px",
                     width: this.options.thumbMaskWidth + "px",
                     height: this.options.carouselHeight + "px"
                  });
                  if (this.options.carouselmultirows && this.options.carouselpagination) {
                     $(".html5gallery-thumbs-" + this.id).css({
                        "margin-left": "0"
                     });
                     $(".html5gallery-car-mask-" +
                        this.id).css({
                        "margin-left": marginL + "px"
                     })
                  }
                  this.carouselHighlight(this.curElem, true)
               }
            },
            resetPagination: function () {
               $(".html5gallery-pagination-" + this.id).remove();
               this.movePagination(0, this.visibleElemLength)
            },
            drawPagination: function (activepage) {
               var inst = this;
               this.options.numperpage = this.options.carouselcolumn * this.options.carouselpaginationrow;
               this.options.page_count = Math.ceil(this.visibleElemLength / this.options.numperpage);
               if (activepage >= this.options.page_count) activepage = this.options.page_count -
                  1;
               if (activepage < 0) activepage = 0;
               var itemindex = activepage * this.options.numperpage;
               var page_buttons = '<div class="html5gallery-pagination-' + this.id + '" data-itemindex=' + itemindex + " data-activepage=" + activepage + ">";
               for (var i = 0; i <= this.options.page_count - 1; i++) page_buttons += '<button type="button" class="html5gallery-pagination-btn' + (i == activepage ? " html5gallery-pagination-btn-selected" : "") + '" data-pageindex="' + i + '">' + (i + 1).toString() + "</button>";
               page_buttons += "</div>";
               $(".html5gallery-pagination-" + this.id).remove();
               $(".html5gallery-car-" + this.id).append(page_buttons);
               this.movePagination(activepage, this.options.numperpage);
               $(".html5gallery-pagination-" + this.id + " .html5gallery-pagination-btn").click(function () {
                  var activepage = $(this).data("pageindex");
                  inst.drawPagination(activepage)
               })
            },
            movePagination: function (activepage, numperpage) {
               var itemStart = activepage * numperpage;
               var itemIndex = 0;
               $(".html5gallery-tn-" + this.id).each(function () {
                  if ($(this).hasClass("html5gallery-tn-hidden")) return true;
                  if (itemIndex >= itemStart &&
                     itemIndex < itemStart + numperpage) $(this).css({
                     display: "block"
                  });
                  else $(this).css({
                     display: "none"
                  });
                  itemIndex++
               })
            },
            createStyleDefault: function () {
               this.options.thumboriginalwidth = this.options.thumbwidth;
               this.options.thumboriginalheight = this.options.thumbheight;
               this.options.thumboriginaltitleheight = this.options.thumbtitleheight;
               if (this.options.thumbresponsive == "samecolumn") {
                  this.options.carouselcolumn = this.options.thumbcolumns;
                  if (this.options.thumbcolumnsresponsive) {
                     var fullW = $(window).width();
                     if (fullW <
                        this.options.thumbsmallsize) this.options.carouselcolumn = this.options.thumbsmallcolumns;
                     else if (fullW < this.options.thumbmediumsize) this.options.carouselcolumn = this.options.thumbmediumcolumns
                  }
                  this.options.thumbwidth = Math.min((this.options.width - this.options.thumbgap * (this.options.carouselcolumn - 1)) / this.options.carouselcolumn);
                  this.options.thumbheight = this.options.thumbwidth * this.options.thumboriginalheight / this.options.thumboriginalwidth
               } else if (this.options.thumbcolumnsresponsive) {
                  var fullW = $(window).width();
                  if (fullW < this.options.thumbsmallsize) {
                     this.options.thumbwidth = this.options.thumbsmallwidth;
                     this.options.thumbheight = this.options.thumbsmallheight;
                     this.options.thumbtitleheight = this.options.thumbsmalltitleheight
                  } else if (fullW < this.options.thumbmediumsize) {
                     this.options.thumbwidth = this.options.thumbmediumwidth;
                     this.options.thumbheight = this.options.thumbmediumheight;
                     this.options.thumbtitleheight = this.options.thumbmediumtitleheight
                  }
               }
               this.options.thumbimagewidth = this.options.thumbwidth - 2 * this.options.thumbimageborder;
               this.options.thumbimageheight = this.options.thumbheight - 2 * this.options.thumbimageborder;
               if (this.options.thumbshowtitle) this.options.thumbheight += this.options.thumbtitleheight;
               if (!this.options.showtitle) this.options.titleheight = 0;
               if (!this.options.showsocialmedia || !this.options.showfacebooklike && !this.options.showtwitter && !this.options.showgoogleplus) this.options.socialheight = 0;
               this.options.headerHeight = this.options.titleoverlay ? this.options.socialheight : this.options.titleheight + this.options.socialheight;
               this.options.boxWidth = this.options.width;
               if (this.options.headerpos == "bottomoutside") this.options.boxHeight = this.options.height;
               else this.options.boxHeight = this.options.height + this.options.headerHeight;
               this.options.boxLeft = this.options.padding;
               this.options.boxTop = this.options.padding;
               if (this.options.slideshadow) {
                  this.options.boxWidth += 8;
                  this.options.boxLeft -= 4;
                  this.options.boxTop -= 4
               }
               if (this.options.showcarousel) {
                  this.options.carouselWidth = this.options.width;
                  this.options.carouselHeight = this.options.thumbheight +
                     2 * this.options.thumbmargin;
                  this.options.carouselLeft = this.options.padding;
                  if (this.options.carouselposition == "top") {
                     this.options.carouselTop = this.options.padding;
                     this.options.boxTop = this.options.padding + this.options.carouselHeight + this.options.carouselmargin;
                     if (this.options.showcategory) this.options.boxTop += this.options.categoryheight
                  } else this.options.carouselTop = this.options.padding + this.options.boxHeight + this.options.carouselmargin;
                  if (this.options.carouselmultirows) {
                     if (this.options.thumbresponsive ==
                        "samecolumn") {
                        this.options.carouselcolumn = this.options.thumbcolumns;
                        if (this.options.thumbcolumnsresponsive) {
                           var fullW = $(window).width();
                           if (fullW < this.options.thumbsmallsize) this.options.carouselcolumn = this.options.thumbsmallcolumns;
                           else if (fullW < this.options.thumbmediumsize) this.options.carouselcolumn = this.options.thumbmediumcolumns
                        }
                        this.options.thumbwidth = Math.min((this.options.width - this.options.thumbgap * (this.options.carouselcolumn - 1)) / this.options.carouselcolumn);
                        this.options.thumbheight = this.options.thumbwidth *
                           this.options.thumboriginalheight / this.options.thumboriginalwidth;
                        this.options.thumbimagewidth = this.options.thumbwidth - 2 * this.options.thumbimageborder;
                        this.options.thumbimageheight = this.options.thumbheight - 2 * this.options.thumbimageborder;
                        if (this.options.thumbshowtitle) this.options.thumbheight += this.options.thumbtitleheight;
                        this.options.carouselHeight = Math.ceil(this.elemArray.length / this.options.carouselcolumn) * (this.options.thumbheight + this.options.thumbrowgap)
                     } else {
                        this.options.carouselcolumn = Math.floor(this.options.width /
                           (this.options.thumbwidth + this.options.thumbgap));
                        if (this.options.carouselcolumn < 1) this.options.carouselcolumn = 1;
                        this.options.carouselHeight = Math.ceil(this.elemArray.length / this.options.carouselcolumn) * (this.options.thumbheight + this.options.thumbrowgap)
                     }
                     if (this.options.carouselpagination)
                        if (this.visibleElemLength > this.options.carouselcolumn * this.options.carouselpaginationrow) {
                           this.options.carouselHeight = this.options.carouselpaginationrow * (this.options.thumbheight + this.options.thumbrowgap);
                           this.drawPagination(0)
                        }
                  }
               } else {
                  this.options.carouselWidth =
                     0;
                  this.options.carouselHeight = 0;
                  this.options.carouselLeft = 0;
                  this.options.carouselTop = 0;
                  this.options.carouselmargin = 0
               }
               this.options.totalWidth = this.options.width + 2 * this.options.padding;
               this.options.totalHeight = this.options.height + this.options.carouselHeight + this.options.carouselmargin + this.options.headerHeight + 2 * this.options.padding;
               this.options.containerWidth = this.options.totalWidth;
               this.options.containerHeight = this.options.totalHeight;
               if (this.options.responsive) {
                  this.options.originalWidth = this.options.width;
                  this.options.originalHeight = this.options.height;
                  this.container.css({
                     "max-width": "100%"
                  })
               } else this.container.css({
                  "width": this.options.containerWidth,
                  "height": this.options.containerHeight
               });
               var titleTop = 0;
               var socialTop = 0;
               this.options.elemTop = 0;
               if (this.options.headerpos == "top") {
                  socialTop = 0;
                  titleTop = this.options.socialheight;
                  this.options.elemTop = this.options.headerHeight
               } else if (this.options.headerpos == "bottom") {
                  this.options.elemTop = 0;
                  titleTop = this.options.titleoverlay ? this.options.height - this.options.titleheight :
                     this.options.height;
                  socialTop = this.options.titleoverlay ? this.options.height : this.options.height + this.options.titleheight
               }
               var styleCss = "";
               $(".html5gallery-container-" + this.id).css({
                  display: "block",
                  position: "absolute",
                  left: 0,
                  top: 0,
                  width: this.options.totalWidth + "px",
                  height: this.options.totalHeight + "px",
                  "background-color": this.options.bgcolor
               });
               if (this.options.bgimage) $(".html5gallery-container-" + this.id).css({
                  background: "url('" + this.options.bgimage + "') center top"
               });
               if (this.options.galleryshadow) styleCss +=
                  " .html5gallery-container-" + this.id + " { -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}";
               $(".html5gallery-box-" + this.id).css({
                  display: "block",
                  position: "absolute",
                  "text-align": "center",
                  left: this.options.boxLeft + "px",
                  top: this.options.boxTop + "px",
                  width: this.options.boxWidth + "px",
                  height: this.options.boxHeight + "px"
               });
               var viralPaddingTop = Math.round(this.options.socialheight / 2 - 12);
               styleCss += " .html5gallery-title-text-" + this.id + " " + this.options.titlecss +
                  " .html5gallery-title-text-" + this.id + " " + this.options.titlecsslink + " .html5gallery-error-" + this.id + " " + this.options.errorcss;
               styleCss += " .html5gallery-description-text-" + this.id + " " + this.options.descriptioncss + " .html5gallery-description-text-" + this.id + " " + this.options.descriptioncsslink;
               styleCss += " .html5gallery-fullscreen-title-" + this.id + "" + this.options.lightboxtitlecss + " .html5gallery-fullscreen-title-" + this.id + "" + this.options.lightboxtitlelinkcss;
               styleCss += " .html5gallery-fullscreen-description-" +
                  this.id + "" + this.options.lightboxdescriptioncss + " .html5gallery-fullscreen-description-" + this.id + "" + this.options.lightboxdescriptionlinkcss;
               styleCss += " .html5gallery-viral-" + this.id + " {display:block; overflow:hidden; position:absolute; text-align:left; top:" + socialTop + "px; left:0px; width:" + this.options.boxWidth + "px; height:" + this.options.socialheight + "px; padding-top:" + viralPaddingTop + "px;}";
               var titleWidth = this.options.slideshadow ? this.options.boxWidth - 8 : this.options.boxWidth;
               styleCss += " .html5gallery-title-" +
                  this.id + " {display:" + (this.options.titleoverlay && this.options.titleautohide ? "none" : "block") + "; overflow:hidden; position:absolute; left:0px; width:" + titleWidth + "px; ";
               if (!this.options.titleoverlay) {
                  styleCss += "top:" + titleTop + "px; height:" + this.options.titleheight + "px; }";
                  if (this.options.titlesmallscreen) styleCss += " @media (max-width: " + this.options.titlesmallscreenwidth + "px) { .html5gallery-title-" + this.id + " {height:" + this.options.titleheightsmallscreen + "px; }}"
               } else if (this.options.headerpos == "top") styleCss +=
                  "top:0px; height:auto; }";
               else styleCss += "bottom:0px; height:auto; }";
               styleCss += " .html5gallery-timer-" + this.id + " {display:block; position:absolute; top:" + String(this.options.elemTop + this.options.height - 2) + "px; left:0px; width:0px; height:2px; background-color:#ccc; filter:alpha(opacity=60); opacity:0.6; }";
               styleCss += " .html5gallery-elem-" + this.id + " {display:block; overflow:hidden; position:absolute; top:" + this.options.elemTop + "px; left:0px; width:" + this.options.width + "px; height:" + this.options.height +
                  "px;}";
               if (this.options.isIE7 || this.options.isIE6) {
                  styleCss += " .html5gallery-loading-" + this.id + " {display:none; }";
                  styleCss += " .html5gallery-loading-center-" + this.id + " {display:none; }"
               } else {
                  styleCss += " .html5gallery-loading-" + this.id + " {display:block; position:absolute; top:4px; right:4px; width:100%; height:100%; background:url('" + this.options.loadinggif + "') no-repeat top right;}";
                  styleCss += " .html5gallery-loading-center-" + this.id + " {display:block; position:absolute; top:0px; left:0px; width:100%; height:100%; background:url('" +
                     this.options.centerloadinggif + "') no-repeat center center;}"
               }
               if (this.options.borderradius > 0) styleCss += " .html5gallery-elem-" + this.id + " {overflow:hidden; border-radius:" + this.options.borderradius + "px; -moz-border-radius:" + this.options.borderradius + "px; -webkit-border-radius:" + this.options.borderradius + "px;}";
               if (this.options.slideshadow) {
                  styleCss += " .html5gallery-title-" + this.id + " { padding:4px;}";
                  styleCss += " .html5gallery-timer-" + this.id + " { margin:4px;}";
                  styleCss += " .html5gallery-elem-" + this.id + " { overflow:hidden; padding:4px; -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}"
               }
               if (this.options.showcarousel) this.visibleElemLength =
                  this.elemArray.length;
               if (this.options.showcarousel && this.options.carouselmultirows) {
                  if (this.options.carouselpagination) {
                     styleCss += " .html5gallery-car-mask-" + this.id + "{overflow:hidden;}";
                     styleCss += ".html5gallery-pagination-" + this.id + "{display:block;text-align:center;margin:0 auto;}";
                     styleCss += ".html5gallery-pagination-" + this.id + " .html5gallery-pagination-btn {display:inline-block;margin:6px;padding:4px 8px;background:#ededed;border:1px solid #dcdcdc;background:linear-gradient(to bottom, #ededed 0%, #dfdfdf 100%);color:#333;transition: background-color 0.5s ease;cursor:pointer;}";
                     styleCss += ".html5gallery-pagination-" + this.id + " .html5gallery-pagination-btn:hover," + ".html5gallery-pagination-" + this.id + " .html5gallery-pagination-btn-selected {background: #dfdfdf;background: linear-gradient(to bottom, #fdfdfd 0%, #ededed 100%);}"
                  }
                  styleCss += " .html5gallery-car-" + this.id + " { position:absolute; display:block; overflow:hidden; left:" + this.options.carouselLeft + "px; top:" + this.options.carouselTop + "px; width:" + this.options.width + "px;";
                  if (this.options.carouselbgtransparent) styleCss += "background-color:transparent;";
                  else styleCss += "border-top:1px solid " + this.options.carouseltopborder + ";" + "border-bottom:1px solid " + this.options.carouselbottomborder + ";" + "background-color: " + this.options.carouselbgcolorend + "; " + "background: " + this.options.carouselbgcolorend + " -webkit-gradient(linear, left top, left bottom, from(" + this.options.carouselbgcolorstart + "), to(" + this.options.carouselbgcolorend + ")) no-repeat; " + "background: " + this.options.carouselbgcolorend + " -moz-linear-gradient(top, " + this.options.carouselbgcolorstart +
                     ", " + this.options.carouselbgcolorend + ") no-repeat; " + "filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselbgcolorstart + ", endColorstr=" + this.options.carouselbgcolorend + ") no-repeat; " + "-ms-filter: 'progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselbgcolorstart + ", endColorstr=" + this.options.carouselbgcolorend + ")' no-repeat;";
                  if (this.options.carouselbgimage) styleCss += "background:url('" + this.options.skinfolder + this.options.carouselbgimage +
                     "') center top;";
                  styleCss += "}";
                  var column = Math.floor(this.options.width / (this.options.thumbwidth + this.options.thumbgap));
                  if (column < 1) column = 1;
                  var marginL = (this.options.width - column * this.options.thumbwidth - (column - 1) * this.options.thumbgap) / 2;
                  var thumbsWidth = this.options.thumbresponsive == "samecolumn" ? (this.options.thumbwidth + this.options.thumbgap) * this.options.carouselcolumn : this.options.width;
                  styleCss += ".html5gallery-thumbs-" + this.id + " { position:relative; display:block; margin-left:" + marginL + "px; width:" +
                     thumbsWidth + "px; top:0px; }";
                  $(".html5gallery-tn-" + this.id).css({
                     display: "block",
                     "float": "left",
                     "margin-left": 0,
                     "margin-right": this.options.thumbgap + "px",
                     "margin-bottom": this.options.thumbrowgap + "px",
                     "text-align": "center",
                     cursor: "pointer",
                     width: this.options.thumbwidth + "px",
                     height: this.options.thumbheight + "px",
                     overflow: "hidden"
                  });
                  if (this.options.thumbshadow) styleCss += " .html5gallery-tn-" + this.id + " { -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}";
                  styleCss += " .html5gallery-tn-selected-" + this.id + " { display:block; float:left; margin-left:0px; margin-right:" + this.options.thumbgap + "px; margin-bottom:" + this.options.thumbrowgap + "px; text-align:center; cursor:pointer; width:" + this.options.thumbwidth + "px;height:" + this.options.thumbheight + "px;overflow:hidden;}";
                  if (this.options.thumbshadow) styleCss += " .html5gallery-tn-selected-" + this.id + " { -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}";
                  styleCss +=
                     " .html5gallery-tn-" + this.id + " {background-color:" + this.options.thumbimagebordercolor + ";}" + " .html5gallery-tn-" + this.id + " { filter:alpha(opacity=" + Math.round(this.options.thumbopacity * 100) + "); opacity:" + this.options.thumbopacity + "; } " + " .html5gallery-tn-selected-" + this.id + " { filter:alpha(opacity=100); opacity:1; } ";
                  styleCss += " .html5gallery-tn-img-" + this.id + " {display:block; overflow:hidden; width:" + String(this.options.thumbimagewidth + 2 * this.options.thumbimageborder) + "px;height:" + String(this.options.thumbimageheight +
                     2 * this.options.thumbimageborder) + "px;}";
                  if (this.options.thumbunselectedimagebordercolor) styleCss += " .html5gallery-tn-selected-" + this.id + " {background-color:" + this.options.thumbunselectedimagebordercolor + ";}";
                  if (this.options.thumbshowtitle) {
                     styleCss += " .html5gallery-tn-title-" + this.id + " {display:block; overflow:hidden; float:top; height:" + this.options.thumbtitleheight + "px;width:" + String(this.options.thumbwidth - 2) + "px;}";
                     styleCss += " .html5gallery-tn-title-" + this.id + this.options.thumbtitlecss
                  } else styleCss +=
                     " .html5gallery-tn-title-" + this.id + " {display:none;}";
                  this.carouselHighlight = function (index, nonanimation) {}
               } else if (this.options.showcarousel) {
                  styleCss += " .html5gallery-car-" + this.id + " {";
                  this.options.carouselTotalHeight = this.options.carouselHeight + (this.options.showcategory ? this.options.categoryheight : 0);
                  $(".html5gallery-car-" + this.id).css({
                     position: "absolute",
                     display: "block",
                     overflow: "hidden",
                     left: this.options.carouselLeft + "px",
                     top: this.options.carouselTop + "px",
                     width: this.options.width + "px",
                     height: this.options.carouselTotalHeight +
                        "px"
                  });
                  if (this.options.carouselbgtransparent) styleCss += "background-color:transparent;";
                  else styleCss += "border-top:1px solid " + this.options.carouseltopborder + ";" + "border-bottom:1px solid " + this.options.carouselbottomborder + ";" + "background-color: " + this.options.carouselbgcolorend + "; " + "background: " + this.options.carouselbgcolorend + " -webkit-gradient(linear, left top, left bottom, from(" + this.options.carouselbgcolorstart + "), to(" + this.options.carouselbgcolorend + ")) no-repeat; " + "background: " + this.options.carouselbgcolorend +
                     " -moz-linear-gradient(top, " + this.options.carouselbgcolorstart + ", " + this.options.carouselbgcolorend + ") no-repeat; " + "filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselbgcolorstart + ", endColorstr=" + this.options.carouselbgcolorend + ") no-repeat; " + "-ms-filter: 'progid:DXImageTransform.Microsoft.gradient(startColorstr=" + this.options.carouselbgcolorstart + ", endColorstr=" + this.options.carouselbgcolorend + ")' no-repeat;";
                  if (this.options.carouselbgimage) styleCss += "background:url('" +
                     this.options.skinfolder + this.options.carouselbgimage + "') center top;";
                  styleCss += "}";
                  var carLeft = 4;
                  var carRight = 4;
                  styleCss += " .html5gallery-car-list-" + this.id + " { position:relative; display:block; overflow:hidden; left:" + carLeft + "px; width:" + String(this.options.width - carLeft - carRight) + "px; height:" + this.options.carouselHeight + "px; " + "}";
                  this.options.carouselNavButton = false;
                  if (Math.floor((this.options.width - carLeft - carRight) / (this.options.thumbwidth + this.options.thumbgap)) < this.elemArray.length) this.options.carouselNavButton =
                     true;
                  styleCss += " .html5gallery-car-left-" + this.id + " { position:absolute; overflow:hidden; width:" + this.options.carouselarrowwidth + "px; height:" + this.options.carouselarrowheight + "px; left:0px; top:" + String(this.options.carouselHeight / 2 - this.options.carouselarrowheight / 2) + "px; background:url('" + this.options.skinfolder + "carousel_left.png') no-repeat 0px 0px;} " + " .html5gallery-car-right-" + this.id + " { position:absolute; overflow:hidden; width:" + this.options.carouselarrowwidth + "px; height:" + this.options.carouselarrowheight +
                     "px; right:0px; top:" + String(this.options.carouselHeight / 2 - this.options.carouselarrowheight / 2) + "px; background:url('" + this.options.skinfolder + "carousel_right.png') no-repeat 0px 0px;} ";
                  var carButtonW = this.options.carouselNavButton ? this.options.carouselarrowwidth * 2 + 8 : 0;
                  $(".html5gallery-car-left-" + this.id).css({
                     display: this.options.carouselNavButton ? "block" : "none"
                  });
                  $(".html5gallery-car-right-" + this.id).css({
                     display: this.options.carouselNavButton ? "block" : "none"
                  });
                  this.options.thumbShowNum = Math.floor((this.options.width -
                     carLeft - carRight - carButtonW) / (this.options.thumbwidth + this.options.thumbgap));
                  if (this.options.thumbShowNum < 1) this.options.thumbShowNum = 1;
                  this.options.thumbMaskWidth = this.options.thumbShowNum * this.options.thumbwidth + this.options.thumbShowNum * this.options.thumbgap;
                  this.options.thumbTotalWidth = this.elemArray.length * this.options.thumbwidth + (this.elemArray.length - 1) * this.options.thumbgap;
                  var marginL = 0;
                  if (this.options.thumbMaskWidth > this.options.thumbTotalWidth) marginL = this.options.thumbMaskWidth / 2 - this.options.thumbTotalWidth /
                     2 - this.options.thumbgap / 2;
                  styleCss += ".html5gallery-thumbs-" + this.id + " { position:relative; display:block; margin-left:" + marginL + "px; width:" + String(this.elemArray.length * (this.options.thumbwidth + this.options.thumbgap)) + "px; top:" + Math.round(this.options.carouselHeight / 2 - this.options.thumbheight / 2) + "px; }";
                  var maskLeft = Math.round((this.options.width - carLeft - carRight) / 2 - this.options.thumbMaskWidth / 2);
                  $(".html5gallery-car-mask-" + this.id).css({
                     position: "absolute",
                     display: "block",
                     "text-align": "left",
                     overflow: "hidden",
                     left: maskLeft + "px",
                     width: this.options.thumbMaskWidth + "px",
                     top: 0,
                     height: this.options.carouselHeight + "px"
                  });
                  $(".html5gallery-tn-" + this.id).css({
                     display: "block",
                     "float": "left",
                     "margin-left": Math.floor(this.options.thumbgap / 2) + "px",
                     "margin-right": Math.floor(this.options.thumbgap / 2) + "px",
                     "text-align": "center",
                     cursor: "pointer",
                     width: this.options.thumbwidth + "px",
                     height: this.options.thumbheight + "px",
                     overflow: "hidden"
                  });
                  if (this.options.thumbshadow) styleCss += " .html5gallery-tn-" + this.id + " { -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}";
                  styleCss += " .html5gallery-tn-selected-" + this.id + " { display:block; float:left; margin-left:" + Math.floor(this.options.thumbgap / 2) + "px; margin-right:" + Math.floor(this.options.thumbgap / 2) + "px;text-align:center; cursor:pointer; width:" + this.options.thumbwidth + "px;height:" + this.options.thumbheight + "px;overflow:hidden;}";
                  if (this.options.thumbshadow) styleCss += " .html5gallery-tn-selected-" + this.id + " { -moz-box-shadow: 0px 2px 5px #aaa; -webkit-box-shadow: 0px 2px 5px #aaa; box-shadow: 0px 2px 5px #aaa;}";
                  styleCss += " .html5gallery-tn-" + this.id + " {background-color:" + this.options.thumbimagebordercolor + ";}" + " .html5gallery-tn-" + this.id + " { filter:alpha(opacity=" + Math.round(this.options.thumbopacity * 100) + "); opacity:" + this.options.thumbopacity + "; } " + " .html5gallery-tn-selected-" + this.id + " { filter:alpha(opacity=100); opacity:1; } ";
                  styleCss += " .html5gallery-tn-img-" + this.id + " {display:block; overflow:hidden; width:" + String(this.options.thumbimagewidth + 2 * this.options.thumbimageborder) + "px;height:" + String(this.options.thumbimageheight +
                     2 * this.options.thumbimageborder) + "px;}";
                  if (this.options.thumbunselectedimagebordercolor) styleCss += " .html5gallery-tn-selected-" + this.id + " {background-color:" + this.options.thumbunselectedimagebordercolor + ";}";
                  if (this.options.thumbshowtitle) {
                     styleCss += " .html5gallery-tn-title-" + this.id + " {display:block; overflow:hidden; float:top; height:" + this.options.thumbtitleheight + "px;width:" + String(this.options.thumbwidth - 2) + "px;}";
                     styleCss += " .html5gallery-tn-title-" + this.id + this.options.thumbtitlecss
                  } else styleCss +=
                     " .html5gallery-tn-title-" + this.id + " {display:none;}";
                  this.carouselHighlight = function (index, nonanimation) {
                     $("#html5gallery-tn-" + this.id + "-" + index, this.$gallery).addClass("html5gallery-tn-selected-" + this.id);
                     if (this.options.thumbShowNum >= this.visibleElemLength) {
                        $(".html5gallery-car-left-" + this.id, this.$gallery).css({
                           "background-position": "-" + String(this.options.carouselarrowwidth * 2) + "px 0px",
                           cursor: ""
                        });
                        $(".html5gallery-car-left-" + this.id, this.$gallery).data("disabled", true);
                        $(".html5gallery-car-right-" +
                           this.id, this.$gallery).css({
                           "background-position": "-" + String(this.options.carouselarrowwidth * 2) + "px 0px",
                           cursor: ""
                        });
                        $(".html5gallery-car-right-" + this.id, this.$gallery).data("disabled", true);
                        return
                     }
                     var pos = Math.floor(index / this.options.thumbShowNum) * this.options.thumbShowNum * (this.options.thumbwidth + this.options.thumbgap);
                     if (pos >= this.options.thumbTotalWidth - this.options.thumbMaskWidth + this.options.thumbgap) pos = this.options.thumbTotalWidth - this.options.thumbMaskWidth + this.options.thumbgap;
                     pos = -pos;
                     if (nonanimation) $(".html5gallery-thumbs-" + this.id, this.$gallery).css({
                        marginLeft: pos
                     });
                     else $(".html5gallery-thumbs-" + this.id, this.$gallery).animate({
                        marginLeft: pos
                     }, 500);
                     this.updateCarouseButtons(pos)
                  };
                  this.carouselPrev = function () {
                     var $thumbContainer = $(".html5gallery-thumbs-" + this.id, this.$gallery);
                     if (parseInt($thumbContainer.css("margin-left")) == 0) return;
                     else {
                        var pos = -1 * parseInt($thumbContainer.css("margin-left")) - this.options.thumbShowNum * (this.options.thumbwidth + this.options.thumbgap);
                        if (pos <
                           0) pos = 0;
                        $thumbContainer.animate({
                           marginLeft: -pos
                        }, 500, this.options.carouseleasing);
                        this.updateCarouseButtons(-pos)
                     }
                  };
                  this.carouselNext = function () {
                     var $thumbContainer = $(".html5gallery-thumbs-" + this.id, this.$gallery);
                     if (parseInt($thumbContainer.css("margin-left")) == -(this.options.thumbTotalWidth - this.options.thumbMaskWidth + this.options.thumbgap)) return;
                     else {
                        var pos = -1 * parseInt($thumbContainer.css("margin-left")) + this.options.thumbShowNum * (this.options.thumbwidth + this.options.thumbgap);
                        if (pos >= this.options.thumbTotalWidth -
                           this.options.thumbMaskWidth + this.options.thumbgap) pos = this.options.thumbTotalWidth - this.options.thumbMaskWidth + this.options.thumbgap;
                        $thumbContainer.animate({
                           marginLeft: -pos
                        }, 500, this.options.carouseleasing);
                        this.updateCarouseButtons(-pos)
                     }
                  };
                  this.updateCarouseButtons = function (pos) {
                     var $leftButton = $(".html5gallery-car-left-" + this.id, this.$gallery);
                     var $rightButton = $(".html5gallery-car-right-" + this.id, this.$gallery);
                     var rightMost = -1 * (this.options.thumbTotalWidth - this.options.thumbMaskWidth + this.options.thumbgap);
                     if (pos == 0) {
                        $leftButton.css({
                           "background-position": "-" + String(this.options.carouselarrowwidth * 2) + "px 0px",
                           cursor: ""
                        });
                        $leftButton.data("disabled", true)
                     } else if ($leftButton.data("disabled")) {
                        $leftButton.css({
                           "background-position": "0px 0px",
                           cursor: "pointer"
                        });
                        $leftButton.data("disabled", false)
                     }
                     if (pos == rightMost) {
                        $rightButton.css({
                           "background-position": "-" + String(this.options.carouselarrowwidth * 2) + "px 0px",
                           cursor: ""
                        });
                        $rightButton.data("disabled", true)
                     } else if ($rightButton.data("disabled")) {
                        $rightButton.css({
                           "background-position": "0px 0px",
                           cursor: "pointer"
                        });
                        $rightButton.data("disabled", false)
                     }
                  }
               } else $(".html5gallery-car-" + this.id).css({
                  display: "none"
               });
               styleCss += ".html5gallery-container-" + this.id + " div {box-sizing:content-box;}";
               styleCss += this.addCommonStyle();
               if (this.options.showcarousel && this.options.showcategory) {
                  var catSelect = '<div class="html5gallery-cat-selection-' + this.id + '">';
                  if (this.options.categorystyle == "dropdown") {
                     catSelect += '<select class="html5gallery-cat-dropdown-' + this.id + '">';
                     for (var i = 0; i < this.options.categorylist.length; i++) catSelect +=
                        "<option" + (this.selectedcategory == this.options.categorylist[i].slug ? " selected" : "") + ' value="' + this.options.categorylist[i].slug + '">' + this.options.categorylist[i].caption + "</option>";
                     catSelect += "</select>"
                  } else
                     for (var i = 0; i < this.options.categorylist.length; i++) catSelect += '<div class="html5gallery-cat-tag-' + this.id + (this.selectedcategory == this.options.categorylist[i].slug ? " html5gallery-cat-tag-selected-" + this.id : "") + '" data-catslug="' + this.options.categorylist[i].slug + '">' + this.options.categorylist[i].caption +
                        "</div>";
                  catSelect += "</div>";
                  $(".html5gallery-car-" + this.id).prepend(catSelect);
                  var instance = this;
                  if (this.options.categorystyle == "dropdown") $(".html5gallery-cat-dropdown-" + this.id).change(function () {
                     instance.selectedcategory = String($(this).val());
                     if (instance.options.carouselmultirows && instance.options.carouselpagination)
                        if ($(".html5gallery-pagination-" + instance.id).length > 0) $(".html5gallery-pagination-" + instance.id).data("itemindex", 0);
                     instance.resizeStyleDefault()
                  });
                  else $(".html5gallery-cat-tag-" +
                     this.id).click(function () {
                     $(".html5gallery-cat-tag-" + instance.id).removeClass("html5gallery-cat-tag-selected-" + instance.id);
                     $(this).addClass("html5gallery-cat-tag-selected-" + instance.id);
                     instance.selectedcategory = String($(this).data("catslug"));
                     if (instance.options.carouselmultirows && instance.options.carouselpagination)
                        if ($(".html5gallery-pagination-" + instance.id).length > 0) $(".html5gallery-pagination-" + instance.id).data("itemindex", 0);
                     instance.resizeStyleDefault()
                  })
               }
               $("head").append("<style type='text/css' data-creator='html5gallery'>" +
                  styleCss + "</style>")
            },
            addCommonStyle: function () {
               var styleCss = "";
               if (this.options.thumbverticalmiddle) styleCss += ".html5gallery-tn-image-" + this.id + " {position:relative;top:50%;transform:translateY(-50%);}";
               return styleCss
            },
            html2Text: function (html) {
               var tag = document.createElement("div");
               tag.innerHTML = html;
               return tag.innerText
            },
            loadCarousel: function () {
               var instance = this;
               var $thumbContainer = $(".html5gallery-thumbs-" + this.id, this.$gallery);
               $thumbContainer.empty();
               for (var i = 0; i < this.elemArray.length; i++) {
                  var $thumb =
                     $("<div " + (this.options.enabletabindex ? "tabindex='0' " : "") + "id='html5gallery-tn-" + this.id + "-" + i + "' class='html5gallery-tn-" + this.id + "'" + (this.elemArray[i][ELEM_CATEGORY] ? " data-category='" + this.elemArray[i][ELEM_CATEGORY] + "'" : "") + " data-index=" + i + " ></div>");
                  $thumb.appendTo($thumbContainer);
                  if (this.options.enabletabindex) $thumb.on("keydown", function (e) {
                     if (e.keyCode == 13) $(this).click()
                  });
                  if (!this.options.thumblinkintitle) {
                     $thumb.off("click").click(function (event) {
                        instance.onThumbClick($(this).data("index"));
                        instance.slideRun($(this).data("index"), true, true)
                     });
                     if (instance.options.switchonmouseover) $thumb.hover(function () {
                        if (instance.curElem != $(this).data("index")) $(this).click()
                     })
                  }
                  $thumb.hover(function () {
                     instance.onThumbOver($(this).data("index"));
                     $(this).addClass("html5gallery-tn-selected-" + instance.id)
                  }, function () {
                     if ($(this).data("index") !== instance.curElem) $(this).removeClass("html5gallery-tn-selected-" + instance.id)
                  });
                  if (this.elemArray[i][ELEM_THUMBNAIL] && this.options.thumbshowimage) {
                     var imgLoader =
                        new Image;
                     imgLoader.data = i;
                     $(imgLoader).on("load", function () {
                        $(this).data("originalwidth", this.width);
                        $(this).data("originalheight", this.height);
                        var scale = Math.max(instance.options.thumbimagewidth / this.width, instance.options.thumbimageheight / this.height);
                        var w = Math.round(scale * this.width);
                        var h = Math.round(scale * this.height);
                        var videoPlay = instance.options.thumbshowplayonvideo && instance.elemArray[this.data][ELEM_TYPE] != 1 ? "<div class='html5gallery-tn-img-play-" + instance.id + "' style='display:block; overflow:hidden; position:absolute; width:100%;height:100%; top:" +
                           instance.options.thumbimageborder + "px; left:" + instance.options.thumbimageborder + 'px;background:url("' + instance.options.playvideothumbimage + "\") no-repeat center center;'></div>" : "";
                        var imgtitle = instance.options.addthumbnailtitle && instance.elemArray[this.data][ELEM_TITLE] ? ' title="' + instance.elemArray[this.data][ELEM_TITLE] + '"' : "";
                        if (instance.options.carouselmultirows && instance.options.thumbresponsive == "samecolumn") $("#html5gallery-tn-" + instance.id + "-" + this.data, $thumbContainer).append("<div class='html5gallery-tn-img-" +
                           instance.id + "'" + imgtitle + " style='position:relative;width:" + String(instance.options.thumbimagewidth + 2 * instance.options.thumbimageborder) + "px;height:" + String(instance.options.thumbimageheight + 2 * instance.options.thumbimageborder) + "px;'><div style='display:block; overflow:hidden; position:absolute; width:" + instance.options.thumbimagewidth + "px;height:" + instance.options.thumbimageheight + "px; top:" + instance.options.thumbimageborder + "px; left:" + instance.options.thumbimageborder + "px;'>" + "<img alt='" + instance.html2Text(instance.elemArray[this.data][ELEM_ALT]) +
                           "'" + (instance.options.addimgtitle ? " title='" + instance.html2Text(instance.elemArray[this.data][ELEM_TITLE]) + "'" : "") + " data-originalwidth=" + this.width + " data-originalheight=" + this.height + " class='html5gallery-tn-image html5gallery-tn-image-" + instance.id + "'" + imgtitle + " style='border:none; padding:0px; margin:0px; max-width:100%; max-height:none; width:" + w + "px; height:" + h + "px;' src='" + instance.elemArray[this.data][ELEM_THUMBNAIL] + "' /></div>" + videoPlay + "</div><div class='html5gallery-tn-title-" + instance.id +
                           "' style='width:" + String(instance.options.thumbwidth - 2) + "px;'>" + instance.elemArray[this.data][ELEM_TITLE] + (instance.options.thumbshowdescription ? "<br /><span class='html5gallery-tn-description-" + instance.id + "'>" + instance.elemArray[this.data][ELEM_INFORMATION] + "</span>" : "") + "</div>");
                        else $("#html5gallery-tn-" + instance.id + "-" + this.data, $thumbContainer).append("<div class='html5gallery-tn-img-" + instance.id + "'" + imgtitle + " style='position:relative;'><div style='display:block; overflow:hidden; position:absolute; width:" +
                           instance.options.thumbimagewidth + "px;height:" + instance.options.thumbimageheight + "px; top:" + instance.options.thumbimageborder + "px; left:" + instance.options.thumbimageborder + "px;'>" + "<img alt='" + instance.html2Text(instance.elemArray[this.data][ELEM_ALT]) + "'" + (instance.options.addimgtitle ? " title='" + instance.html2Text(instance.elemArray[this.data][ELEM_TITLE]) + "'" : "") + " data-originalwidth=" + this.width + " data-originalheight=" + this.height + " class='html5gallery-tn-image html5gallery-tn-image-" + instance.id +
                           "'" + imgtitle + " style='border:none; padding:0px; margin:0px; max-width:100%; max-height:none; width:" + w + "px; height:" + h + "px;' src='" + instance.elemArray[this.data][ELEM_THUMBNAIL] + "' /></div>" + videoPlay + "</div><div class='html5gallery-tn-title-" + instance.id + "'>" + instance.elemArray[this.data][ELEM_TITLE] + (instance.options.thumbshowdescription ? "<br /><span class='html5gallery-tn-description-" + instance.id + "'>" + instance.elemArray[this.data][ELEM_INFORMATION] + "</span>" : "") + "</div>");
                        if (instance.options.thumblinkintitle) {
                           var $thumbImage =
                              $(".html5gallery-tn-img-" + instance.id, $thumbContainer);
                           $thumbImage.each(function () {
                              $(this).off("click").click(function (event) {
                                 var parent = $(this).closest(".html5gallery-tn-" + instance.id);
                                 if (parent.length > 0) {
                                    instance.onThumbClick(parent.data("index"));
                                    instance.slideRun(parent.data("index"), true, true)
                                 }
                              });
                              if (instance.options.switchonmouseover) $(this).off("hover").hover(function () {
                                 var parent = $(this).closest(".html5gallery-tn-" + instance.id);
                                 if (parent.length > 0 && instance.curElem != parent.data("index")) {
                                    instance.onThumbClick(parent.data("index"));
                                    instance.slideRun(parent.data("index"), true, true)
                                 }
                              })
                           })
                        }
                     });
                     imgLoader.src = this.elemArray[i][ELEM_THUMBNAIL]
                  } else $("#html5gallery-tn-" + instance.id + "-" + i, $thumbContainer).append("<div class='html5gallery-tn-title-" + instance.id + "'>" + instance.elemArray[i][ELEM_TITLE] + (instance.options.thumbshowdescription ? "<br /><span class='html5gallery-tn-description-" + instance.id + "'>" + instance.elemArray[i][ELEM_INFORMATION] + "</span>" : "") + "</div>")
               }
               if (this.options.carouselmultirows) $thumbContainer.append("<div style='clear:both;'></div>")
            },
            goNormal: function () {
               this.isFullscreen = false;
               if ($(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).length > 0) $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).stop();
               this.slideshowTimeout.stop();
               $(document).off("keyup.html5gallery");
               $(".html5gallery-timer-" + this.id, this.$gallery).css({
                  width: 0
               });
               if ($(".html5gallery-elem-" + this.id, this.$fullscreen).length > 0) {
                  var $elem = $(".html5gallery-elem-" + this.id, this.$fullscreen).empty().css({
                     top: this.options.elemTop
                  });
                  $(".html5gallery-box-" + this.id,
                     this.$gallery).prepend($elem)
               }
               this.slideRun(this.curElem);
               this.$fullscreen.remove();
               if (this.options.imagetoolboxmode == "show") this.showimagetoolbox(this.elemArray[this.curElem][ELEM_TYPE]);
               else this.hideimagetoolbox()
            },
            goFullscreen: function () {
               this.hideimagetoolbox();
               this.slideshowTimeout.stop();
               $(".html5gallery-fullscreen-timer-" + this.id, this.$fullscreen).css({
                  width: 0
               });
               this.isFullscreen = true;
               this.fullscreenInitial = 20;
               this.fullscreenMargin = this.options.lightboxborder;
               this.fullscreenBarH = this.options.lightboxtextheight;
               this.fullscreenOutsideMargin = this.options.lightboxmargin;
               var fullW = $(window).width();
               var w = this.elemArray[this.curElem][ELEM_WIDTH],
                  h = this.elemArray[this.curElem][ELEM_HEIGHT];
               this.fullscreenWidth = fullW - 2 * this.fullscreenMargin - 2 * this.fullscreenOutsideMargin;
               var winH = $(window).height();
               this.fullscreenHeight = winH - 2 * this.fullscreenMargin - this.fullscreenBarH - 2 * this.fullscreenOutsideMargin;
               var fullH = Math.max(winH, $(document).height());
               var fW = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH],
                  this.fullscreenWidth) : this.fullscreenWidth;
               var fH = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : this.fullscreenHeight;
               var scale = Math.min(fW / w, fH / h);
               if (scale < 1) w *= scale, h *= scale;
               var marginT = $(window).scrollTop() + Math.round((winH - (h + 2 * this.fullscreenMargin + this.fullscreenBarH)) / 2);
               this.$fullscreen = $("<div class='html5gallery-fullscreen-" + this.id + "' style='position:absolute;top:0px;left:0px;width:" + fullW + "px;height:" +
                  fullH + "px;text-align:center;z-index:99999;'>" + "<div class='html5gallery-fullscreen-overlay-" + this.id + "' style='display:block;position:absolute;top:0px;left:0px;width:100%;height:100%;background-color:#000000;opacity:0.9;filter:alpha(opacity=80);'></div>" + "<div class='html5gallery-fullscreen-box-" + this.id + "' style='display:block;overflow:hidden;position:relative;margin:0px auto;top:" + marginT + "px;width:" + this.fullscreenInitial + "px;height:" + this.fullscreenInitial + "px;'>" + "<div class='html5gallery-fullscreen-elem-" +
                  this.id + "' style='display:block;position:relative;overflow:hidden;width:" + String(w + 2 * this.fullscreenMargin) + "px;height:" + String(h + 2 * this.fullscreenMargin) + "px;background-color:" + this.options.lightboxbgcolor + ";'>" + "<div class='html5gallery-fullscreen-elem-wrapper-" + this.id + "' style='display:block;position:relative;overflow:hidden;margin:" + this.fullscreenMargin + "px;'>" + "<div class='html5gallery-fullscreen-timer-" + this.id + "' style='display:block; position:absolute; top:" + String(h - 4) + "px; left:0px; width:0px; height:4px; background-color:#666; filter:alpha(opacity=60); opacity:0.6;'></div>" +
                  "</div>" + "</div>" + "<div class='html5gallery-fullscreen-bar-" + this.id + "' style='display:block;position:relative;width:" + String(w + 2 * this.fullscreenMargin) + "px;height:auto;min-height:36px;background-color:" + this.options.lightboxbgcolor + ";'>" + "<div class='html5gallery-fullscreen-bar-wrapper-" + this.id + "' style='display:block;position:relative;padding:0px " + this.fullscreenMargin + "px " + this.fullscreenMargin + "px " + this.fullscreenMargin + "px;'>" + "<div class='html5gallery-fullscreen-close-" + this.id + "' style='display:block;position:relative;float:right;cursor:pointer;width:32px;height:32px;top:0px;background-image:url(\"" +
                  this.options.skinfolder + "lightbox_close.png\");'></div>" + "<div class='html5gallery-fullscreen-play-" + this.id + "' style='display:" + (this.isPaused && this.elemArray.length > 1 && this.elemArray[this.curElem][ELEM_TYPE] == 1 ? "block" : "none") + ';position:relative;float:right;cursor:pointer;width:32px;height:32px;top:0px;background-image:url("' + this.options.skinfolder + "lightbox_play.png\");'></div>" + "<div class='html5gallery-fullscreen-pause-" + this.id + "' style='display:" + (this.isPaused || this.elemArray.length <= 1 ||
                     this.elemArray[this.curElem][ELEM_TYPE] != 1 ? "none" : "block") + ';position:relative;float:right;cursor:pointer;width:32px;height:32px;top:0px;background-image:url("' + this.options.skinfolder + "lightbox_pause.png\");'></div>" + "<div class='html5gallery-fullscreen-title-" + this.id + "' style='display:block;position:relative;float:left;width:" + String(w - 2 * this.fullscreenMargin - 72) + "px;height:auto;top:0px;left:0px;text-align:left;'></div>" + "<div style='clear:both;'></div>" + "</div>" + "</div>" + "<div class='html5gallery-fullscreen-next-" +
                  this.id + "' style='display:none;position:absolute;cursor:pointer;width:48px;height:48px;right:" + this.fullscreenMargin + "px;top:" + Math.round(h / 2) + 'px;background-image:url("' + this.options.skinfolder + "lightbox_next.png\");'></div>" + "<div class='html5gallery-fullscreen-prev-" + this.id + "' style='display:none;position:absolute;cursor:pointer;width:48px;height:48px;left:" + this.fullscreenMargin + "px;top:" + Math.round(h / 2) + 'px;background-image:url("' + this.options.skinfolder + "lightbox_prev.png\");'></div>" + "</div>" +
                  "</div>");
               this.$fullscreen.appendTo("body");
               var instance = this;
               $(window).scroll(function () {
                  if (instance.options.isMobile && !instance.options.mobileresizeevent) return;
                  var $box = $(".html5gallery-fullscreen-box-" + instance.id, instance.$fullscreen);
                  var winH = $(window).height();
                  var marginT = $(window).scrollTop() + Math.round((winH - $box.height()) / 2);
                  $box.css({
                     "top": marginT
                  })
               });
               this.createSocial(true);
               $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).animate({
                     height: h + 2 * this.fullscreenMargin
                  }, instance.options.lightboxanimationspeed,
                  function () {
                     $(this).animate({
                        width: w + 2 * instance.fullscreenMargin
                     }, instance.options.lightboxanimationspeed, function () {
                        $(this).animate({
                           height: "+=" + instance.fullscreenBarH
                        }, instance.options.lightboxanimationspeed, function () {
                           if (instance.isFullscreen) {
                              var $elem = $(".html5gallery-elem-" + instance.id, instance.$gallery).empty().css({
                                 top: 0,
                                 position: "relative"
                              });
                              $(".html5gallery-fullscreen-elem-wrapper-" + instance.id, instance.$fullscreen).prepend($elem);
                              instance.slideRun(instance.curElem);
                              if (instance.options.showsocial) $(".html5gallery-fullscreen-social-" +
                                 instance.id, instance.$fullscreen).show()
                           }
                        })
                     })
                  });
               $(".html5gallery-fullscreen-overlay-" + this.id, this.$fullscreen).click(function () {
                  instance.goNormal()
               });
               $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).hover(function () {
                  if (instance.elemArray.length > 1) {
                     $(".html5gallery-fullscreen-next-" + instance.id, instance.$fullscreen).fadeIn();
                     $(".html5gallery-fullscreen-prev-" + instance.id, instance.$fullscreen).fadeIn()
                  }
               }, function () {
                  $(".html5gallery-fullscreen-next-" + instance.id, instance.$fullscreen).fadeOut();
                  $(".html5gallery-fullscreen-prev-" + instance.id, instance.$fullscreen).fadeOut()
               });
               if (instance.options.enabletouchswipe) {
                  var preventBrowser = instance.options.isAndroid && instance.options.enabletouchswipeonandroid ? true : false;
                  $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).touchSwipe({
                     preventWebBrowser: preventBrowser,
                     swipeLeft: function () {
                        if (!instance.disableTouchSwipe) instance.slideRun(-1)
                     },
                     swipeRight: function () {
                        if (!instance.disableTouchSwipe) instance.slideRun(-2)
                     }
                  })
               }
               $(".html5gallery-fullscreen-close-" +
                  this.id, this.$fullscreen).click(function () {
                  instance.goNormal()
               });
               $(".html5gallery-fullscreen-next-" + this.id, this.$fullscreen).click(function () {
                  instance.slideRun(-1)
               });
               $(".html5gallery-fullscreen-prev-" + this.id, this.$fullscreen).click(function () {
                  instance.slideRun(-2)
               });
               $(".html5gallery-fullscreen-play-" + this.id, this.$fullscreen).click(function () {
                  $(".html5gallery-fullscreen-play-" + instance.id, instance.$fullscreen).hide();
                  $(".html5gallery-fullscreen-pause-" + instance.id, instance.$fullscreen).show();
                  instance.isPaused =
                     false;
                  var slideshowinterval = instance.elemArray[instance.curElem][ELEM_DURATION] ? instance.elemArray[instance.curElem][ELEM_DURATION] : instance.options.slideshowinterval;
                  instance.slideshowTimeout.setInterval(slideshowinterval);
                  instance.slideshowTimeout.start();
                  $(".html5gallery-fullscreen-timer-" + instance.id, instance.$fullscreen).css({
                     width: 0
                  })
               });
               $(".html5gallery-fullscreen-pause-" + this.id, this.$fullscreen).click(function () {
                  $(".html5gallery-fullscreen-play-" + instance.id, instance.$fullscreen).show();
                  $(".html5gallery-fullscreen-pause-" +
                     instance.id, instance.$fullscreen).hide();
                  instance.isPaused = true;
                  instance.slideshowTimeout.stop();
                  $(".html5gallery-fullscreen-timer-" + instance.id, instance.$fullscreen).css({
                     width: 0
                  })
               });
               $(document).on("keyup.html5gallery", function (e) {
                  if (e.keyCode == 27) instance.goNormal();
                  else if (e.keyCode == 39) instance.slideRun(-1);
                  else if (e.keyCode == 37) instance.slideRun(-2)
               })
            },
            calcIndex: function (index) {
               this.savedElem = this.curElem;
               if (index == -2) {
                  this.nextElem = this.curElem;
                  this.curElem = this.prevElem;
                  this.prevElem = this.curElem -
                     1 < 0 ? this.elemArray.length - 1 : this.curElem - 1
               } else if (index == -1) {
                  this.prevElem = this.curElem;
                  this.curElem = this.nextElem;
                  this.nextElem = this.curElem + 1 >= this.elemArray.length ? 0 : this.curElem + 1
               } else if (index >= 0) {
                  this.curElem = index;
                  this.prevElem = this.curElem - 1 < 0 ? this.elemArray.length - 1 : this.curElem - 1;
                  this.nextElem = this.curElem + 1 >= this.elemArray.length ? 0 : this.curElem + 1
               }
            },
            showSlideTimer: function () {
               var slideshowinterval = this.elemArray[this.curElem][ELEM_DURATION] ? this.elemArray[this.curElem][ELEM_DURATION] : this.options.slideshowinterval;
               this.slideTimerCount++;
               if (this.isFullscreen) $(".html5gallery-fullscreen-timer-" + this.id, this.$fullscreen).width(Math.round($(".html5gallery-fullscreen-elem-wrapper-" + this.id, this.$fullscreen).width() * 50 * (this.slideTimerCount + 1) / slideshowinterval));
               else $(".html5gallery-timer-" + this.id, this.$gallery).width(Math.round(this.options.boxWidth * 50 * (this.slideTimerCount + 1) / slideshowinterval))
            },
            setHd: function (isHd, switching) {
               var type = this.elemArray[this.curElem][ELEM_TYPE];
               var toSwitch = this.isHd != isHd && switching &&
                  (type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM);
               this.isHd = isHd;
               if (toSwitch) this.slideRun(this.curElem, false, false, true)
            },
            enableUpdateCarousel: function () {
               this.disableupdatecarousel = false
            },
            slideRun: function (index, navClicked, thumbClicked, videoSwitching) {
               this.slideshowTimeout.stop();
               if (this.isFullscreen) $(".html5gallery-fullscreen-timer-" + this.id, this.$fullscreen).css({
                  width: 0
               });
               else $(".html5gallery-timer-" + this.id, this.$gallery).css({
                  width: 0
               });
               if (this.options.showcarousel &&
                  this.curElem >= 0) $("#html5gallery-tn-" + this.id + "-" + this.curElem, this.$gallery).removeClass("html5gallery-tn-selected-" + this.id);
               this.calcIndex(index);
               if (this.isFullscreen) {
                  this.$fullscreen.addClass("html5gallery-fullscreen-activeslide-" + this.id + "-" + this.curElem);
                  if (this.prevElem >= 0) this.$fullscreen.removeClass("html5gallery-fullscreen-activeslide-" + this.id + "-" + this.prevElem)
               } else {
                  this.$gallery.addClass("html5gallery-activeslide-" + this.id + "-" + this.curElem);
                  if (this.prevElem >= 0) this.$gallery.removeClass("html5gallery-activeslide-" +
                     this.id + "-" + this.prevElem)
               }
               if (!this.options.arrowloop)
                  if (this.isFullscreen) {
                     $(".html5gallery-fullscreen-prev-" + this.id, this.$fullscreen).css({
                        visibility: this.curElem == 0 ? "hidden" : "visible"
                     });
                     $(".html5gallery-fullscreen-next-" + this.id, this.$fullscreen).css({
                        visibility: this.curElem == this.elemArray.length - 1 ? "hidden" : "visible"
                     })
                  } else {
                     $(".html5gallery-left-" + this.id, this.$gallery).css({
                        visibility: this.curElem == 0 ? "hidden" : "visible"
                     });
                     $(".html5gallery-right-" + this.id, this.$gallery).css({
                        visibility: this.curElem ==
                           this.elemArray.length - 1 ? "hidden" : "visible"
                     })
                  } if (this.options.socialurlforeach) this.createSocialMedia();
               if (!this.isFullscreen && this.options.showcarousel) {
                  $("#html5gallery-tn-" + this.id + "-" + this.curElem, this.$gallery).addClass("html5gallery-tn-selected-" + this.id);
                  if (!this.options.notupdatecarousel && !this.disableupdatecarousel) this.carouselHighlight(this.curElem)
               }
               if (this.options.showtitle || this.options.lightboxshowtitle || this.options.lightboxshowdescription) {
                  var title = this.elemArray[this.curElem][ELEM_TITLE];
                  var description = this.elemArray[this.curElem][ELEM_INFORMATION];
                  if (this.options.shownumbering) title = this.options.numberingformat.replace("%NUM", this.curElem + 1).replace("%TOTAL", this.elemArray.length) + " " + title;
                  if (this.isFullscreen) {
                     var fullscreentitle = "";
                     if (this.options.lightboxshowtitle && title) fullscreentitle += title;
                     if (this.options.lightboxshowdescription && description) fullscreentitle += "<div class='html5gallery-fullscreen-description-" + this.id + "'>" + description + "</div>";
                     $(".html5gallery-fullscreen-title-" +
                        this.id, this.$fullscreen).html(fullscreentitle)
                  } else if (this.options.showtitle) {
                     var titleHtml = "";
                     if (title) titleHtml += "<div class='html5gallery-title-text-" + this.id + "'>" + title + "</div>";
                     if (this.options.showdescription && description) titleHtml += "<div class='html5gallery-description-text-" + this.id + "'>" + description + "</div>";
                     $(".html5gallery-title-" + this.id, this.$gallery).html(titleHtml)
                  }
                  if (!this.options.titleoverlay || !this.options.titleautohide) $(".html5gallery-title-" + this.id, this.$gallery).show()
               }
               var type =
                  this.elemArray[this.curElem][ELEM_TYPE];
               if (type < 0) return;
               if (!this.isFullscreen && navClicked)
                  if (this.options.showimagetoolbox == "always") {
                     if (this.options.imagetoolboxmode == "mouseover" || this.options.imagetoolboxmode == "show") this.showimagetoolbox(type)
                  } else {
                     if (this.options.showimagetoolbox == "image" && type != TYPE_IMAGE) this.hideimagetoolbox()
                  }
               else if (this.options.imagetoolboxmode == "show") this.showimagetoolbox(type);
               else this.hideimagetoolbox();
               this.onChange();
               var $elem = $(".html5gallery-elem-" + this.id, parent);
               $elem.find("iframe").each(function () {
                  $(this).attr("src", "")
               });
               $elem.find("video").each(function () {
                  $(this).attr("src", "")
               });
               this.disableTouchSwipe = false;
               this.isVideoPlaying = false;
               var playVideo = this.options.autoplayvideo || this.options.playvideoonclick && thumbClicked || videoSwitching;
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               this.showingPoster = false;
               if (!this.options.donotuseposter && (type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM || type == TYPE_VIDEO_YOUTUBE ||
                     type == TYPE_VIDEO_VIMEO || type == TYPE_EMBED_VIDEO) && !playVideo && this.elemArray[this.curElem][ELEM_POSTER]) {
                  this.showingPoster = true;
                  this.showPoster()
               } else {
                  if ($(".html5gallery-video-play-" + this.id, parent).length) $(".html5gallery-video-play-" + this.id, parent).remove();
                  if (type == TYPE_IMAGE) this.showImage();
                  else {
                     if (this.options.hidetitlewhenvideoisplaying) $(".html5gallery-title-" + this.id, parent).hide();
                     if (type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM) this.showVideo(playVideo,
                        videoSwitching);
                     else if (type == TYPE_VIDEO_YOUTUBE) this.showYoutube(playVideo);
                     else if (type == TYPE_VIDEO_VIMEO) this.showVimeo(playVideo);
                     else if (type == TYPE_EMBED_VIDEO) this.showEmbedVideo(playVideo);
                     else if (type == TYPE_SWF) this.showSWF();
                     else if (type == TYPE_IFRAME) this.showIframe()
                  }
               }
               this.checkMK();
               if (this.prevElem in this.elemArray && this.elemArray[this.prevElem][ELEM_TYPE] == 1)(new Image).src = this.elemArray[this.prevElem][ELEM_SRC];
               if (this.nextElem in this.elemArray && this.elemArray[this.nextElem][ELEM_TYPE] ==
                  1)(new Image).src = this.elemArray[this.nextElem][ELEM_SRC];
               if (this.prevElem in this.elemArray && !this.options.autoplayvideo && this.elemArray[this.prevElem][ELEM_POSTER])(new Image).src = this.elemArray[this.prevElem][ELEM_POSTER];
               if (this.nextElem in this.elemArray && !this.options.autoplayvideo && this.elemArray[this.nextElem][ELEM_POSTER])(new Image).src = this.elemArray[this.nextElem][ELEM_POSTER];
               if (this.curElem == this.elemArray.length - 1) this.looptimes++;
               var instance = this;
               if ((type == TYPE_IMAGE || this.showingPoster) &&
                  !this.isPaused && this.elemArray.length > 1 && (!this.options.loop || this.looptimes < this.options.loop)) {
                  var slideshowinterval = this.elemArray[this.curElem][ELEM_DURATION] ? this.elemArray[this.curElem][ELEM_DURATION] : this.options.slideshowinterval;
                  if (this.firstrun && this.options.setfirstslideshowinterval) slideshowinterval = this.options.firstslideshowinterval;
                  this.slideshowTimeout.setInterval(slideshowinterval);
                  this.slideshowTimeout.start();
                  if (this.isFullscreen) $(".html5gallery-fullscreen-timer-" + this.id, this.$fullscreen).css({
                     width: 0
                  });
                  else $(".html5gallery-timer-" + this.id, this.$gallery).css({
                     width: 0
                  })
               }
               if (this.options.loop && this.looptimes >= this.options.loop) {
                  this.looptimes = 0;
                  this.pauseGallery()
               }
               var type = this.elemArray[this.curElem][ELEM_TYPE];
               if ((this.elemArray[this.curElem][ELEM_LINK] || (this.options.lightbox || this.elemArray[this.curElem][ELEM_LIGHTBOX]) && !this.isFullscreen) && !(this.options.linkonlyonvideo && (type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM))) {
                  $elem.css({
                     cursor: "pointer"
                  });
                  $elem.off("click").on("click", function () {
                     if ((instance.options.lightbox || instance.elemArray[instance.curElem][ELEM_LIGHTBOX]) && !instance.isFullscreen) instance.goFullscreen();
                     else if (instance.elemArray[instance.curElem][ELEM_LINK])
                        if (instance.elemArray[instance.curElem][ELEM_LINKTARGET]) window.open(instance.elemArray[instance.curElem][ELEM_LINK], instance.elemArray[instance.curElem][ELEM_LINKTARGET]);
                        else window.open(instance.elemArray[instance.curElem][ELEM_LINK])
                  })
               } else {
                  $elem.css({
                     cursor: ""
                  });
                  $elem.off("click")
               }
            },
            showImage: function () {
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var $elem = $(".html5gallery-elem-" + this.id, parent);
               if ($elem.html() === "") $preloading = $("<div class='html5gallery-loading-center-" + this.id + "'></div>").appendTo($elem);
               else $preloading = $("<div class='html5gallery-loading-" + this.id + "'></div>").appendTo($elem);
               var instance = this;
               var imgLoader = new Image;
               $(imgLoader).on("load", function () {
                  $preloading.remove();
                  instance.elemArray[instance.curElem][ELEM_WIDTH] = this.width;
                  instance.elemArray[instance.curElem][ELEM_HEIGHT] =
                     this.height;
                  var scale;
                  if (instance.isFullscreen) {
                     var fullW = instance.elemArray[instance.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(instance.elemArray[instance.curElem][ELEM_LIGHTBOXWIDTH], instance.fullscreenWidth) : instance.fullscreenWidth;
                     var fullH = instance.elemArray[instance.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(instance.elemArray[instance.curElem][ELEM_LIGHTBOXHEIGHT], instance.fullscreenHeight) : instance.fullscreenHeight;
                     scale = Math.min(fullW / this.width, fullH / this.height);
                     scale = scale > 1 ? 1 : scale
                  } else if (instance.options.resizemode ==
                     "fill") scale = Math.max(instance.options.width / this.width, instance.options.height / this.height);
                  else scale = Math.min(instance.options.width / this.width, instance.options.height / this.height);
                  var w = Math.round(scale * this.width);
                  var h = Math.round(scale * this.height);
                  var w1 = instance.isFullscreen ? w : instance.options.width;
                  var h1 = instance.isFullscreen ? h : instance.options.height;
                  var l = Math.round(w1 / 2 - w / 2);
                  var t = Math.round(h1 / 2 - h / 2);
                  if (instance.isFullscreen) instance.adjustFullscreen(w1, h1);
                  $elem.css({
                     "width": w1,
                     "height": h1
                  });
                  var $imgCur = $("<div class='html5gallery-elem-img-" + instance.id + "' style='display:block; position:absolute; overflow:hidden; width:" + w1 + "px; height:" + h1 + "px; left:0px; margin-left:" + (instance.options.slideshadow && !instance.isFullscreen ? 4 : 0) + "px; top:0px; margin-top:" + (instance.options.slideshadow && !instance.isFullscreen ? 4 : 0) + "px;'>" + "<img alt='" + instance.html2Text(instance.elemArray[instance.curElem][ELEM_ALT]) + "'" + (instance.options.addimgtitle ? " title='" + instance.html2Text(instance.elemArray[instance.curElem][ELEM_TITLE]) +
                     "'" : "") + " class='html5gallery-elem-image html5gallery-elem-image-" + instance.id + "' style='border:none; position:absolute; opacity:inherit; filter:inherit; padding:0px; margin:0px; left:" + l + "px; top:" + t + "px; max-width:none; max-height:none; width:" + w + "px; height:" + h + "px;' src='" + instance.elemArray[instance.curElem][ELEM_SRC] + "' />" + instance.options.watermarkcode + "</div>");
                  var $imgPrev = $(".html5gallery-elem-img-" + instance.id, $elem);
                  if ($imgPrev.length) {
                     $elem.prepend($imgCur);
                     $elem.html5boxTransition(instance.id,
                        $imgPrev, $imgCur, {
                           effect: instance.options.effect,
                           easing: instance.options.easing,
                           duration: instance.options.duration,
                           direction: instance.curElem >= instance.savedElem,
                           slide: instance.options.slide
                        },
                        function () {})
                  } else $elem.html($imgCur);
                  if (instance.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Image", {
                     "Action": "Play",
                     "URL": instance.elemArray[instance.curElem][ELEM_SRC]
                  });
                  if (instance.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Image", "Play", instance.elemArray[instance.curElem][ELEM_SRC]]);
                  instance.checkMK()
               });
               $(imgLoader).on("error", function () {
                  $preloading.remove();
                  if (instance.isFullscreen) instance.adjustFullscreen(instance.options.width, instance.options.height);
                  $elem.html("<div class='html5gallery-elem-error-" + instance.id + "' style='display:block; position:absolute; overflow:hidden; text-align:center; width:" + instance.options.width + "px; left:0px; top:" + Math.round(instance.options.height / 2 - 10) + "px; margin:4px;'><div class='html5gallery-error-" + instance.id + "'>The requested content cannot be found</div>");
                  if (instance.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Image", {
                     "Action": "Error",
                     "URL": instance.elemArray[instance.curElem][ELEM_SRC]
                  });
                  if (instance.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Image", "Error", instance.elemArray[instance.curElem][ELEM_SRC]])
               });
               imgLoader.src = this.elemArray[this.curElem][ELEM_SRC]
            },
            adjustFullscreen: function (w1, h1, noanimation) {
               var fullW = $(window).width();
               this.fullscreenWidth = fullW - 2 * this.fullscreenMargin - 2 * this.fullscreenOutsideMargin;
               var winH = $(window).height();
               this.fullscreenHeight = winH - 2 * this.fullscreenMargin - this.fullscreenBarH - 2 * this.fullscreenOutsideMargin;
               var fullH = Math.max(winH, $(document).height());
               var fW = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : this.fullscreenWidth;
               var fH = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : this.fullscreenHeight;
               var scale =
                  Math.min(fW / w1, fH / h1);
               if (scale < 1) w1 *= scale, h1 *= scale;
               var marginT = $(window).scrollTop() + Math.round((winH - (h1 + 2 * this.fullscreenMargin + this.fullscreenBarH)) / 2);
               $(".html5gallery-fullscreen-" + this.id).css({
                  width: fullW + "px",
                  height: fullH + "px"
               });
               $(".html5gallery-fullscreen-title-" + this.id, this.$fullscreen).css({
                  "width": w1 - 2 * this.fullscreenMargin - 72
               });
               if (noanimation) {
                  $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).css({
                     "width": w1 + 2 * this.fullscreenMargin,
                     "height": h1 + 2 * this.fullscreenMargin + this.fullscreenBarH,
                     "top": marginT
                  });
                  $(".html5gallery-fullscreen-elem-" + this.id, this.$fullscreen).css({
                     "width": w1 + 2 * this.fullscreenMargin,
                     "height": h1 + 2 * this.fullscreenMargin
                  });
                  $(".html5gallery-fullscreen-elem-wrapper-" + this.id, this.$fullscreen).css({
                     "width": w1,
                     "height": h1
                  });
                  $(".html5gallery-fullscreen-bar-" + this.id, this.$fullscreen).css({
                     "width": w1 + 2 * this.fullscreenMargin
                  })
               } else {
                  $(".html5gallery-fullscreen-box-" + this.id, this.$fullscreen).animate({
                     "width": w1 + 2 * this.fullscreenMargin,
                     "height": h1 + 2 * this.fullscreenMargin +
                        this.fullscreenBarH,
                     "top": marginT
                  }, this.options.lightboxanimationspeed);
                  $(".html5gallery-fullscreen-elem-" + this.id, this.$fullscreen).animate({
                     "width": w1 + 2 * this.fullscreenMargin,
                     "height": h1 + 2 * this.fullscreenMargin
                  }, this.options.lightboxanimationspeed);
                  $(".html5gallery-fullscreen-elem-wrapper-" + this.id, this.$fullscreen).animate({
                     "width": w1,
                     "height": h1
                  }, this.options.lightboxanimationspeed);
                  $(".html5gallery-fullscreen-bar-" + this.id, this.$fullscreen).animate({
                     "width": w1 + 2 * this.fullscreenMargin
                  }, this.options.lightboxanimationspeed)
               }
               $(".html5gallery-fullscreen-next-" +
                  this.id, this.$fullscreen).css({
                  "top": Math.round(h1 / 2)
               });
               $(".html5gallery-fullscreen-prev-" + this.id, this.$fullscreen).css({
                  "top": Math.round(h1 / 2)
               });
               $(".html5gallery-fullscreen-play-" + this.id, this.$fullscreen).css("display", this.isPaused && this.elemArray.length > 1 && this.elemArray[this.curElem][ELEM_TYPE] == 1 ? "block" : "none");
               $(".html5gallery-fullscreen-pause-" + this.id, this.$fullscreen).css("display", this.isPaused || this.elemArray.length <= 1 || this.elemArray[this.curElem][ELEM_TYPE] != 1 ? "none" : "block");
               $(".html5gallery-elem-" +
                  this.id, this.$fullscreen).css({
                  "width": w1,
                  "height": h1
               });
               $(".html5gallery-fullscreen-timer-" + this.id, this.$fullscreen).css({
                  top: String(h1 - 4) + "px"
               });
               $(".html5gallery-elem-video-" + this.id, this.$fullscreen).css({
                  "width": w1 + "px",
                  "height": h1 + "px"
               });
               $(".html5gallery-elem-video-container-" + this.id, this.$fullscreen).css({
                  "width": "100%",
                  "height": "100%"
               });
               $(".html5gallery-elem-video-container-" + this.id, this.$fullscreen).find("video").css({
                  "width": "100%",
                  "height": "100%"
               });
               $("#html5gallery-elem-video-" + this.id,
                  this.$fullscreen).css({
                  "width": w1 + "px",
                  "height": h1 + "px"
               });
               $("#html5gallery-elem-video-" + this.id, this.$fullscreen).attr("width", w1);
               $("#html5gallery-elem-video-" + this.id, this.$fullscreen).attr("height", h1);
               $(".html5gallery-elem-video-" + this.id, this.$fullscreen).find("iframe").attr("width", w1);
               $(".html5gallery-elem-video-" + this.id, this.$fullscreen).find("iframe").attr("height", h1);
               $("#html5gallery-elem-video-" + this.id, this.$fullscreen).find("iframe").attr("width", w1);
               $("#html5gallery-elem-video-" + this.id,
                  this.$fullscreen).find("iframe").attr("height", h1);
               $(".html5gallery-elem-iframe-" + this.id, this.$fullscreen).css({
                  "width": w1 + "px",
                  "height": h1 + "px"
               });
               $(".html5gallery-elem-iframe-" + this.id, this.$fullscreen).find("iframe").attr("width", w1);
               $(".html5gallery-elem-iframe-" + this.id, this.$fullscreen).find("iframe").attr("height", h1)
            },
            showPoster: function () {
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var $elem = $(".html5gallery-elem-" + this.id, parent);
               if ($elem.html() === "") $preloading = $("<div class='html5gallery-loading-center-" +
                  this.id + "'></div>").appendTo($elem);
               else $preloading = $("<div class='html5gallery-loading-" + this.id + "'></div>").appendTo($elem);
               var instance = this;
               var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
               var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
               var imgLoader = new Image;
               $(imgLoader).on("load", function () {
                  $preloading.remove();
                  instance.elemArray[instance.curElem][ELEM_POSTERWIDTH] = this.width;
                  instance.elemArray[instance.curElem][ELEM_POSTERHEIGHT] = this.height;
                  var scale, w1, h1;
                  if (instance.isFullscreen) {
                     var lw =
                        instance.elemArray[instance.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(instance.elemArray[instance.curElem][ELEM_LIGHTBOXWIDTH], instance.fullscreenWidth) : Math.min(dataW, instance.fullscreenWidth);
                     var lh = instance.elemArray[instance.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(instance.elemArray[instance.curElem][ELEM_LIGHTBOXHEIGHT], instance.fullscreenHeight) : Math.min(dataH, instance.fullscreenHeight);
                     scale = Math.max(lw / this.width, lh / this.height);
                     scale = scale > 1 ? 1 : scale;
                     w1 = lw;
                     h1 = lh
                  } else {
                     if (instance.options.resizemode ==
                        "fill") scale = Math.max(instance.options.width / this.width, instance.options.height / this.height);
                     else scale = Math.min(instance.options.width / this.width, instance.options.height / this.height);
                     w1 = instance.options.width;
                     h1 = instance.options.height
                  }
                  var w = Math.round(scale * this.width);
                  var h = Math.round(scale * this.height);
                  var l = Math.round(w1 / 2 - w / 2);
                  var t = Math.round(h1 / 2 - h / 2);
                  if (instance.isFullscreen) instance.adjustFullscreen(w1, h1);
                  $elem.css({
                     "width": w1,
                     "height": h1
                  });
                  var $imgCur = $("<div class='html5gallery-elem-img-" +
                     instance.id + "' style='display:block; position:absolute; overflow:hidden; width:" + w1 + "px; height:" + h1 + "px; left:0px; margin-left:" + (instance.options.slideshadow && !instance.isFullscreen ? 4 : 0) + "px; top:0px; margin-top:" + (instance.options.slideshadow && !instance.isFullscreen ? 4 : 0) + "px;'>" + "<img alt='" + instance.html2Text(instance.elemArray[instance.curElem][ELEM_ALT]) + "'" + (instance.options.addimgtitle ? " title='" + instance.html2Text(instance.elemArray[instance.curElem][ELEM_TITLE]) + "'" : "") + " class='html5gallery-elem-image html5gallery-elem-image-" +
                     instance.id + "' style='border:none; position:absolute; opacity:inherit; filter:inherit; padding:0px; margin:0px; left:" + l + "px; top:" + t + "px; max-width:none; max-height:none; width:" + w + "px; height:" + h + "px;' src='" + instance.elemArray[instance.curElem][ELEM_POSTER] + "' />" + instance.options.watermarkcode + "</div>");
                  var $imgPrev = $(".html5gallery-elem-img-" + instance.id, $elem);
                  if ($imgPrev.length) {
                     $elem.prepend($imgCur);
                     $elem.html5boxTransition(instance.id, $imgPrev, $imgCur, {
                        effect: instance.options.effect,
                        easing: instance.options.easing,
                        duration: instance.options.duration,
                        direction: instance.curElem >= instance.savedElem,
                        slide: instance.options.slide
                     }, function () {})
                  } else $elem.html($imgCur);
                  if (!$(".html5gallery-video-play-" + instance.id, parent).length) {
                     var $play = $("<div class='html5gallery-video-play-" + instance.id + "' style='position:absolute;display:block;cursor:pointer;top:50%;left:50%;width:64px;height:64px;margin-left:-32px;margin-top:-32px;background:url(\"" + instance.options.playvideoimage + "\") no-repeat center center;'></div>").appendTo($elem);
                     $play.off(instance.eClick).on(instance.eClick, function () {
                        if (instance.options.hidetitlewhenvideoisplaying) $(".html5gallery-title-" + instance.id, instance.$gallery).hide();
                        $(this).remove();
                        instance.slideshowTimeout.stop();
                        $(".html5gallery-timer-" + instance.id, instance.$gallery).css({
                           width: 0
                        });
                        instance.showingPoster = false;
                        var type = instance.elemArray[instance.curElem][ELEM_TYPE];
                        if (type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM) instance.showVideo(true);
                        else if (type ==
                           TYPE_VIDEO_YOUTUBE) instance.showYoutube(true);
                        else if (type == TYPE_VIDEO_VIMEO) instance.showVimeo(true);
                        else if (type == TYPE_EMBED_VIDEO) instance.showEmbedVideo(true);
                        instance.checkMK()
                     })
                  }
                  instance.checkMK()
               });
               $(imgLoader).on("error", function () {
                  $preloading.remove();
                  if (instance.isFullscreen) instance.adjustFullscreen(instance.options.width, instance.options.height);
                  $elem.html("<div class='html5gallery-elem-error-" + instance.id + "' style='display:block; position:absolute; overflow:hidden; text-align:center; width:" +
                     instance.options.width + "px; left:0px; top:" + Math.round(instance.options.height / 2 - 10) + "px; margin:4px;'><div class='html5gallery-error-" + instance.id + "'>The requested content cannot be found</div>");
                  if (instance.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Image", {
                     "Action": "Error",
                     "URL": instance.elemArray[instance.curElem][ELEM_POSTER]
                  });
                  if (instance.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Image", "Error", instance.elemArray[instance.curElem][ELEM_POSTER]])
               });
               imgLoader.src = this.elemArray[this.curElem][ELEM_POSTER]
            },
            getFlashMovieObject: function (movieName) {
               if (window.document[movieName]) return window.document[movieName];
               if (navigator.appName.indexOf("Microsoft Internet") == -1) {
                  if (document.embeds && document.embeds[movieName]) return document.embeds[movieName]
               } else return document.getElementById(movieName)
            },
            playVideo: function () {
               var type = this.elemArray[this.curElem][ELEM_TYPE];
               if (type == TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM)
                  if (this.isHTML5 &&
                     $("#html5gallery-elem-html5-video-" + this.id).length > 0) $("#html5gallery-elem-html5-video-" + this.id, this.container).get(0).play();
                  else {
                     var flashObj = this.getFlashMovieObject("html5gallery-elem-video-flash-" + this.id);
                     if (flashObj && typeof flashObj.playVideo === "function") flashObj.playVideo()
                  }
            },
            stopAllPlaying: function () {
               if ($("video").length) $("video").each(function () {
                  this.pause()
               });
               if ($("audio").length) $("audio").each(function () {
                  this.pause()
               });
               if (typeof html5GalleryObjects !== "undefined" && html5GalleryObjects &&
                  html5GalleryObjects.objects)
                  for (var i = 0; i < html5GalleryObjects.objects.length; i++) {
                     if (html5GalleryObjects.objects[i].id == this.id) continue;
                     try {
                        if (html5GalleryObjects.objects[i].ytPlayer && typeof html5GalleryObjects.objects[i].ytPlayer.pauseVideo == "function") html5GalleryObjects.objects[i].ytPlayer.pauseVideo();
                        if (html5GalleryObjects.objects[i].vimeoPlayer) html5GalleryObjects.objects[i].vimeoPlayer.api("pause")
                     } catch (err) {}
                  }
            },
            pauseVideo: function () {
               var type = this.elemArray[this.curElem][ELEM_TYPE];
               if (type ==
                  TYPE_VIDEO_FLASH || type == TYPE_VIDEO_MP4 || type == TYPE_VIDEO_OGG || type == TYPE_VIDEO_WEBM)
                  if (this.isHTML5 && $("#html5gallery-elem-html5-video-" + this.id).length > 0) $("#html5gallery-elem-html5-video-" + this.id, this.container).get(0).pause();
                  else {
                     var flashObj = this.getFlashMovieObject("html5gallery-elem-video-flash-" + this.id);
                     if (flashObj && typeof flashObj.pauseVideo === "function") flashObj.pauseVideo()
                  }
               else if (type == TYPE_VIDEO_YOUTUBE) {
                  if (this.ytPlayer && typeof this.ytPlayer.pauseVideo == "function") this.ytPlayer.pauseVideo()
               } else if (type ==
                  TYPE_VIDEO_VIMEO) {
                  if (this.vimeoPlayer) this.vimeoPlayer.api("pause")
               } else if ($("video", this.container).length) $("video", this.container).get(0).pause()
            },
            showVideo: function (autoPlay, videoSwitching) {
               if (this.options.stopallplaying) this.stopAllPlaying();
               this.isVideoPlaying = true;
               if (autoPlay && this.options.autoslideandplayafterfirstplayed) {
                  this.options.autoplayvideo = true;
                  this.isPaused = false
               }
               this.disableTouchSwipe = true;
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
               var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
               var w1, h1;
               if (this.isFullscreen) {
                  var lw = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : Math.min(dataW, this.fullscreenWidth);
                  var lh = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : Math.min(dataH, this.fullscreenHeight);
                  this.adjustFullscreen(lw, lh);
                  w1 = lw;
                  h1 = lh
               } else {
                  $(".html5gallery-elem-" +
                     this.id, this.$gallery).css({
                     "width": this.options.width,
                     "height": this.options.height
                  });
                  w1 = this.options.width;
                  h1 = this.options.height
               }
               var timeStamp = -1;
               if (videoSwitching && $(".html5gallery-elem-" + this.id, parent).find("video").length) timeStamp = $(".html5gallery-elem-" + this.id, parent).find("video:first").get(0).currentTime;
               $(".html5gallery-elem-" + this.id, parent).html("<div class='html5gallery-loading-center-" + this.id + "'></div><div class='html5gallery-elem-video-" + this.id + "' style='display:block;position:absolute;overflow:hidden;top:" +
                  (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;left:" + (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;width:" + w1 + "px;height:" + h1 + "px;'></div>" + this.options.watermarkcode);
               this.isHTML5 = false;
               if (this.options.isIE678 || this.options.isIE9 && this.options.useflashonie9 || this.options.isIE10 && this.options.useflashonie10 || this.options.isIE11 && this.options.useflashonie11) this.isHTML5 = false;
               else if (this.options.isMobile) this.isHTML5 = true;
               else if ((this.options.html5player || !this.options.flashInstalled) &&
                  this.options.html5VideoSupported) {
                  this.isHTML5 = true;
                  if (this.options.isFirefox || this.options.isOpera)
                     if (!this.elemArray[this.curElem][ELEM_SRC_WEBM] && !this.elemArray[this.curElem][ELEM_SRC_OGG] && (!this.options.canplaymp4 || this.options.useflashformp4onfirefox)) this.isHTML5 = false
               }
               var videoSrc = this.elemArray[this.curElem][ELEM_SRC];
               var videoHd = this.elemArray[this.curElem][ELEM_HD];
               if (this.options.isFirefox || this.options.isOpera) {
                  if (this.elemArray[this.curElem][ELEM_SRC_WEBM]) videoSrc = this.elemArray[this.curElem][ELEM_SRC_WEBM];
                  else if (this.elemArray[this.curElem][ELEM_SRC_OGG]) videoSrc = this.elemArray[this.curElem][ELEM_SRC_OGG];
                  if (this.elemArray[this.curElem][ELEM_HD_WEBM]) videoHd = this.elemArray[this.curElem][ELEM_HD_WEBM];
                  else if (this.elemArray[this.curElem][ELEM_HD_OGG]) videoHd = this.elemArray[this.curElem][ELEM_HD_OGG]
               }
               this.embedHTML5Video($(".html5gallery-elem-video-" + this.id, parent), w1, h1, videoSrc, videoHd, autoPlay, timeStamp, videoSwitching);
               if (this.options.enablega4 && typeof window.gtag === "function") window.gtag("event",
                  "Video", {
                     "Action": "Play",
                     "URL": this.elemArray[this.curElem][ELEM_SRC]
                  });
               if (this.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Video", "Play", this.elemArray[this.curElem][ELEM_SRC]])
            },
            showSWF: function () {
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var w1 = this.elemArray[this.curElem][ELEM_WIDTH];
               var h1 = this.elemArray[this.curElem][ELEM_HEIGHT];
               if (this.isFullscreen) this.adjustFullscreen(w1, h1);
               else $(".html5gallery-elem-" + this.id, this.$gallery).css({
                  "width": this.options.width,
                  "height": this.options.height
               });
               $(".html5gallery-elem-" + this.id, parent).html("<div class='html5gallery-elem-error-" + this.id + "' style='display:block; position:absolute; overflow:hidden; text-align:center; width:" + this.options.width + "px; left:0px; top:" + Math.round(this.options.height / 2 - 10) + "px; margin:4px;'><div class='html5gallery-error-" + this.id + "'>Adobe Flash has been discontinued!</div>");
               if (this.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Flash", {
                  "Action": "Play",
                  "URL": this.elemArray[this.curElem][ELEM_SRC]
               });
               if (this.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Flash", "Play", this.elemArray[this.curElem][ELEM_SRC]])
            },
            prepareYoutubeHref: function (href) {
               var youtubeId = href.match(/(\?v=|\/\d\/|\/embed\/|\/v\/|\.be\/)([a-zA-Z0-9\-\_]+)/)[2];
               var youtubedomain = href.indexOf("youtube-nocookie.com") !== -1 ? "youtube-nocookie.com" : "youtube.com";
               var result = "https://www." + youtubedomain + "/embed/" + youtubeId;
               var params = this.getYoutubeParams(href);
               var first = true;
               for (var key in params) {
                  if (first) {
                     result +=
                        "?";
                     first = false
                  } else result += "&";
                  result += key + "=" + params[key]
               }
               return result
            },
            getYoutubeParams: function (href) {
               var result = {};
               if (href.indexOf("?") < 0) return result;
               var params = href.substring(href.indexOf("?") + 1).split("&");
               for (var i = 0; i < params.length; i++) {
                  var value = params[i].split("=");
                  if (value && value.length == 2 && value[0].toLowerCase() != "v") result[value[0].toLowerCase()] = value[1]
               }
               return result
            },
            initYoutubeApi: function () {
               var i, initYoutube = false;
               var initVimeo = false;
               for (i = 0; i < this.elemArray.length; i++)
                  if (this.elemArray[i][ELEM_TYPE] ==
                     TYPE_VIDEO_YOUTUBE && this.elemArray[i][ELEM_SRC].indexOf("youtube-nocookie.com") === -1) initYoutube = true;
                  else if (this.elemArray[i][ELEM_TYPE] == TYPE_VIDEO_VIMEO) initVimeo = true;
               if (initYoutube) {
                  var tag = document.createElement("script");
                  tag.src = "https://www.youtube.com/iframe_api";
                  var firstScriptTag = document.getElementsByTagName("script")[0];
                  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag)
               }
               if (initVimeo) {
                  var tag = document.createElement("script");
                  tag.src = this.options.jsfolder + "froogaloop2.min.js";
                  var firstScriptTag = document.getElementsByTagName("script")[0];
                  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag)
               }
            },
            showEmbedVideo: function (autoPlay) {
               if (this.options.stopallplaying) this.stopAllPlaying();
               this.isVideoPlaying = true;
               if (autoPlay && this.options.autoslideandplayafterfirstplayed) {
                  this.options.autoplayvideo = true;
                  this.isPaused = false
               }
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
               var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
               var w1, h1;
               if (this.isFullscreen) {
                  var lw = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : Math.min(dataW, this.fullscreenWidth);
                  var lh = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : Math.min(dataH, this.fullscreenHeight);
                  this.adjustFullscreen(lw, lh);
                  w1 = lw;
                  h1 = lh
               } else {
                  $(".html5gallery-elem-" + this.id, this.$gallery).css({
                     "width": this.options.width,
                     "height": this.options.height
                  });
                  w1 = this.options.width;
                  h1 = this.options.height
               }
               var src = this.elemArray[this.curElem][ELEM_SRC];
               $(".html5gallery-elem-" + this.id, parent).html("<div class='html5gallery-loading-center-" + this.id + "'></div><div id='html5gallery-elem-video-" + this.id + "' style='display:block;position:absolute;overflow:hidden;top:" + (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;left:" + (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;width:" + w1 + "px;height:" + h1 + "px;'></div>" + this.options.watermarkcode);
               if (src.match(/\:\/\/.*(dai\.ly)/i)) {
                  var id = src.match(/(dai\.ly\/)([a-zA-Z0-9\-\_]+)/)[2];
                  src = "https://www.dailymotion.com/embed/video/" + id
               }
               if (autoPlay)
                  if (src.indexOf("?") < 0) src += "?autoplay=1";
                  else src += "&autoplay=1";
               $("#html5gallery-elem-video-" + this.id, parent).html("<iframe width='" + w1 + "' height='" + h1 + "' src='" + src + "' frameborder='0' allow='autoplay' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>");
               if (this.options.enablega4 && typeof window.gtag === "function") window.gtag("event",
                  "Video", {
                     "Action": "Play",
                     "URL": this.elemArray[this.curElem][ELEM_SRC]
                  });
               if (this.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Video", "Play", this.elemArray[this.curElem][ELEM_SRC]])
            },
            showYoutube: function (autoPlay) {
               if (this.options.stopallplaying) this.stopAllPlaying();
               this.isVideoPlaying = true;
               if (autoPlay && this.options.autoslideandplayafterfirstplayed) {
                  this.options.autoplayvideo = true;
                  this.isPaused = false
               }
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var dataW =
                  this.elemArray[this.curElem][ELEM_WIDTH];
               var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
               var w1, h1;
               if (this.isFullscreen) {
                  var lw = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : Math.min(dataW, this.fullscreenWidth);
                  var lh = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : Math.min(dataH, this.fullscreenHeight);
                  this.adjustFullscreen(lw, lh);
                  w1 = lw;
                  h1 = lh
               } else {
                  $(".html5gallery-elem-" + this.id, this.$gallery).css({
                     "width": this.options.width,
                     "height": this.options.height
                  });
                  w1 = this.options.width;
                  h1 = this.options.height
               }
               var src = this.elemArray[this.curElem][ELEM_SRC];
               $(".html5gallery-elem-" + this.id, parent).html("<div class='html5gallery-loading-center-" + this.id + "'></div><div id='html5gallery-elem-video-" + this.id + "' style='display:block;position:absolute;overflow:hidden;top:" + (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;left:" + (this.options.slideshadow &&
                  !this.isFullscreen ? 4 : 0) + "px;width:" + w1 + "px;height:" + h1 + "px;'></div>" + this.options.watermarkcode);
               var youtubeNoCookie = src.indexOf("youtube-nocookie.com") !== -1;
               var instance = this;
               if (!ASYouTubeIframeAPIReady && !youtubeNoCookie) {
                  ASYouTubeTimeout += 100;
                  if (ASYouTubeTimeout < 3E3) {
                     setTimeout(function () {
                        instance.showYoutube(autoPlay)
                     }, 100);
                     return
                  }
               }
               if (ASYouTubeIframeAPIReady && !this.options.isMobile && !this.options.isIE6 && !this.options.isIE7 && !youtubeNoCookie) {
                  var id = this.elemArray[this.curElem][ELEM_SRC].match(/(\?v=|\/\d\/|\/embed\/|\/v\/|\.be\/)([a-zA-Z0-9\-\_]+)/)[2];
                  var onPlayReady = function (event) {};
                  if (autoPlay) onPlayReady = function (event) {
                     event.target.playVideo()
                  };
                  var youtubeParams = this.getYoutubeParams(this.elemArray[this.curElem][ELEM_SRC]);
                  youtubeParams = $.extend({
                     "html5": 1,
                     "controls": instance.options.videohidecontrols ? "0" : "1",
                     "showinfo": instance.options.videohidecontrols ? "0" : "1",
                     "autoplay": autoPlay ? 1 : 0,
                     "rel": 0,
                     "wmode": "transparent"
                  }, youtubeParams);
                  this.ytPlayer = new YT.Player("html5gallery-elem-video-" + this.id, {
                     width: w1,
                     height: h1,
                     videoId: id,
                     playerVars: youtubeParams,
                     events: {
                        "onReady": onPlayReady,
                        "onStateChange": function (event) {
                           if (event.data == YT.PlayerState.ENDED) {
                              instance.onVideoEnd();
                              if (!instance.isPaused) instance.slideRun(-1)
                           }
                        }
                     }
                  })
               } else {
                  src = this.prepareYoutubeHref(src);
                  if (autoPlay)
                     if (src.indexOf("?") < 0) src += "?autoplay=1";
                     else src += "&autoplay=1";
                  if (src.indexOf("?") < 0) src += "?wmode=transparent&rel=0";
                  else src += "&wmode=transparent&rel=0";
                  if (instance.options.videohidecontrols) src += "&controls=0&showinfo=0";
                  src += "&version=3&enablejsapi=1";
                  $("#html5gallery-elem-video-" +
                     this.id, parent).html("<iframe width='" + w1 + "' height='" + h1 + "' src='" + src + "' frameborder='0' allow='autoplay' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>")
               }
               if (this.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Video", {
                  "Action": "Play",
                  "URL": this.elemArray[this.curElem][ELEM_SRC]
               });
               if (this.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Video", "Play", this.elemArray[this.curElem][ELEM_SRC]])
            },
            showVimeo: function (autoPlay) {
               if (this.options.stopallplaying) this.stopAllPlaying();
               this.isVideoPlaying = true;
               if (autoPlay && this.options.autoslideandplayafterfirstplayed) {
                  this.options.autoplayvideo = true;
                  this.isPaused = false
               }
               var instance = this;
               if (typeof $f !== "function") {
                  ASVimeoTimeout += 100;
                  if (ASVimeoTimeout < 3E3) {
                     setTimeout(function () {
                        instance.showVimeo(autoPlay)
                     }, 100);
                     return
                  }
               }
               var parent = this.isFullscreen ? this.$fullscreen : this.$gallery;
               var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
               var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
               var w1, h1;
               if (this.isFullscreen) {
                  var lw = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ?
                     Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : Math.min(dataW, this.fullscreenWidth);
                  var lh = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : Math.min(dataH, this.fullscreenHeight);
                  this.adjustFullscreen(lw, lh);
                  w1 = lw;
                  h1 = lh
               } else {
                  $(".html5gallery-elem-" + this.id, this.$gallery).css({
                     "width": this.options.width,
                     "height": this.options.height
                  });
                  w1 = this.options.width;
                  h1 = this.options.height
               }
               var src =
                  this.elemArray[this.curElem][ELEM_SRC];
               if (src.indexOf("?") < 0) src += "?";
               else src += "&";
               if (autoPlay && !this.options.isAndroid) src += "autoplay=1";
               else src += "autoplay=0";
               src += "&api=1&player_id=html5gallery_vimeo_" + this.id;
               $(".html5gallery-elem-" + this.id, parent).html("<div class='html5gallery-loading-center-" + this.id + "'></div><div class='html5gallery-elem-video-" + this.id + "' style='display:block;position:absolute;overflow:hidden;top:" + (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;left:" + (this.options.slideshadow &&
                  !this.isFullscreen ? 4 : 0) + "px;width:" + w1 + "px;height:" + h1 + "px;'></div>" + this.options.watermarkcode);
               $(".html5gallery-elem-video-" + this.id, parent).html("<iframe id='html5gallery_vimeo_" + this.id + "' width='" + w1 + "' height='" + h1 + "' src='" + src + "' frameborder='0' allow='autoplay' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>");
               if (typeof $f === "function" && autoPlay && !this.options.isAndroid) {
                  var vimeoIframe = $("#html5gallery_vimeo_" + this.id)[0];
                  var instance = this;
                  instance.vimeoPlayer = $f(vimeoIframe);
                  instance.vimeoPlayer.addEvent("ready", function () {
                     instance.vimeoPlayer.addEvent("finish", function (id) {
                        instance.onVideoEnd();
                        if (!instance.isPaused) instance.slideRun(-1)
                     })
                  })
               }
               if (this.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Video", {
                  "Action": "Play",
                  "URL": this.elemArray[this.curElem][ELEM_SRC]
               });
               if (this.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Video", "Play", this.elemArray[this.curElem][ELEM_SRC]])
            },
            showIframe: function () {
               var parent = this.isFullscreen ?
                  this.$fullscreen : this.$gallery;
               var dataW = this.elemArray[this.curElem][ELEM_WIDTH];
               var dataH = this.elemArray[this.curElem][ELEM_HEIGHT];
               var w1, h1;
               if (this.isFullscreen) {
                  var lw = this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXWIDTH], this.fullscreenWidth) : Math.min(dataW, this.fullscreenWidth);
                  var lh = this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT] ? Math.min(this.elemArray[this.curElem][ELEM_LIGHTBOXHEIGHT], this.fullscreenHeight) : Math.min(dataH, this.fullscreenHeight);
                  this.adjustFullscreen(lw, lh);
                  w1 = lw;
                  h1 = lh
               } else {
                  $(".html5gallery-elem-" + this.id, this.$gallery).css({
                     "width": this.options.width,
                     "height": this.options.height
                  });
                  w1 = this.options.width;
                  h1 = this.options.height
               }
               var src = this.elemArray[this.curElem][ELEM_SRC];
               $(".html5gallery-elem-" + this.id, parent).html("<div class='html5gallery-loading-center-" + this.id + "'></div><div class='html5gallery-elem-iframe-" + this.id + "' style='display:block;position:absolute;overflow:hidden;top:" + (this.options.slideshadow && !this.isFullscreen ?
                  4 : 0) + "px;left:" + (this.options.slideshadow && !this.isFullscreen ? 4 : 0) + "px;width:" + w1 + "px;height:" + h1 + "px;'></div>" + this.options.watermarkcode);
               $(".html5gallery-elem-iframe-" + this.id, parent).html("<iframe id='html5gallery-iframe-" + this.id + "' width='" + w1 + "' height='" + h1 + "' src='" + src + "' frameborder='0' webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>");
               if (this.options.enablega4 && typeof window.gtag === "function") window.gtag("event", "Iframe", {
                  "Action": "Play",
                  "URL": this.elemArray[this.curElem][ELEM_SRC]
               });
               if (this.options.googleanalyticsaccount && window._gaq) window._gaq.push(["_trackEvent", "Iframe", "Play", this.elemArray[this.curElem][ELEM_SRC]])
            },
            checkType: function (href) {
               if (!href) return -1;
               if (href.match(/\.(jpg|gif|png|bmp|jpeg)(.*)?$/i)) return TYPE_IMAGE;
               if (href.match(/[^\.]\.(swf)\s*$/i)) return TYPE_SWF;
               if (href.match(/[^\.]\.(mp3)\s*$/i)) return TYPE_MP3;
               if (href.match(/[^\.]\.(pdf)\s*$/i)) return TYPE_PDF;
               if (href.match(/\.(flv)(.*)?$/i)) return TYPE_VIDEO_FLASH;
               if (href.match(/\.(mp4|m4v)(.*)?$/i)) return TYPE_VIDEO_MP4;
               if (href.match(/\.(ogv|ogg)(.*)?$/i)) return TYPE_VIDEO_OGG;
               if (href.match(/\.(webm)(.*)?$/i)) return TYPE_VIDEO_WEBM;
               if (href.match(/\:\/\/.*(youtube\.com)/i) || href.match(/\:\/\/.*(youtu\.be)/i) || href.match(/\:\/\/.*(youtube-nocookie\.com)/i)) return TYPE_VIDEO_YOUTUBE;
               if (href.match(/\:\/\/.*(vimeo\.com)/i)) return TYPE_VIDEO_VIMEO;
               if (href.match(/\:\/\/.*(dailymotion\.com)/i) || href.match(/\:\/\/.*(dai\.ly)/i)) return TYPE_EMBED_VIDEO;
               return TYPE_IMAGE
            },
            onChange: function () {
               $(window).trigger("html5gallery.onchange",
                  [this.id, this.curElem]);
               if (this.options.onchange && window[this.options.onchange] && typeof window[this.options.onchange] == "function") window[this.options.onchange](this.elemArray[this.curElem].concat([this.id]))
            },
            onSlideshowOver: function () {
               $(window).trigger("html5gallery.onslideshowover", [this.id, this.curElem]);
               if (this.options.onslideshowover && window[this.options.onslideshowover] && typeof window[this.options.onslideshowover] == "function") window[this.options.onslideshowover](this.elemArray[this.curElem])
            },
            onThumbOver: function (index) {
               $(window).trigger("html5gallery.onthumbover", [this.id, index]);
               if (this.options.onthumbover && window[this.options.onthumbover] && typeof window[this.options.onthumbover] == "function") window[this.options.onthumbover](this.elemArray[index])
            },
            onThumbClick: function (index) {
               $(window).trigger("html5gallery.onthumbclick", [this.id, index]);
               if (this.options.onthumbclick && window[this.options.onthumbclick] && typeof window[this.options.onthumbclick] == "function") window[this.options.onthumbclick](this.elemArray[index].concat([this.id]));
               if (this.options.thumbjumptotop)
                  if (this.options.thumbjumpanchor && this.options.thumbjumpanchor.length > 0 && $("#" + this.options.thumbjumpanchor).length > 0) {
                     var t0 = $("#" + this.options.thumbjumpanchor).offset().top;
                     $(window).scrollTop(t0)
                  } else if (this.options.thumbjumpposition >= 0) $(window).scrollTop(this.options.thumbjumpposition);
               else {
                  var t = this.container.offset().top;
                  if (t < $(window).scrollTop()) $(window).scrollTop(t)
               }
            },
            onVideoEnd: function () {
               $(window).trigger("html5gallery.videoend", [this.id, this.curElem]);
               if (this.options.onvideoend && window[this.options.onvideoend] && typeof window[this.options.onvideoend] == "function") window[this.options.onvideoend](this.elemArray[this.curElem]);
               if (this.options.reloadonvideoend) this.slideRun(this.curElem);
               else if (this.options.loadnextonvideoend) this.slideRun(-1)
            },
            embedHTML5Video: function ($container, w, h, src, hd, autoPlay, timeStamp, videoSwitching) {
               var instance = this;
               if ((this.options.isIE11 || this.options.isIE) && this.options.usenativehtml5controlsonie || this.options.isFirefox &&
                  this.options.usenativehtml5controlsonfirefox || this.options.isIPhone && this.options.usenativehtml5controlsoniphone || this.options.isIPad && this.options.usenativehtml5controlsonipad || this.options.isAndroid && this.options.usenativehtml5controlsonandroid) this.options.nativehtml5controls = true;
               if (this.options.isIOS || this.options.isAndroid) this.options.fullscreennativecontrols = true;
               if (this.options.mutevideo) this.options.defaultvideovolume = 0;
               $container.html("<div class='html5gallery-elem-video-container-" + this.id +
                  "' style='position:relative;display:block;background-color:#000;width:100%;height:100%;'><video id='html5gallery-elem-html5-video-" + this.id + "' width='100%' height='100%'" + (this.options.nativehtml5controls && !this.options.videohidecontrols ? " controls" : "") + (this.options.html5videonodownload ? ' controlsList="nodownload"' : "") + (this.options.mutevideo ? " muted" : "") + (this.options.playsinline ? " playsinline" : "") + (this.options.loopvideo ? " loop" : "") + (this.options.donotuseposter && this.options.showhtml5videoposter &&
                     this.elemArray[this.curElem][ELEM_POSTER] ? ' poster="' + this.elemArray[this.curElem][ELEM_POSTER] + '"' : "") + ">" + (this.elemArray[this.curElem][ELEM_VTT] ? '<track default src="' + this.elemArray[this.curElem][ELEM_VTT] + '" kind="subtitles" srclang="' + this.elemArray[this.curElem][ELEM_VTTLANG] + '" label="' + this.elemArray[this.curElem][ELEM_VTTLABEL] + '">' : "") + "</video>" + "</div>");
               $("video", $container).get(0).setAttribute("src", (hd && this.isHd ? hd : src) + (timeStamp > 0 ? "#t=" + timeStamp : ""));
               if (!this.options.nativehtml5controls &&
                  !this.options.videohidecontrols) {
                  $("video", $container).data("src", src);
                  $("video", $container).data("hd", hd);
                  $("video", $container).data("ishd", this.isHd);
                  $("video", $container).addHTML5VideoControls(this.options.skinfolder, this, "#html5gallery-elem-html5-video-" + this.id, false, false, this.options.defaultvideovolume, this.options.fullscreennativecontrols, this.options.html5videonodownload, {
                     playbutton: this.options.playvideoimage
                  }, this.elemArray[this.curElem][ELEM_VTT] ? true : false, this.options.vttline, this.options.showsubtitlebydefault)
               }
               if (this.elemArray[this.curElem][ELEM_LINK]) {
                  $("video",
                     $container).css({
                     cursor: "pointer"
                  });
                  $("video", $container).off("click").on("click", function () {
                     if (instance.elemArray[instance.curElem][ELEM_LINK])
                        if (instance.elemArray[instance.curElem][ELEM_LINKTARGET]) window.open(instance.elemArray[instance.curElem][ELEM_LINK], instance.elemArray[instance.curElem][ELEM_LINKTARGET]);
                        else window.open(instance.elemArray[instance.curElem][ELEM_LINK])
                  })
               }
               if (autoPlay || videoSwitching) $("video", $container).get(0).play();
               $("video", $container).off("ended").on("ended", function () {
                  instance.onVideoEnd();
                  if (!instance.isPaused) instance.slideRun(-1)
               })
            }
         };
         this.each(function () {
            var $this = $(this);
            options = options || {};
            for (var key in options)
               if (key.toLowerCase() !== key) {
                  options[key.toLowerCase()] = options[key];
                  delete options[key]
               } if ($(this).data("donotinit") && (!options || !options["forceinit"])) return;
            if ($(this).data("inited")) return;
            $(this).data("inited", 1);
            this.options = $.extend({}, options);
            var instance = this;
            $.each($this.data(), function (key, value) {
               instance.options[key.toLowerCase()] = value
            });
            if ("skin" in this.options) this.options.skin =
               this.options.skin.toLowerCase();
            var commonOptions = {
               freelink: "#",
               watermark: "",
               watermarklink: "",
               enabletabindex: false,
               playvideoimage: "playvideo_64.png",
               playvideothumbimage: "playvideo.png",
               loadinggif: "loading.gif",
               centerloadinggif: "loading_center.gif",
               skin: "horizontal",
               googlefonts: "",
               mobileresizeevent: false,
               enabletouchswipe: true,
               enabletouchswipeonandroid: false,
               disablehovereventontouch: false,
               responsive: true,
               responsivefullscreen: false,
               resizedelay: 10,
               screenquery: {},
               firstitemid: 0,
               addimgtitle: false,
               src: "",
               xml: "",
               xmlnocache: true,
               stopallplaying: false,
               lightbox: false,
               autoslide: false,
               slideshowinterval: 6E3,
               random: false,
               borderradius: 0,
               loop: 0,
               pauseonmouseover: false,
               arrowloop: true,
               setfirstslideshowinterval: false,
               firstslideshowinterval: 6E3,
               reverse: false,
               notupdatecarousel: false,
               updatecarouselinterval: 6E4,
               youtubeimage: "0.jpg",
               youtubethumb: "0.jpg",
               autoplayvideo: false,
               html5player: true,
               playvideoonclick: true,
               videohidecontrols: false,
               useflashformp4onfirefox: false,
               reloadonvideoend: false,
               loadnextonvideoend: false,
               nativehtml5controls: false,
               hddefault: false,
               useflashonie9: true,
               useflashonie10: false,
               useflashonie11: false,
               fullscreennativecontrols: true,
               html5videonodownload: true,
               vttline: -4,
               vttlang: "en",
               vttlabel: "English",
               showsubtitlebydefault: true,
               usenativehtml5controlsoniphone: true,
               usenativehtml5controlsonipad: true,
               usenativehtml5controlsonandroid: true,
               usenativehtml5controlsonie: false,
               usenativehtml5controlsonfirefox: false,
               defaultvideovolume: 1,
               mutevideo: false,
               playsinline: false,
               loopvideo: false,
               autoslideandplayafterfirstplayed: false,
               lazyloadtags: "lazy-src,lazyload-src,cfsrc,src,orig-src",
               linkonlyonvideo: true,
               hidetitlewhenvideoisplaying: false,
               hideplaypausefullscreenwhenvideoisplaying: false,
               lightboxborder: 8,
               lightboxtextheight: 72,
               lightboxmargin: 12,
               lightboxbgcolor: "#fff",
               lightboxshowtitle: true,
               lightboxtitlecss: " {color:#333333; font:bold 12px Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; line-height:18px;}",
               lightboxtitlelinkcss: " a {color:#333333;}",
               lightboxshowdescription: true,
               lightboxdescriptioncss: " {color:#333333; font:normal 12px Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; line-height:14px;}",
               lightboxdescriptionlinkcss: " a {color:#333333;}",
               lightboxanimationspeed: 400,
               effect: "fade",
               easing: "easeOutCubic",
               duration: 1500,
               slide: {
                  duration: 1E3,
                  easing: "easeOutExpo"
               },
               width: 480,
               height: 270,
               showtimer: true,
               resizemode: "fit",
               showtitle: true,
               titleheight: 45,
               errorcss: " {text-align:center; color:#ff0000; font-size:14px; font-family:Arial, sans-serif;}",
               shownumbering: false,
               numberingformat: "%NUM / %TOTAL",
               ga4account: "",
               enablega4: true,
               googleanalyticsaccount: "",
               showsocialmedia: false,
               socialheight: 30,
               socialurlforeach: false,
               showfacebooklike: true,
               facebooklikeurl: "",
               twitterurl: "",
               twitterusername: "",
               twittervia: "html5box",
               showgoogleplus: true,
               googleplusurl: "",
               initsocial: false,
               showsocial: false,
               sharemediaurl: false,
               socialmode: "mouseover",
               socialposition: "position:absolute;top:8px;right:8px;",
               socialpositionlightbox: "position:absolute;top:8px;right:8px;",
               socialdirection: "horizontal",
               socialbuttonsize: 32,
               socialbuttonfontsize: 18,
               socialrotateeffect: true,
               showfacebook: true,
               showtwitter: true,
               showpinterest: true,
               showlinkedin: false,
               showgplus: false,
               showemail: false,
               showimagetoolbox: "always",
               imagetoolboxstyle: "side",
               imagetoolboxmode: "mouseover",
               showplaybutton: true,
               showprevbutton: true,
               shownextbutton: true,
               showfullscreenbutton: true,
               showplaypausefullscreenforall: false,
               showcarouselforsingle: false,
               carouselbgtransparent: true,
               carouselbgcolorstart: "#ffffff",
               carouselbgcolorend: "#ffffff",
               carouseltopborder: "#ffffff",
               carouselbottomborder: "#ffffff",
               carouselbgimage: "",
               carouseleasing: "easeOutCirc",
               carouselarrowwidth: 32,
               carouselarrowheight: 32,
               showcategory: true,
               categorystyle: "dropdown",
               categoryheight: 48,
               categorydefault: "all",
               thumbresponsive: "samesize",
               thumbcolumns: 5,
               thumbcolumnsresponsive: false,
               thumbmediumcolumns: 3,
               thumbmediumsize: 800,
               thumbsmallcolumns: 2,
               thumbsmallsize: 480,
               thumbmediumwidth: 64,
               thumbmediumheight: 64,
               thumbsmallwidth: 48,
               thumbsmallheight: 48,
               addthumbnailtitle: false,
               switchonmouseover: false,
               thumbverticalmiddle: false,
               carouselmultirows: false,
               thumbrowgap: 16,
               carouselpagination: false,
               carouselpaginationrow: 3,
               thumblinkintitle: false,
               thumbjumptotop: false,
               thumbjumpposition: -1,
               thumbjumpanchor: "",
               thumbshowimage: true,
               thumbshowtitle: false,
               thumbtitlecss: "{text-align:center; color:#000; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden;}",
               thumbtitleheight: 24,
               thumbmediumtitleheight: 48,
               thumbsmalltitleheight: 72,
               youtubeapikey: "",
               youtubeplaylistid: "",
               youtubeplaylistmaxresults: "",
               youtubeplaylistusemaxres: true,
               titlesmallscreen: false,
               titlesmallscreenwidth: 640,
               titleheightsmallscreen: 148,
               donotuseposter: false,
               showhtml5videoposter: true,
               splitvsliderontouch: true,
               forcetouch: false,
               version: "9.7",
               frve: true,
               fm: "87,111,114,100,80,114,101,115,115,32,71,97,108,108,101,114,121,32,84,114,105,97,108,32,86,101,114,115,105,111,110"
            };
            var horizontalSkinOptions = {
               skinfolder: "skins/horizontal/",
               padding: 6,
               bgcolor: "#ffffff",
               bgimage: "",
               galleryshadow: true,
               slideshadow: false,
               showsocialmedia: false,
               headerpos: "top",
               showdescription: true,
               titleoverlay: true,
               titleautohide: true,
               titlecss: " {color:#ffffff; font-size:14px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; text-align:left; padding:10px 0px 10px 10px; background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:13px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; text-align:left; padding:0px 0px 10px 10px; background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 0,
               carouselbgtransparent: false,
               carouselbgcolorstart: "#494f54",
               carouselbgcolorend: "#292c31",
               carouseltopborder: "#666666",
               carouselbottomborder: "#111111",
               thumbwidth: 64,
               thumbheight: 48,
               thumbgap: 4,
               thumbmargin: 6,
               thumbunselectedimagebordercolor: "#ffffff",
               thumbimageborder: 1,
               thumbimagebordercolor: "",
               thumbshowplayonvideo: true,
               thumbshadow: false,
               thumbopacity: 0.8
            };
            var lightSkinOptions = {
               padding: 12,
               skinfolder: "skins/light/",
               bgcolor: "",
               bgimage: "",
               galleryshadow: false,
               slideshadow: true,
               showsocialmedia: false,
               headerpos: "top",
               showdescription: true,
               titleoverlay: true,
               titleautohide: true,
               titlecss: " {color:#ffffff; font-size:14px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px 10px 10px;  background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 10px;  background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 10,
               carouselbgtransparent: true,
               thumbwidth: 48,
               thumbheight: 48,
               thumbgap: 8,
               thumbmargin: 12,
               thumbunselectedimagebordercolor: "#fff",
               thumbimageborder: 2,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: true,
               thumbopacity: 0.8
            };
            var mediapageSkinOptions = {
               padding: 0,
               skinfolder: "skins/mediapage/",
               bgcolor: "",
               bgimage: "",
               galleryshadow: false,
               slideshadow: false,
               showsocialmedia: false,
               headerpos: "top",
               showdescription: true,
               titleoverlay: true,
               titleautohide: true,
               titlecss: " {color:#ffffff; font-size:14px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px 10px 10px;  background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 10px;  background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 24,
               carouselmultirows: true,
               thumbrowgap: 16,
               carouselpagination: false,
               carouselbgtransparent: true,
               thumbwidth: 120,
               thumbheight: 60,
               thumbgap: 10,
               thumbmargin: 12,
               thumbunselectedimagebordercolor: "#fff",
               thumbimageborder: 0,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: false,
               thumbopacity: 0.8,
               thumbjumptotop: true,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:center; color:#000; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden;}",
               thumbtitleheight: 24
            };
            var gallerySkinOptions = {
               padding: 12,
               skinfolder: "skins/gallery/",
               bgcolor: "",
               bgimage: "",
               galleryshadow: false,
               slideshadow: true,
               showsocialmedia: false,
               headerpos: "top",
               showdescription: true,
               titleoverlay: true,
               titleautohide: true,
               titlecss: " {color:#ffffff; font-size:14px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px 10px 10px;  background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 10px;  background:rgb(102, 102, 102) transparent; background: rgba(102, 102, 102, 0.6); filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; -ms-filter:'progid:DXImageTransform.Microsoft.gradient(startColorstr=#99666666, endColorstr=#99666666)'; }",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 10,
               carouselbgtransparent: true,
               thumbwidth: 120,
               thumbheight: 60,
               thumbgap: 8,
               thumbmargin: 12,
               thumbunselectedimagebordercolor: "#fff",
               thumbimageborder: 2,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: true,
               thumbopacity: 0.8,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:center; color:#000; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal;}",
               thumbtitleheight: 18
            };
            var galleryWithTextSkinOptions = {
               padding: 12,
               skinfolder: "skins/gallery/",
               bgcolor: "",
               bgimage: "",
               galleryshadow: false,
               slideshadow: true,
               showsocialmedia: false,
               headerpos: "bottom",
               showdescription: true,
               titleoverlay: false,
               titleheight: 72,
               titleautohide: true,
               titlecss: "{color:#333;font-size:14px;font-family:Arial,Helvetica,sans-serif;overflow:hidden;text-align:center;padding:16px 8px 4px 8px;}",
               titlecsslink: "a{color:#333;}",
               descriptioncss: "{color:#333;font-size:12px;font-family:Arial,Helvetica,sans-serif;overflow:hidden;text-align:center;padding:4px 8px; }",
               descriptioncsslink: "a{color:#333;}",
               titlesmallscreen: true,
               showcarousel: true,
               carouselmargin: 10,
               carouselbgtransparent: true,
               thumbwidth: 120,
               thumbheight: 60,
               thumbgap: 8,
               thumbmargin: 12,
               thumbunselectedimagebordercolor: "#fff",
               thumbimageborder: 2,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: true,
               thumbopacity: 0.8,
               thumbshowtitle: false,
               thumbtitlecss: "{text-align:center; color:#000; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal;}",
               thumbtitleheight: 18
            };
            var galleryWithTextTopThumbnailsSkinOptions = {
               padding: 12,
               skinfolder: "skins/gallery/",
               bgcolor: "",
               bgimage: "",
               galleryshadow: false,
               slideshadow: true,
               showsocialmedia: false,
               headerpos: "bottom",
               showdescription: true,
               titleoverlay: false,
               titleheight: 72,
               titleautohide: true,
               titlecss: "{color:#333;font-size:14px;font-family:Arial,Helvetica,sans-serif;overflow:hidden;text-align:center;padding:16px 8px 4px 8px;}",
               titlecsslink: "a{color:#333;}",
               descriptioncss: "{color:#333;font-size:12px;font-family:Arial,Helvetica,sans-serif;overflow:hidden;text-align:center;padding:4px 8px; }",
               descriptioncsslink: "a{color:#333;}",
               titlesmallscreen: true,
               showcarousel: true,
               carouselmargin: 10,
               carouselposition: "top",
               carouselbgtransparent: true,
               thumbwidth: 120,
               thumbheight: 60,
               thumbgap: 8,
               thumbmargin: 12,
               thumbunselectedimagebordercolor: "#fff",
               thumbimageborder: 2,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: true,
               thumbopacity: 0.8,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:center; color:#000; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal;}",
               thumbtitleheight: 18
            };
            var galleryWithTextBottomSkinOptions = {
               padding: 12,
               skinfolder: "skins/gallery/",
               bgcolor: "",
               bgimage: "",
               galleryshadow: false,
               slideshadow: true,
               showsocialmedia: false,
               headerpos: "bottomoutside",
               showdescription: true,
               titleoverlay: false,
               titleheight: 72,
               titleautohide: true,
               titlecss: "{color:#333;font-size:14px;font-family:Arial,Helvetica,sans-serif;overflow:hidden;text-align:center;padding:16px 8px 4px 8px;}",
               titlecsslink: "a{color:#333;}",
               descriptioncss: "{color:#333;font-size:12px;font-family:Arial,Helvetica,sans-serif;overflow:hidden;text-align:center;padding:4px 8px; }",
               descriptioncsslink: "a{color:#333;}",
               titlesmallscreen: true,
               showcarousel: true,
               carouselmargin: 10,
               carouselbgtransparent: true,
               thumbwidth: 120,
               thumbheight: 60,
               thumbgap: 8,
               thumbmargin: 12,
               thumbunselectedimagebordercolor: "#fff",
               thumbimageborder: 2,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: true,
               thumbopacity: 0.8,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:center; color:#000; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal;}",
               thumbtitleheight: 18
            };
            var darknessSkinOptions = {
               skinfolder: "skins/darkness/",
               padding: 12,
               bgcolor: "#444444",
               bgimage: "background.jpg",
               galleryshadow: false,
               slideshadow: false,
               headerpos: "bottom",
               showdescription: false,
               titleoverlay: false,
               titleautohide: false,
               titlecss: " {color:#ffffff; font-size:16px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px;}",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 0px;}",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 8,
               carouselbgtransparent: false,
               carouselbgcolorstart: "#494f54",
               carouselbgcolorend: "#292c31",
               carouseltopborder: "#666666",
               carouselbottomborder: "#111111",
               thumbwidth: 64,
               thumbheight: 48,
               thumbgap: 4,
               thumbmargin: 6,
               thumbunselectedimagebordercolor: "#ffffff",
               thumbimageborder: 1,
               thumbimagebordercolor: "",
               thumbshowplayonvideo: true,
               thumbshadow: false,
               thumbopacity: 0.8
            };
            var verticalLightSkinOptions = {
               skinfolder: "skins/verticallight/",
               padding: 12,
               bgcolor: "#fff",
               bgimage: "",
               galleryshadow: false,
               slideshadow: false,
               headerpos: "bottom",
               showdescription: false,
               titleoverlay: false,
               titleautohide: false,
               titlecss: " {color:#333; font-size:16px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px;}",
               titlecsslink: " a {color:#333;}",
               descriptioncss: " {color:#333; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 0px;}",
               descriptioncsslink: " a {color:#333;}",
               showcarousel: true,
               carouselmargin: 8,
               carouselposition: "right",
               carouselposresponsive: true,
               carouselposresponsiveonscreenwidth: 800,
               carouselheight: 280,
               carouselbgtransparent: false,
               carouselbgcolorstart: "#fff",
               carouselbgcolorend: "#fff",
               carouseltopborder: "#fff",
               carouselbottomborder: "#fff",
               carouselhighlightbgcolorstart: "#f0f0f0",
               carouselhighlightbgcolorend: "#f0f0f0",
               carouselhighlighttopborder: "#f0f0f0",
               carouselhighlightbottomborder: "#f0f0f0",
               carouselhighlightbgimage: "",
               thumbwidth: 148,
               thumbheight: 48,
               thumbgap: 2,
               thumbmargin: 6,
               thumbunselectedimagebordercolor: "",
               thumbimageborder: 0,
               thumbimagebordercolor: "#fff",
               thumbshowplayonvideo: true,
               thumbshadow: false,
               thumbopacity: 0.8,
               thumbshowimage: true,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:center; color:#333; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal;}"
            };
            var verticalLightWithLeftSkinOptions = $.extend({}, verticalLightSkinOptions, {
               carouselposition: "left"
            });
            var verticalSkinOptions = {
               skinfolder: "skins/vertical/",
               padding: 12,
               bgcolor: "#444444",
               bgimage: "background.jpg",
               galleryshadow: false,
               slideshadow: false,
               headerpos: "bottom",
               showdescription: false,
               titleoverlay: false,
               titleautohide: false,
               titlecss: " {color:#ffffff; font-size:16px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px;}",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 0px;}",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 8,
               carouselposition: "right",
               carouselposresponsive: true,
               carouselposresponsiveonscreenwidth: 800,
               carouselheight: 280,
               carouselbgtransparent: false,
               carouselbgcolorstart: "#494f54",
               carouselbgcolorend: "#292c31",
               carouseltopborder: "#666666",
               carouselbottomborder: "#111111",
               carouselhighlightbgcolorstart: "#999999",
               carouselhighlightbgcolorend: "#666666",
               carouselhighlighttopborder: "#cccccc",
               carouselhighlightbottomborder: "#444444",
               carouselhighlightbgimage: "",
               thumbwidth: 148,
               thumbheight: 48,
               thumbgap: 2,
               thumbmargin: 6,
               thumbunselectedimagebordercolor: "",
               thumbimageborder: 1,
               thumbimagebordercolor: "#cccccc",
               thumbshowplayonvideo: true,
               thumbshadow: false,
               thumbopacity: 0.8,
               thumbshowimage: true,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:center; color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal;}"
            };
            var verticalWithLeftSkinOptions = $.extend({}, verticalSkinOptions, {
               carouselposition: "left"
            });
            var showcaseSkinOptions = {
               skinfolder: "skins/showcase/",
               padding: 12,
               bgcolor: "#444444",
               bgimage: "background.jpg",
               galleryshadow: false,
               slideshadow: false,
               showsocialmedia: false,
               headerpos: "bottom",
               showdescription: false,
               titleoverlay: false,
               titleautohide: false,
               titlecss: " {color:#ffffff; font-size:16px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:10px 0px;}",
               titlecsslink: " a {color:#ffffff;}",
               descriptioncss: " {color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; white-space:normal; text-align:left; padding:0px 0px 10px 0px;}",
               descriptioncsslink: " a {color:#ffffff;}",
               showcarousel: true,
               carouselmargin: 8,
               carouselposition: "bottom",
               carouselheight: 280,
               carouselposresponsive: false,
               carouselbgtransparent: false,
               carouselbgcolorstart: "#494f54",
               carouselbgcolorend: "#292c31",
               carouseltopborder: "#666666",
               carouselbottomborder: "#111111",
               carouselhighlightbgcolorstart: "#999999",
               carouselhighlightbgcolorend: "#666666",
               carouselhighlighttopborder: "#cccccc",
               carouselhighlightbottomborder: "#444444",
               carouselhighlightbgimage: "",
               thumbwidth: 148,
               thumbheight: 60,
               thumbgap: 2,
               thumbmargin: 6,
               thumbunselectedimagebordercolor: "",
               thumbimageborder: 1,
               thumbimagebordercolor: "#cccccc",
               thumbshowplayonvideo: true,
               thumbshadow: false,
               thumbopacity: 0.8,
               thumbshowimage: true,
               thumbshowtitle: true,
               thumbtitlecss: "{text-align:left; color:#ffffff; font-size:12px; font-family:Arial,Helvetica,sans-serif; overflow:hidden; padding: 6px 0;}",
               thumbshowdescription: true,
               thumbdescriptioncss: "{font-size:10px;}"
            };
            var sysOptions = commonOptions;
            if (this.options.skin == "vertical") sysOptions = $.extend(sysOptions,
               verticalSkinOptions);
            else if (this.options.skin == "verticalwithleft") sysOptions = $.extend(sysOptions, verticalWithLeftSkinOptions);
            else if (this.options.skin == "verticallight") sysOptions = $.extend(sysOptions, verticalLightSkinOptions);
            else if (this.options.skin == "verticallightwithleft") sysOptions = $.extend(sysOptions, verticalLightWithLeftSkinOptions);
            else if (this.options.skin == "showcase") sysOptions = $.extend(sysOptions, showcaseSkinOptions);
            else if (this.options.skin == "light") sysOptions = $.extend(sysOptions, lightSkinOptions);
            else if (this.options.skin == "gallery") sysOptions = $.extend(sysOptions, gallerySkinOptions);
            else if (this.options.skin == "gallerywithtext") sysOptions = $.extend(sysOptions, galleryWithTextSkinOptions);
            else if (this.options.skin == "gallerywithtopthumbs") sysOptions = $.extend(sysOptions, galleryWithTextTopThumbnailsSkinOptions);
            else if (this.options.skin == "gallerywithtextbottom") sysOptions = $.extend(sysOptions, galleryWithTextBottomSkinOptions);
            else if (this.options.skin == "horizontal") sysOptions = $.extend(sysOptions,
               horizontalSkinOptions);
            else if (this.options.skin == "darkness") sysOptions = $.extend(sysOptions, darknessSkinOptions);
            else if (this.options.skin == "mediapage") sysOptions = $.extend(sysOptions, mediapageSkinOptions);
            else sysOptions = $.extend(sysOptions, horizontalSkinOptions);
            this.options = $.extend(sysOptions, this.options);
            this.options.titleheightlargescreen = this.options.titleheight;
            if (this.options.lightbox) this.options.showfullscreenbutton = false;
            if ("slideduration" in this.options) this.options.slide.duration = this.options.slideduration;
            this.options.htmlfolder = window.location.href.substr(0, window.location.href.lastIndexOf("/") + 1);
            if (!this.options.jsfolder || !this.options.jsfolder.length) this.options.jsfolder = jsFolder;
            if (this.options.skinfolder.charAt(0) != "/" && this.options.skinfolder.substring(0, 5) != "http:" && this.options.skinfolder.substring(0, 6) != "https:") this.options.skinfolder = this.options.jsfolder + this.options.skinfolder;
            var image_list = ["bgimage", "playvideoimage", "playvideothumbimage", "loadinggif", "centerloadinggif"];
            for (var i =
                  0; i < image_list.length; i++)
               if (this.options[image_list[i]] && this.options[image_list[i]].length > 0 && this.options[image_list[i]].substring(0, 7).toLowerCase() != "http://" && this.options[image_list[i]].substring(0, 8).toLowerCase() != "https://") this.options[image_list[i]] = this.options.skinfolder + this.options[image_list[i]];
            var i;
            var l;
            var mark = "";
            var bytes = this.options.fm.split(",");
            for (i = 0; i < bytes.length; i++) mark += String.fromCharCode(bytes[i]);
            this.options.frvem = mark;
            var d0 = "wmoangdiecrpluginh.iclolms";
            for (i =
               1; i <= 5; i++) d0 = d0.slice(0, i) + d0.slice(i + 1);
            l = d0.length;
            for (i = 0; i < 5; i++) d0 = d0.slice(0, l - 9 + i) + d0.slice(l - 8 + i);
            if (this.options.htmlfolder.indexOf(d0) != -1) this.options.frve = false;
            var screenWidth = $(window).width();
            if (this.options.screenquery)
               for (var i in this.options.screenquery)
                  if (screenWidth <= this.options.screenquery[i].screenwidth) {
                     if (this.options.screenquery[i].gallerywidth) this.options.width = this.options.screenquery[i].gallerywidth;
                     if (this.options.screenquery[i].galleryheight) this.options.height = this.options.screenquery[i].galleryheight;
                     if (this.options.screenquery[i].thumbwidth) this.options.thumbwidth = this.options.screenquery[i].thumbwidth;
                     if (this.options.screenquery[i].thumbheight) this.options.thumbheight = this.options.screenquery[i].thumbheight
                  } var galleryid;
            if ("galleryid" in this.options) galleryid = this.options.galleryid;
            else {
               galleryid = html5GalleryId;
               html5GalleryId++
            }
            var html5GalleryObject = new Html5Gallery($this, this.options, galleryid);
            $this.data("html5galleryobject", html5GalleryObject);
            $this.data("html5galleryid", galleryid);
            if (typeof html5GalleryObjects !==
               "undefined" && html5GalleryObjects && html5GalleryObjects.objects) html5GalleryObjects.addObject(html5GalleryObject)
         });
         return this
      }
   })(jQuery);
   jQuery(document).ready(function () {
      jQuery(".wonderplugin-engine").css({
         display: "none"
      });
      if (jQuery.fn.wonderplugingallery) jQuery(".wonderplugingallery").wonderplugingallery()
   })
}

function HTML5GalleryTimer(interval, callback, updatecallback) {
   var timerInstance = this;
   timerInstance.timeout = interval;
   var updateinterval = 50;
   var updateTimerId = null;
   var runningTime = 0;
   var paused = false;
   var started = false;
   var startedandpaused = false;
   this.setInterval = function (interval) {
      timerInstance.timeout = interval
   };
   this.pause = function () {
      if (started) {
         paused = true;
         clearInterval(updateTimerId)
      }
   };
   this.resume = function (forceresume) {
      if (startedandpaused && !forceresume) return;
      startedandpaused = false;
      if (started && paused) {
         paused =
            false;
         updateTimerId = setInterval(function () {
            runningTime += updateinterval;
            if (runningTime > timerInstance.timeout) {
               clearInterval(updateTimerId);
               if (callback) callback()
            }
            if (updatecallback) updatecallback(runningTime / timerInstance.timeout)
         }, updateinterval)
      }
   };
   this.stop = function () {
      clearInterval(updateTimerId);
      if (updatecallback) updatecallback(-1);
      runningTime = 0;
      paused = false;
      started = false
   };
   this.start = function () {
      runningTime = 0;
      paused = false;
      started = true;
      updateTimerId = setInterval(function () {
         runningTime += updateinterval;
         if (runningTime > timerInstance.timeout) {
            clearInterval(updateTimerId);
            if (callback) callback()
         }
         if (updatecallback) updatecallback(runningTime / timerInstance.timeout)
      }, updateinterval)
   };
   this.startandpause = function () {
      runningTime = 0;
      paused = true;
      started = true;
      startedandpaused = true
   }
}
(function () {
   var scripts = document.getElementsByTagName("script");
   var jsFolder = "";
   for (var i = 0; i < scripts.length; i++)
      if (scripts[i].src && scripts[i].src.match(/wonderplugingallery\.js/i)) jsFolder = scripts[i].src.substr(0, scripts[i].src.lastIndexOf("/") + 1);
   var loadjQuery = false;
   if (typeof jQuery == "undefined") loadjQuery = true;
   else {
      var jVersion = jQuery.fn.jquery.split(".");
      if (jVersion[0] < 1 || jVersion[0] == 1 && jVersion[1] < 6) loadjQuery = true
   }
   if (false) {
      var head = document.getElementsByTagName("head")[0];
      var script = document.createElement("script");
      script.setAttribute("type", "text/javascript");
      if (script.readyState) script.onreadystatechange = function () {
         if (script.readyState == "loaded" || script.readyState == "complete") {
            script.onreadystatechange = null;
            loadHtml5Gallery(jsFolder)
         }
      };
      else script.onload = function () {
         loadHtml5Gallery(jsFolder)
      };
      script.setAttribute("src", jsFolder + "jquery.js");
      head.appendChild(script)
   } else loadHtml5Gallery(jsFolder)
})();