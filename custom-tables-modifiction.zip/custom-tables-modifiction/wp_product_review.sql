-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 08:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wordpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_product_review`
--

CREATE TABLE `wp_product_review` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `company` varchar(100) NOT NULL,
  `review` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wp_product_review`
--

INSERT INTO `wp_product_review` (`id`, `product_id`, `company`, `review`) VALUES
(1, 5261, 'b db db db', 'g e bdb d'),
(2, 5261, ' bdb db db', 'db edb db'),
(5, 5261, 'b s bsdb s', ' sb sdbsb s'),
(6, 7874, ' bsb sb sb s', ' s sbsb sb sb sb s'),
(7, 14223, 'v svsvsv', ' vsvsd'),
(8, 14223, ' ca cac ac aca', 'a sza aca cac'),
(9, 5261, ' s s s s ', 'vvsvsv  s s'),
(10, 12648, 'test', 'test'),
(11, 12648, 'testb db db db d', 'test bdb db db db d'),
(12, 5261, 'hr hr', 'v sv sv sv sv s'),
(13, 7874, ' a avv av vv', 'av avasv av av av a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_product_review`
--
ALTER TABLE `wp_product_review`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_product_review`
--
ALTER TABLE `wp_product_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
