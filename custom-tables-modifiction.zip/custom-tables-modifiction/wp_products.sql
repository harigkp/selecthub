-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 08:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wordpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_products`
--

CREATE TABLE `wp_products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `logo_url` varchar(255) NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `popularity` int(11) NOT NULL,
  `default_category_id` int(11) NOT NULL,
  `industry` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wp_products`
--

INSERT INTO `wp_products` (`id`, `name`, `logo_url`, `vendor_name`, `slug`, `popularity`, `default_category_id`, `industry`) VALUES
(1930, 'Accruent', 'https://d3uimxdj41cg3o.cloudfront.net/products/29530de21430b7540ec3f65135f7323c-142cbbfceb28dc4bcdd689b224594b7f/resources/original/logo.png?1590792626', 'Accruent', 'accruent', 2, 377, 'Manufacturing'),
(5261, 'TheWorxHub', 'https://d3uimxdj41cg3o.cloudfront.net/products/c6943e764b46c1c95fa6dd19904a055d-6d757637949e61ec4e8675c0dc457267/resources/original/logo.jpg?1673984309', 'Brightly Software', 'theworxhub', 19, 377, 'Manufacturing'),
(7874, 'LeaseQuery', 'https://d3uimxdj41cg3o.cloudfront.net/products/305ddad049f65a2c241dbb6e6f746c54-7bc6608990f90dce0708888fc555491d/resources/original/logo.png?1668076216', 'LeaseQuery', 'leasequery', 55, 377, 'Energy & Utilities'),
(7881, 'Facilitron', 'https://d3uimxdj41cg3o.cloudfront.net/products/7c9e9afa5a9dc68ccaf27d9effeb9383-ed6b3aa722c3bba64fa03960a0584cec/resources/original/logo.png?1629827572', 'Facilitron', 'facilitron', 53, 377, 'Federal Government'),
(12581, 'Facilitypal', 'https://d3uimxdj41cg3o.cloudfront.net/products/e2575ed7d2c481c414c10e688bcbc4cf-eacf331f0ffc35d4b482f1d15a887d3b/resources/original/logo.png?1668211975', 'Arya Ceylon Holdings', 'facilitypal', 251, 377, 'Human Resources'),
(12648, 'Planima', 'https://d3uimxdj41cg3o.cloudfront.net/products/1bff3f64f354e35b89422273e74cab8f-eacf331f0ffc35d4b482f1d15a887d3b/resources/original/logo.png?1668212096', 'InterDynamics', 'planima', 180, 377, 'Electronics'),
(13065, 'andcards', 'https://d3uimxdj41cg3o.cloudfront.net/products/fed02ce0e96f989ec31e4eb6596bb06e-eacf331f0ffc35d4b482f1d15a887d3b/resources/original/logo.png?1668212982', 'andcards', 'andcards', 146, 377, 'Semiconductors'),
(14223, 'KeyLogic CAFM', 'https://d3uimxdj41cg3o.cloudfront.net/products/b844b947d3f4f2829acc21c79ee6ef5e-eacf331f0ffc35d4b482f1d15a887d3b/resources/original/logo.png?1668526724', 'KeyLogic', 'keylogic', 281, 377, 'Recruiting Agency'),
(16054, 'Omni Commercial & Healthcare', 'https://d3uimxdj41cg3o.cloudfront.net/products/bb226d51f12d70d1da7fd1fcaebc0dfd-eacf331f0ffc35d4b482f1d15a887d3b/resources/original/logo.png?1668526595', 'Omni Software Solutions', 'omni-commercial', 291, 377, 'Transportation & Logistics'),
(16335, 'Layout-iQ', 'https://d3uimxdj41cg3o.cloudfront.net/products/d1183696d4d901b9b97416efe8c85f08-eacf331f0ffc35d4b482f1d15a887d3b/resources/original/logo.png?1668526630', 'Rapid Modeling Corporation', 'layout-iq', 242, 377, 'Sports and Recreation');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_products`
--
ALTER TABLE `wp_products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_products`
--
ALTER TABLE `wp_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16336;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
