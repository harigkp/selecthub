-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 08:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wordpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_categories`
--

CREATE TABLE `wp_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wp_categories`
--

INSERT INTO `wp_categories` (`id`, `name`, `slug`, `position`) VALUES
(16, 'Cloud Management Software', 'cloud-management-software', 2),
(19, 'Security Compliance Software', 'security-compliance-software', 3),
(25, 'Server Monitoring Software Tools', 'server-monitoring-software', 3),
(29, 'CMS Software', 'cms-software', 6),
(34, 'Anti-Virus Software', 'anti-virus-software', 4),
(36, 'CDN Providers', 'cdn-providers', 7),
(40, 'Cloud Storage Providers', 'cloud-storage-providers', 8),
(43, 'Sales Force Automation Software', 'sales-force-automation-software', 8),
(46, 'Financial Management Software', 'financial-management-software', 3),
(50, 'BPM Software Tools', 'business-process-management-software', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_categories`
--
ALTER TABLE `wp_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_categories`
--
ALTER TABLE `wp_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
