-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 08:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wordpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  `position` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`, `position`) VALUES
(1, 'SelectHub Newsroom', 'selecthub-newsroom', 0, NULL),
(2, 'main', 'main', 0, NULL),
(5, 'text', 'text', 0, NULL),
(6, 'after_paragraph', 'after_paragraph', 0, NULL),
(7, 'sample', 'sample', 0, NULL),
(8, 'message', 'message', 0, NULL),
(9, 'php', 'php', 0, NULL),
(10, 'everywhere', 'everywhere', 0, NULL),
(11, 'disable', 'disable', 0, NULL),
(12, 'comments', 'comments', 0, NULL),
(13, 'generated', 'generated', 0, NULL),
(14, 'site_wide_header', 'site_wide_header', 0, NULL),
(15, 'simple', 'simple', 0, NULL),
(16, 'Cloud Management Software', 'cloud-management-software', 0, 2),
(17, 'variable', 'variable', 0, NULL),
(18, 'external', 'external', 0, NULL),
(19, 'Security Compliance Software', 'security-compliance-software', 0, 3),
(20, 'exclude-from-catalog', 'exclude-from-catalog', 0, NULL),
(21, 'featured', 'featured', 0, NULL),
(22, 'outofstock', 'outofstock', 0, NULL),
(23, 'rated-1', 'rated-1', 0, NULL),
(24, 'rated-2', 'rated-2', 0, NULL),
(25, 'Server Monitoring Software Tools', 'server-monitoring-software', 0, 3),
(26, 'rated-4', 'rated-4', 0, NULL),
(27, 'rated-5', 'rated-5', 0, NULL),
(28, 'Uncategorized', 'uncategorized', 0, NULL),
(29, 'CMS Software', 'cms-software', 0, 6),
(30, 'Hoodies', 'hoodies', 0, NULL),
(31, 'Blue', 'blue', 0, NULL),
(32, 'Business Intelligence', 'business-intelligence', 0, NULL),
(34, 'Anti-Virus Software', 'anti-virus-software', 0, 4),
(36, 'CDN Providers', 'cdn-providers', 0, 7),
(40, 'Cloud Storage Providers', 'cloud-storage-providers', 0, 8),
(43, 'Sales Force Automation Software', 'sales-force-automation-software', 0, 8),
(46, 'Financial Management Software', 'financial-management-software', 0, 3),
(48, 'hari', 'hari', 0, NULL),
(50, 'BPM Software Tools', 'business-process-management-software', 0, 9),
(377, 'Business Intelligence', 'business-intelligence', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=379;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
